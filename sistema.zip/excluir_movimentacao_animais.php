<?php
	$documento = $_REQUEST['id'];

	@ session_start(); 
    $nomeusuario = $_SESSION['nome_usuario'];
    $controle_estoque = $_SESSION['controle_estoque'];

	include "conecta_mysql.inc";

    $tbl_movimentacao = mysqli_query($conector, "SELECT * FROM tbl_movimentacao
        WHERE tbl_movimentacao_id='$documento'");
                                    
    $reg_mov = mysqli_fetch_object($tbl_movimentacao);
    $codigo_pesagem = $reg_mov->tbl_movimentacao_codigo_pesagem;
    $tipo_mov = $reg_mov->tbl_movimentacao_tipo;
    $data_mov = $reg_mov->tbl_movimentacao_data;

    if ($tipo_mov!=4) {
    	if ($controle_estoque=='I') {
		    $tbl_item = mysqli_query($conector, "select * from tbl_item_movimentacao
		        where tbl_ite_movimentacao_numero_id='$documento'"); 

		    while ($reg_item = mysqli_fetch_object($tbl_item)) {
			    $codigo_animal_id = $reg_item->tbl_ite_movimentacao_codigo_id_animal;

				$rs = mysqli_query($conector, "SELECT * FROM tbl_animais
		              WHERE tbl_animal_codigo_id='$codigo_animal_id'");

		    	$num_rows = mysqli_num_rows($rs);
		    	if ($num_rows!=0) {
		        	$reg_animal = mysqli_fetch_object($rs);
		        	$codigo_origem_anterior = $reg_animal->tbl_animal_codigo_origem_anterior;
		        	$codigo_fazenda_anterior = $reg_animal->tbl_animal_codigo_fazenda_anterior;
		        	$situacao = $reg_animal->tbl_animal_situacao;
		        	$codigo_numerico = $reg_animal->tbl_animal_codigo_numerico;

	                $primeiro_peso = $reg_animal->tbl_animal_primeiro_peso; 
	                $peso_desmama = $reg_animal->tbl_animal_peso_desmama; 
	                $ultimo_peso = $reg_animal->tbl_animal_ultimo_peso; 

	                if ($ultimo_peso!=0 && $ultimo_peso!='') {
	                    $peso = $ultimo_peso;
	                }
	                else if ($peso_desmama!=0 && $peso_desmama!='') {
	                    $peso = $peso_desmama;
	                }
	                else if ($primeiro_peso!=0 && $primeiro_peso!=''){
	                    $peso = $primeiro_peso;
	                }
	                else {
	                    $peso = 0;
	                }
		    	}

		    	if ($situacao=='T'){
					$sql = "UPDATE tbl_animais SET
								tbl_animal_ativo='S',
								tbl_animal_situacao='',
								tbl_animal_baixado_em=null,
								tbl_animal_baixado_por=null,
								tbl_animal_observacao='',
								tbl_animal_codigo_origem_anterior=0,
								tbl_animal_codigo_fazenda_anterior=0
						    WHERE tbl_animal_codigo_id='$codigo_animal_id'";
		    	}
		    	else {
					$sql = "UPDATE tbl_animais SET
								tbl_animal_ativo='S',
								tbl_animal_situacao='',
								tbl_animal_baixado_em=null,
								tbl_animal_baixado_por=null,
								tbl_animal_observacao='',
								tbl_animal_codigo_fazenda='$codigo_fazenda_anterior',
								tbl_animal_codigo_origem='$codigo_origem_anterior',
								tbl_animal_codigo_origem_anterior=0,
								tbl_animal_codigo_fazenda_anterior=0
						    WHERE tbl_animal_codigo_id='$codigo_animal_id'";
		    	}

				$resultado = mysqli_query($conector,$sql);
				$erro_mysql = mysqli_error($conector);

				if (!$resultado){
				    $valor[0]=9;
				    $valor[1]='Erro ao estornar a baixa do animal! ' . $codigo_numerico . ' - ' . $erro_mysql;
				    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
				    die ($str);
				}

			    // Exclui o flag de vendido, morte ou outras saidas na tabela tbl_item_cobertura
			    if ($tipo_mov==3 || $tipo_mov==888 || $tipo_mov==999){

				    if ($tipo_mov==3) {
				    	$situacao='V';
				    }
				    else if ($tipo_mov==888) {
				    	$situacao='M';
				    }
				    else {
				    	$situacao='O';
				    }

			        $item_cobertura = mysqli_query($conector, "SELECT * FROM tbl_item_cobertura
			            INNER JOIN tbl_cobertura 
			        	        ON tbl_cobertura_id = tbl_ite_cobertura_numero_id
			            WHERE tbl_cobertura_controle='C' AND 
			                  tbl_cobertura_encerrada='S' AND
			                  tbl_ite_cobertura_codigo_id_animal='$codigo_animal_id' AND 
			                  tbl_ite_cobertura_resultado_diagnostico='P' AND 
			                  tbl_ite_cobertura_nascido='O' AND 
			                  tbl_ite_cobertura_situacao_femea_nascido_outro='$situacao'");

				    $num_rows = mysqli_num_rows($item_cobertura);

				    if ($num_rows!=0) {
				       	$reg_item = mysqli_fetch_object($item_cobertura);
				       	$cobertura_id = $reg_item->tbl_ite_cobertura_numero_id;
				       	$numero_item = $reg_item->tbl_ite_cobertura_numero_item;
						    
					    $sql = "UPDATE tbl_item_cobertura SET
								tbl_ite_cobertura_nascido='',
								tbl_ite_cobertura_situacao_femea_nascido_outro=''
				 			WHERE tbl_ite_cobertura_numero_id ='$cobertura_id' AND 
				 	   			  tbl_ite_cobertura_numero_item='$numero_item'";
				       	
					   	$resultado = mysqli_query($conector,$sql);
						$erro_mysql = mysqli_error($conector);

						if (!$resultado){
						    $valor[0]=9;
						    $valor[1]='Ocorreu um erro na atualização do item de cobertura animal ' . $codigo_numerico . ' erro ' . $erro_mysql;
						    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
						    die ($str);
						} 
				    }
			    }
			    // Fim inclui flag de vendido, morte ou outra saida
		    }
    	}

	    $tbl_estoque = mysqli_query($conector, "select * from tbl_movimentacao_estoque
	        where tbl_mov_estoque_codigo_movimentacao='$documento'"); 

	    while ($reg_estoque = mysqli_fetch_object($tbl_estoque)) {
		    $codigo_animal_id = $reg_estoque->tbl_mov_estoque_codigo_id_animal;
		    $nascimento = $reg_estoque->tbl_mov_estoque_nascimento;
			$sexo = $reg_estoque->tbl_mov_estoque_sexo;
		    $codigo_pasto = $reg_estoque->tbl_mov_estoque_codigo_pasto;
		    $codigo_local = $reg_estoque->tbl_mov_estoque_local;
		    $codigo_categoria = $reg_estoque->tbl_mov_estoque_codigo_categoria;
	        $ent_sai = $reg_estoque->tbl_mov_estoque_entrada_saida;
	        $tipo = $reg_estoque->tbl_mov_estoque_tipo_movimentacao;

			$rs = mysqli_query($conector, "SELECT * FROM tbl_animais
		        WHERE tbl_animal_codigo_id='$codigo_animal_id'");

		    $num_rows = mysqli_num_rows($rs);
		    if ($num_rows!=0) {
		       	$reg_animal = mysqli_fetch_object($rs);

	            $primeiro_peso = $reg_animal->tbl_animal_primeiro_peso; 
	            $peso_desmama = $reg_animal->tbl_animal_peso_desmama; 
	            $ultimo_peso = $reg_animal->tbl_animal_ultimo_peso; 

	            if ($ultimo_peso!=0 && $ultimo_peso!='') {
	                $peso = $ultimo_peso;
	            }
	            else if ($peso_desmama!=0 && $peso_desmama!='') {
	                $peso = $peso_desmama;
	            }
	            else if ($primeiro_peso!=0 && $primeiro_peso!=''){
	                $peso = $primeiro_peso;
	            }
	            else {
	                $peso = 0;
	            }
		    }

		    $incluir_pasto = incluir_pasto($conector, $codigo_local, $codigo_pasto, $nascimento, $sexo, $codigo_categoria);

		    if ($incluir_pasto!='Gravei') {
			    $valor[0]=9;
			    $valor[1]=$incluir_pasto;
			    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
			    die ($str);
		    }

			// Soma registro no fechamento mensal
			$data_hoje = date("Y-m-d");
			$partes_hoje = explode("-", $data_hoje);
			$anomes_inicial = $partes_hoje[0].$partes_hoje[1];

			$partes_mov = explode("-", $data_mov);
			$anomes_final = $partes_mov[0].$partes_mov[1];
			$diferenca = $anomes_inicial - $anomes_final;

			if ($diferenca!=0) {
				$date = new DateTime($data_mov);
				$date->modify('last day of this month');
				$data_fechamento = $date->format('Y-m-d');

				$tbl_fechamento = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque
			   		WHERE tbl_fechamento_local='$codigo_local' AND
			       		  tbl_fechamento_data='$data_fechamento' AND 
			       		  tbl_fechamento_categoria='$codigo_categoria' AND
			       		  tbl_fechamento_sexo='$sexo'");

				$num_rows = mysqli_num_rows($tbl_fechamento);    

				if ($num_rows!=0) {
					$reg = mysqli_fetch_object($tbl_fechamento);
					$fechamento_id = $reg->tbl_fechamento_id;
					$qtd_fechamento = $reg->tbl_fechamento_qtd;
    				$peso_fechamento = $reg->tbl_fechamento_peso;

					$qtd_fechamento++;
    				$peso_fechamento+=$peso;

					$sql = ("UPDATE tbl_fechamento_mensal_estoque SET 
							   		tbl_fechamento_qtd='$qtd_fechamento',
							   		tbl_fechamento_peso='$peso_fechamento'
					 	WHERE tbl_fechamento_id ='$fechamento_id'");

					$resultado = mysqli_query($conector,$sql);
					$erro_mysql = mysqli_error($conector);

					if (!$resultado) {
						$valor[0]=9;
		    			$valor[1]='Ocorreu um erro na alteração do fechamento mensal! ' . $erro_mysql;
		    			$str = $valor[0] . '<|>' . $valor[1] . '<|>';
						mysqli_close($conector);
		    			die ($str);
					}
			    }

				$tbl_fechamento_ent_sai = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque_ent_sai_peso
	        		WHERE tbl_fechamento_local='$codigo_local' AND
	              		  tbl_fechamento_data='$data_fechamento'");

	    		$num_rows = mysqli_num_rows($tbl_fechamento_ent_sai);    

	    		if ($num_rows!=0) {
	    			$reg = mysqli_fetch_object($tbl_fechamento_ent_sai);
	    			$fechamento_id = $reg->tbl_fechamento_id;
	    			$peso_ent_transferencia = $reg->tbl_fechamento_peso_ent_transferencia;
	    			$peso_ent_outra = $reg->tbl_fechamento_peso_ent_outras;
	    			$peso_morte = $reg->tbl_fechamento_peso_sai_morte;
	    			$peso_venda = $reg->tbl_fechamento_peso_sai_venda;
	    			$peso_sai_transferencia = $reg->tbl_fechamento_peso_sai_transferencia;
	    			$peso_sai_outra = $reg->tbl_fechamento_peso_sai_outras;
	    			$peso_final = $reg->tbl_fechamento_peso_final;

	                if ($ent_sai=='E') {
                    	if ($tipo=='T') {
	                        $peso_ent_transferencia-=$peso;
	                        $peso_final-=$peso;
	                    }
	                    else{
	                        $peso_ent_outra-=$peso;
	                        $peso_final-=$peso;
	                    }
	                }
	                else {
	                    if ($tipo=='M') {
	                        $peso_morte-=$peso;   
	                        $peso_final+=$peso;
	                    }
	                    else if ($tipo=='V') {
	                        $peso_venda-=$peso;
	                        $peso_final+=$peso;
	                    }
	                    else if ($tipo=='T') {
	                        $peso_sai_transferencia-=$peso;
	                        $peso_final+=$peso;
	                    }
	                    else {
	                        $peso_sai_outra-=$peso;
	                        $peso_final+=$peso;
	                    }
	                }

					$sql = ("UPDATE tbl_fechamento_mensal_estoque_ent_sai_peso SET 
							tbl_fechamento_peso_ent_transferencia='$peso_ent_transferencia',
							tbl_fechamento_peso_ent_outras='$peso_ent_outra',
					   		tbl_fechamento_peso_sai_morte='$peso_morte',
					   		tbl_fechamento_peso_sai_venda='$peso_venda',
					   		tbl_fechamento_peso_sai_transferencia='$peso_sai_transferencia',
					   		tbl_fechamento_peso_sai_outras='$peso_sai_outra',
					   		tbl_fechamento_peso_final='$peso_final'
					 	WHERE tbl_fechamento_id ='$fechamento_id'");

					$resultado = mysqli_query($conector,$sql);
					$erro_mysql = mysqli_error($conector);

					if (!$resultado) {
				   		header('Content-type: application/json');
				   		echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na alteração do fechamento mensal Ent/Sai' . $erro_mysql));
						mysqli_close($conector);
						exit;
					}
	    		}
			}

			// Fim Soma registro
		}
    }
    
    if ($tipo_mov==4) {
	    $tbl_estoque = mysqli_query($conector, "select * from tbl_movimentacao_estoque
	        where tbl_mov_estoque_codigo_movimentacao='$documento'"); 

	    while ($reg_estoque = mysqli_fetch_object($tbl_estoque)) {
		    $codigo_animal_id = $reg_estoque->tbl_mov_estoque_codigo_id_animal;
		    $nascimento = $reg_estoque->tbl_mov_estoque_nascimento;
			$sexo = $reg_estoque->tbl_mov_estoque_sexo;
		    $codigo_pasto = $reg_estoque->tbl_mov_estoque_codigo_pasto;
		    $codigo_local = $reg_estoque->tbl_mov_estoque_local;
			$data_mov = $reg_estoque->tbl_mov_estoque_data_emissao;
			$codigo_categoria = $reg_estoque->tbl_mov_estoque_codigo_categoria;
			$peso = $reg_estoque->tbl_mov_estoque_primeiro_peso;

		    $exclui_pasto = exclui_pasto($conector, $codigo_local, $codigo_pasto, $nascimento, $sexo);

		    if ($exclui_pasto=='Erro') {
			    $valor[0]=9;
			    $valor[1]='Erro ao excluir o animal no Curral de Entrada. Verifique se existem animais nesse curral.';
			    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
			    die ($str);
		    }

			$sql = ("DELETE FROM tbl_animais 
		  		WHERE tbl_animal_codigo_id='$codigo_animal_id'");	    		
			$resultado = mysqli_query($conector,$sql);

			// Subtrai registro no fechamento mensal
			$data_hoje = date("Y-m-d");
			$partes_hoje = explode("-", $data_hoje);
			$anomes_inicial = $partes_hoje[0].$partes_hoje[1];

			$partes_mov = explode("-", $data_mov);
			$anomes_final = $partes_mov[0].$partes_mov[1];
			$diferenca = $anomes_inicial - $anomes_final;

			if ($diferenca!=0) {
				$date = new DateTime($data_mov);
				$date->modify('last day of this month');
				$data_fechamento = $date->format('Y-m-d');

				$tbl_fechamento = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque
			   		WHERE tbl_fechamento_local='$codigo_local' AND
			       		  tbl_fechamento_data='$data_fechamento' AND 
			       		  tbl_fechamento_categoria='$codigo_categoria' AND
			       		  tbl_fechamento_sexo='$sexo'");

				$num_rows = mysqli_num_rows($tbl_fechamento);    

				if ($num_rows!=0) {
					$reg = mysqli_fetch_object($tbl_fechamento);
					$fechamento_id = $reg->tbl_fechamento_id;
					$qtd_fechamento = $reg->tbl_fechamento_qtd;
					$peso_fechamento = $reg->tbl_fechamento_peso;

					$qtd_fechamento--;
					$peso_fechamento-=$peso;

					$sql = ("UPDATE tbl_fechamento_mensal_estoque SET 
							   		tbl_fechamento_qtd='$qtd_fechamento',
							   		tbl_fechamento_peso='$peso_fechamento'
					 	WHERE tbl_fechamento_id ='$fechamento_id'");

					$resultado = mysqli_query($conector,$sql);
					$erro_mysql = mysqli_error($conector);

					if (!$resultado) {
						$valor[0]=9;
		    			$valor[1]='Ocorreu um erro na alteração do fechamento mensal! ' . $erro_mysql;
		    			$str = $valor[0] . '<|>' . $valor[1] . '<|>';
						mysqli_close($conector);
		    			die ($str);
					}
			    }

				$tbl_fechamento_ent_sai = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque_ent_sai_peso
	        		WHERE tbl_fechamento_local='$codigo_local' AND
	              		  tbl_fechamento_data='$data_fechamento'");

	    		$num_rows = mysqli_num_rows($tbl_fechamento_ent_sai);    

	    		if ($num_rows!=0) {
	    			$reg = mysqli_fetch_object($tbl_fechamento_ent_sai);
	    			$fechamento_id = $reg->tbl_fechamento_id;
	    			$peso_ent_compra = $reg->tbl_fechamento_peso_ent_compra;
	    			$peso_final = $reg->tbl_fechamento_peso_final;

                    $peso_ent_compra-=$peso;
                    $peso_final-=$peso;

					$sql = ("UPDATE tbl_fechamento_mensal_estoque_ent_sai_peso SET 
						tbl_fechamento_peso_ent_compra='$peso_ent_compra',
						tbl_fechamento_peso_final='$peso_final'
					 	WHERE tbl_fechamento_id ='$fechamento_id'");

					$resultado = mysqli_query($conector,$sql);
					$erro_mysql = mysqli_error($conector);

					if (!$resultado) {
				   		header('Content-type: application/json');
				   		echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na alteração do fechamento mensal Ent/Sai' . $erro_mysql));
						mysqli_close($conector);
						exit;
					}
	    		}
			}

			// Fim Subtrai registro
	    }

		$sql = ("DELETE FROM tbl_movimentacao_estoque 
			  WHERE tbl_mov_estoque_codigo_movimentacao='$documento'");
		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		    $valor[0]=9;
		    $valor[1]='Erro ao excluir o registro do item da movimentação estoque! ' . $erro_mysql;
		    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
		    die ($str);
		}
    }
    else {
		$sql = ("DELETE FROM tbl_movimentacao_estoque 
			  WHERE tbl_mov_estoque_codigo_movimentacao='$documento'");
		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		    $valor[0]=9;
		    $valor[1]='Erro ao excluir o registro do item da movimentação estoque! ' . $erro_mysql;
		    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
		    die ($str);
		}
    }    

	$sql = ("DELETE FROM tbl_item_movimentacao 
		  WHERE tbl_ite_movimentacao_numero_id='$documento'");
	$resultado = mysqli_query($conector,$sql);
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	    $valor[0]=9;
	    $valor[1]='Erro ao excluir o registro do item da movimentação! ' . $erro_mysql;
	    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	    die ($str);
	}

	$sql = ("DELETE FROM tbl_movimentacao 
			  WHERE tbl_movimentacao_id='$documento'");
	$resultado = mysqli_query($conector,$sql);
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	    $valor[0]=9;
	    $valor[1]='Erro ao excluir a movimentação! ' . $erro_mysql;
	    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	    die ($str);
	}

	$sql = "UPDATE tbl_pesagem SET
   			tbl_pesagem_codigo_movimentacao=0
	    WHERE tbl_pesagem_id ='$codigo_pesagem'";

	$resultado = mysqli_query($conector,$sql);
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	    $valor[0]=9;
	    $valor[1]='Não existe pesagem vinculada a essa movimentação! ' . $erro_mysql;
	    $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	    die ($str);
	}

	$valor[0]=0;
	$valor[1]='Registro estornado com sucesso! ';
	$str = $valor[0] . '<|>' . $valor[1] . '<|>';
	die ($str);

	mysqli_close($conector);

	function exclui_pasto($conector, $codigo_local, $codigo_pasto, $nascimento, $sexo) {

		$sql = ("DELETE FROM tbl_animal_pasto 
				  WHERE tbl_animal_pasto_local='$codigo_local' AND 
				  tbl_animal_pasto_id ='$codigo_pasto' AND 
			      tbl_animal_pasto_nascimento='$nascimento' AND 
			      tbl_animal_pasto_sexo='$sexo'");
		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado) {
			return 'Erro';
		}
		else {
			return '';
		}

	}

	function incluir_pasto($conector, $codigo_local, $codigo_pasto, $nascimento, $sexo, $codigo_categoria) {
       	$data_sistema = date("Y-m-d H:i:s");

		@ session_start(); 
		$nomeusuario = $_SESSION['nome_usuario'];
	    $controle_estoque = $_SESSION['controle_estoque'];
		
		$tbl_animal_pasto = mysqli_query($conector, "SELECT * FROM tbl_animal_pasto
		    WHERE tbl_animal_pasto_local ='$codigo_local' 
			    ORDER BY tbl_animal_pasto_numero_item DESC LIMIT 1");

		$num_rows_animal_pasto = mysqli_num_rows($tbl_animal_pasto);	

		if ($num_rows_animal_pasto!=0) {
			$reg_animal_pasto = mysqli_fetch_object($tbl_animal_pasto);
			$numero_item =  $reg_animal_pasto->tbl_animal_pasto_numero_item;
			$numero_item++;
		}
		else {
			$numero_item = 1;
		}

		$sql = "INSERT INTO tbl_animal_pasto (
			tbl_animal_pasto_local,
			tbl_animal_pasto_id,
			tbl_animal_pasto_numero_item,
			tbl_animal_pasto_nascimento,
			tbl_animal_pasto_sexo,
			tbl_animal_pasto_categoria,
			tbl_animal_pasto_raca,
			tbl_animal_pasto_situacao,
			tbl_animal_pasto_motivo_morte,
			tbl_animal_pasto_observacao,
			tbl_animal_pasto_incluido_em,
			tbl_animal_pasto_incluido_por,
			tbl_animal_pasto_baixado_em,
			tbl_animal_pasto_baixado_por
		    ) 
		    VALUES (
		   		'$codigo_local',
			    '$codigo_pasto',
			    '$numero_item',
			    '$nascimento',
			    '$sexo',
			    '$codigo_categoria',
			    null,
				'A',
				null,
				null,
		        '$data_sistema',
		        '$nomeusuario',
		        null,
		        null
		    )";
		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado) {
			return 'Erro ao inserir o animal no pasto ' . $erro_mysql;
		}
		else {
			return 'Gravei';
		}
	}

?>