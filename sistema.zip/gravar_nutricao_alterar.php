<?php 
include "conecta_mysql.inc";

$tipo_gravacao = $_POST['tipo_gravacao'];
$id_nutricao = $_POST['id_nutricao'];
$id_local = $_POST['id_local'];
$id_produto = $_POST['id_produto'];
$observacao = $_POST['observacao'];
$data_sistema = date("Y-m-d H:i:s");

if (empty($_POST['quantidade'])) {
	$quantidade = 0;
}
else {
	$quantidade = str_replace(',','.', str_replace('.','', $_POST['quantidade']));
}

if (empty($_POST['qtd_media'])) {
	$qtd_media = 0;
}
else {
	$qtd_media = str_replace(',','.', str_replace('.','', $_POST['qtd_media']));
}

if ($quantidade==0) {
	header('Content-type: application/json');
	echo json_encode(array('error' => true, 'message' => 'Informe a Quantidade.'));
	exit;
} 

@ session_start(); 
$nomeusuario = $_SESSION['nome_usuario'];

if ($tipo_gravacao==2){
	$sql = "DELETE FROM tbl_nutricao WHERE tbl_nutricao_id = '$id_nutricao'";

	$resultado = mysqli_query($conector,$sql);
	$resposta = array('success' => true, 'message' => 'Registro enviado para lixeira com sucesso.');
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	   	header('Content-type: application/json');
	   	echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro ao enviar o registro para a lixeira' . $erro_mysql));
	   	exit;
	} 
	else {
        $tbl_estoque = mysqli_query($conector, "SELECT * from tbl_produto_estoque
	            WHERE tbl_produto_estoque_codigo_id='$id_produto' AND 
	                  tbl_produto_estoque_codigo_local='$id_local' AND 
	                  tbl_produto_estoque_lixeira = 0"); 
        $num_rows = mysqli_num_rows($tbl_estoque);

        if ($num_rows!=0) {
            $reg_est = mysqli_fetch_object($tbl_estoque);
            $qtd_estoque = $reg_est->tbl_produto_estoque_atual;
            $qtd_estoque+= $quantidade;

            $sql = ("UPDATE tbl_produto_estoque SET
                            tbl_produto_estoque_atual='$qtd_estoque',
                            tbl_produto_estoque_alterado_em='$data_sistema',
                            tbl_produto_estoque_alterado_por='$nomeusuario'
                        WHERE tbl_produto_estoque_codigo_id='$id_produto' AND 
                              tbl_produto_estoque_codigo_local='$id_local'");

            $resultado = mysqli_query($conector,$sql);
            $erro_mysql = mysqli_error($conector);

            if (!$resultado){
                header('Content-type: application/json');
                echo json_encode(array('error' => $erro_mysql, 'message' => 'Erro na alteração do estoque - ' . $erro_mysql));
                exit;
            } 
            else {
                header('Content-type: application/json');
                echo json_encode($resposta);
            }
        }
        else {
            header('Content-type: application/json');
            echo json_encode(array('error' => true, 'message' => 'Estoque não encontrado para o produto/local'));
            exit;
        }
	}
}
/*else {
	$sql = ("UPDATE tbl_nutricao SET
				tbl_nutricao_quantidade_produto='$quantidade',
				tbl_nutricao_media_cabeca='$qtd_media',
				tbl_nutricao_observacao='$observacao',
				tbl_nutricao_alterado_em='$data_sistema',
				tbl_nutricao_alterado_por='$nomeusuario'
	 		WHERE tbl_nutricao_id='$id_nutricao'");

	$resultado = mysqli_query($conector,$sql);
	$resposta = array('success' => true, 'message' => 'Registro alterado com sucesso.');
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	   	header('Content-type: application/json');
	   	echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na alateração ' . $erro_mysql));
	} 
	else {
	   	header('Content-type: application/json');
	   	echo json_encode($resposta);
	}

	mysqli_close($conector);
	exit;
}*/

mysqli_close($conector);
exit;


?>