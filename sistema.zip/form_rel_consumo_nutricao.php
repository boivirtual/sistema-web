<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";
    $data_sistema = date("Y-m-d");

    @ session_start(); 

//    if ($_SESSION['data_inicio_ctp_rel']==0){
        $data_inicial = $data_sistema;
//    }
//    else {
//        $data_inicial =  $_SESSION['data_inicio_ctp_rel'];  
//    }

//    if ($_SESSION['data_fim_ctp_rel']==0){
        $data_final = $data_sistema;
//    }
//    else {
//        $data_final =  $_SESSION['data_fim_ctp_rel'];   
//    }

/*    if ($_SESSION['tipo_data_ctp_rel']==''){
        $tipo_data = "V";
    }
    else {
        $tipo_data =  $_SESSION['tipo_data_ctp_rel'];   
    }

    if ($_SESSION['tipo_rel_ctp_rel']==''){
        $tipo_rel = "S";
    }
    else {
        $tipo_rel =  $_SESSION['tipo_rel_ctp_rel'];     
    }
*/
    $local = mysqli_query($conector, "SELECT * FROM tbl_pessoa 
        WHERE tbl_pessoa_classe=4 AND tbl_pessoa_lixeira=0"); 

    $tbl_produto = mysqli_query($conector, "SELECT * FROM tbl_produto 
        INNER JOIN tabela_unidade_produtos
                ON tab_codigo_unidade_id = tbl_produto_unidade 
        INNER JOIN tbl_apresentacao_produtos
                ON tab_codigo_apresentacao_id = tbl_produto_apresentacao 
        WHERE tbl_produto_lixeira=0"); 

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" rel="stylesheet"  crossorigin="anonymous">

  <link href="css/jquery.dataTables.min.css" rel="stylesheet">
  <!--<link href="https://cdn.datatables.net/fixedcolumns/3.3.1/css/fixedColumns.dataTables.min.css" rel="stylesheet">-->
  <link href="css/tabela_1300.css" rel="stylesheet">
  <link rel="stylesheet" href="css/select-1.13.14.css"> 
</head>

<body>

  <?php

   @ session_start();   
    if(isset($_SESSION['menu_relatorios'])) {
        $array_relatorios = explode("!",$_SESSION['menu_relatorios']);

        if ($array_relatorios[0] == 0){
            echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
            echo '<strong class="negrito">Atenção! </strong><span>Você não tem acesso a esse programa!</span>';  
            echo '</div>';         
            exit;
        }
    }
    else {
        echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
        echo '<strong class="negrito">Atenção! </strong><span>Você não efetuol o login!</span>';  
        echo '</div>';         
        exit;
    }

    $codigo_usuario = $_SESSION['id_usuario'];

    $tbl_usuario = "SELECT * FROM usuario WHERE id_usuario = '$codigo_usuario' AND 
                                           lixeira_usuario=0 ";  
    $query = mysqli_query($conector_acesso, $tbl_usuario);

    $num_rows_usuario = mysqli_num_rows($query);

    if ($num_rows_usuario!=0){
        $reg_usuario = mysqli_fetch_assoc($query);

        $array_locais_usuario = explode(',', $reg_usuario['local_usuario']);
        $qtd_locais_usuario = count($array_locais_usuario);

        if ($qtd_locais_usuario==0) {
            $array_locais_usuario='';
        }
    }
    else {
        $array_locais_usuario='';
    }

?>

<!-- container section start -->
<section id="container" class="">

    <!--sidebar start-->
    <?php
        include "cabecalho.php";
        include "opcoes_menu.php";
    ?>
    <!--sidebar end-->

  <!-- container section start -->
  <section id="container" class="">

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Relatórios <i class="fa fa-angle-right seta-direita"></i><a class="voltar-menu" href="form_relatorios_produtivos.php">Relatórios Produtivos</a><i class="fa fa-angle-right seta-direita"></i>
            <span class="titulo">Consumo de Nutrição</span></span>

           <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><img src="img/nutricao.png"> Consumo de Nutrição</h3>
                </div>
            </div>

	        <div class="row">
		        <div class="col-lg-12">
                        <div class="row col-md-12 filtro_exibido" id="consulta_contas">
                            <form method="GET" action="#" enctype="multipart/form-data" >
                            
                                <div class="tab-panel ">
                                    <div class="tab-pane active">
                                        <fieldset class="scheduler-border " >
                                            <legend class="scheduler-border fonte-legend">Filtros</legend>
                                                
                                            <div class="row">
                                                <div class="form-group col-md-11">
                                                </div>

                                                <div class="form-group col-md-1">
                                                    <button type="button" class="form-control btn btn-info pull-right" onclick="voltar_relatorios()">Voltar
                                                    </button>
                                                </div>
                                            </div>                                                
                                            <div class="row ">
                                                <div class="form-group col-md-4">
                                                    <input type="hidden" name="lista_ao_entrar" id="lista_ao_entrar" value="S">  
                                                    
                                                    <label for="data_inicial" class="control-label"><span class="required">*</span> Data Incial</label>
                                                    <input name="data_inicial" type="date" class="form-control" id="data_inicial"
                                                    <?php //echo "value='".$data_inicial."'";?>>

                                                </div>

                                                <div class="form-group col-md-4">
                                                    <label for="data_final" class="control-label"><span class="required">*</span> Data Final</label>
                                                    <input name="data_final" type="date" class="form-control" id="data_final"
                                                    <?php //echo "value='".$data_final."'";?>>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="form-group col-md-8">
                                                    <label for="codigo_local_filtro" class="control-label">Fazenda</label>
                                                    <select class="form-control selectpicker" id="codigo_local_filtro" multiple name="codigo_local_filtro">

                                                    <?php 
                                                    while($reg_local = mysqli_fetch_object($local)) { 
                                                    
                                                        foreach ($array_locais_usuario as $value) {
                                                            $value = ltrim($value);
                                                            $value = rtrim($value);
                                                            if ($value==$reg_local->tbl_pessoa_id) {
                                                                echo '<option value="'.$value.'">' .$reg_local->tbl_pessoa_nome. '</option>'; 
                                                            }
                                                        }
                                                    } 
                                                    ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="form-group col-md-8">
                                                    <label for="codigo_produto_filtro" class="control-label">Produto</label>
                                                    <select class="form-control selectpicker" id="codigo_produto_filtro" multiple name="codigo_produto_filtro">

                                                    <?php 
                                                    while($reg_produto = mysqli_fetch_object($tbl_produto)) { 

                                                        $codigo = $reg_produto->tbl_produto_codigo_id;

                                                        $descricao_produto = $reg_produto->tbl_produto_descricao;
                                                        $unidade_consumo = $reg_produto->tab_codigo_unidade_produtos;
                                                        $apresentacao = $reg_produto->tab_descricao_apresentacao_produtos;
                                                        $qtd_unidade = $reg_produto->tbl_produto_qtd_unidade;
                                                        $descricao = $descricao_produto.' '.$apresentacao
                                                                         .' '.$qtd_unidade.' '.$unidade_consumo;

                                                        echo '<option value="'.$codigo.'">' .$descricao. '</option>';
                                                    } 
                                                    ?>
                                                    </select>
                                                </div>

                                                <div class="form-group col-md-1">
                                                    <label class="control-label">&nbsp;</label>
                                                    <button type="button" class="form-control btn btn-primary pull-right" onclick="listar_consumo_nutricao()">Listar
                                                    </button>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </form>
                        </div> 
    	        </div>
	        </div>

            <div class="modal fade" id="mensagem_erro" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Relatório Consumo de Nutrição - Mensagem</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" >Fechar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="aguardar" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <p class="aguardar">Aguarde <i class='fa fa-spinner fa-spin fa-2x' ></i></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	        <!-- page end-->
        </section>
    </section>

<!-- <div class="text-center">
     <div class="credits">
         <font size="2"><p style="color:#C0C0C0">Copyright &copy; Agrolandes 2021</p></font>
     </div>
 </div>
-->

</section> <!-- container section start end -->
  
<!-- javascripts -->

<script src="js/jquery.js?<?php echo Versao; ?>"></script>
<script src="js/jquery.nicescroll.js?<?php echo Versao; ?>" type="text/javascript"></script>
<script src="js/scripts.js?<?php echo Versao; ?>"></script>
<script src="js/nutricao.js?<?php echo Versao; ?>" charset="utf-8" type="text/javascript" ></script>
<script src="js/opcoes_menu.js?<?php echo Versao; ?>"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js?<?php echo Versao; ?>"></script>

<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js" charset="utf-8" type="text/javascript" >
</script>

<script src="js/select-1.13.14.js"></script>




