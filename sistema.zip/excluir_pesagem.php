<?php
	$documento = $_REQUEST['id'];
	$opcao = $_REQUEST['opcao'];
    $data_sistema = date("Y-m-d H:i:s");

	@ session_start(); 
    $nomeusuario = $_SESSION['nome_usuario'];

	include "conecta_mysql.inc";

	switch ($opcao) {
    case 0:
		$sql = ("UPDATE tbl_pesagem SET tbl_pesagem_lixeira='1',
			                        tbl_pesagem_lixeira_em='$data_sistema',
			                        tbl_pesagem_lixeira_por='$nomeusuario'
		                      WHERE tbl_pesagem_id='$documento'");

		$resultado = mysqli_query($conector,$sql);
		$mysql_erro = mysqli_error($conector);

		if (!$resultado){
	       $valor[0]=9;
	       $valor[1]='Erro ao enviar o registro para a lixeira! ' . $mysql_erro;
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
		else {
	       $valor[0]=0;
	       $valor[1]='Registro enviado para lixeira! ';
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
        break;
    case 1:
		$sql = ("DELETE FROM tbl_pesagem WHERE tbl_pesagem_id='$documento'");
		$resultado = mysqli_query($conector,$sql);

		$sql = ("DELETE FROM tbl_item_pesagem WHERE tbl_ite_pesagem_numero_id='$documento'");

		$resultado = mysqli_query($conector,$sql);
		$mysql_erro = mysqli_error($conector);

		if (!$resultado){
	       $valor[0]=9;
	       $valor[1]='Erro ao enviar o registro para a lixeira! ' . $mysql_erro;
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
		else {
	       $valor[0]=0;
	       $valor[1]='Registro enviado para lixeira! ';
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
        break;
    case 2:   
		$sql = ("UPDATE tbl_pesagem SET tbl_pesagem_lixeira='0',
			                        tbl_pesagem_lixeira_em=null,
			                        tbl_pesagem_lixeira_por=null
		                      WHERE tbl_pesagem_id='$documento'");

		$resultado = mysqli_query($conector,$sql);
		$mysql_erro = mysqli_error($conector);

		if (!$resultado){
	       $valor[0]=9;
	       $valor[1]='Erro ao resturar o registro da lixeira! ' . $mysql_erro;
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
		else {
	       $valor[0]=0;
	       $valor[1]='Registro restaurado da lixeira! ';
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
	  	break;
	} 
		

	mysqli_close($conector);

?>