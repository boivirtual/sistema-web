<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS 
  <link href="css/jquery-ui.css" rel="stylesheet" />-->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />

  <script src="https://kit.fontawesome.com/30604bf5d3.js" crossorigin="anonymous"></script>

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.22/r-2.2.6/datatables.min.css"/>

  <link rel="stylesheet" href="css/select-1.13.14.css"> 


</head>

<body>

  <?php

    @ session_start();

    if(isset($_SESSION['menu_manejo_animais'])) {
        $array_manejo = explode("!",$_SESSION['menu_manejo_animais']);

        if ($array_manejo[0] == 0){
            echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
            echo '<strong class="negrito">Atenção! </strong><span>Você não tem acesso a esse programa!</span>';  
            echo '</div>';         
            exit;
        }
    }
    else {
        echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
        echo '<strong class="negrito">Atenção! </strong><span>Você não efetuol o login!</span>';  
        echo '</div>';         
        exit;
    }

    $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_classe=4 and tbl_pessoa_lixeira=0"); 

    $codigo_usuario = $_SESSION['id_usuario'];

    $tbl_usuario = "SELECT * FROM usuario WHERE id_usuario = '$codigo_usuario' AND 
                                           lixeira_usuario=0 ";  
    $query = mysqli_query($conector_acesso, $tbl_usuario);

    $num_rows_usuario = mysqli_num_rows($query);

    if ($num_rows_usuario!=0){
        $reg_usuario = mysqli_fetch_assoc($query);

        $array_locais_usuario = explode(',', $reg_usuario['local_usuario']);
        $qtd_locais_usuario = count($array_locais_usuario);

        if ($qtd_locais_usuario==0) {
            $array_locais_usuario='';
        }
    }
    else {
        $array_locais_usuario='';
    }

    $wlocal = "";
    if (isset($_POST['local'])) {
        $codigo_local = $_POST['local'];

        if(in_array("", $codigo_local)) {
            $wlocal='';
        }
        else {
            $wlocal = " AND tbl_pasto_codigo_local IN(";
            $wlocal.= implode(',', $codigo_local);
            $wlocal.= ")";
            }
    }
    else {
        $wlocal='';
    }

?>

<!-- container section start -->
<section id="container" class="">

    <!--sidebar start-->
    <?php
        include "cabecalho.php";
        include "opcoes_menu.php";
    ?>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Animais <i class="fa fa-angle-right seta-direita"></i><a class="voltar-menu" href="form_mapa_gados.php"> Mapa de Gado</a> <i class="fa fa-angle-right seta-direita"></i>
            <span class="titulo">Movimentações</span></span>

            <a href="#" style="color: gray; margin-left: 10px;" data-toggle='tooltip' data-placement='right' title="Orientações de uso" onclick="informacoes_uso()"><i class="far fa-question-circle"></i></a>

           <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-retweet"></i> Mapa de Gado - Movimentações</h3>
                </div>
            </div>
          
            <div class="row">
                <div class="col-lg-12">
                    <div class="row table-responsive" id="consulta_mapa">

                    </div>
                </div>
            </div>

	        <!-- page end-->
            <div class='modal fade' id='mensagem_retorno_inclusao' tabindex='-1' role='dialog' 
                        aria-labelledby='myModalLabel' aria-hidden='true' data-backdrop='static'>
                <div class='modal-dialog modal-dialog-centered' role='document'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
                            <h4 class='modal-title'>Mapa de Gado - Nascimento </h4>
                        </div>
                        <div class='modal-body'></div>
                        <div class='modal-footer'>
                            <button class='btn btn-default' type='button' onclick='reseta_confirma(); ler_animal_nascimento();'>Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class='modal fade' id='mensagem_retorno_morte' tabindex='-1' role='dialog' 
                aria-labelledby='myModalLabel' aria-hidden='true' data-backdrop='static'>
                <div class='modal-dialog modal-dialog-centered' role='document'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
                            <h4 class='modal-title'>Mapa de Gado - Morte </h4>
                        </div>
                        <div class='modal-body'></div>
                        <div class='modal-footer'>
                            <button data-dismiss='modal' class='btn btn-default' type='button' onclick='reseta_confirma();abrir_modal_morte();'>Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_retorno" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Mapa de Gado</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" onclick='fecharNutricao()'>Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_erro" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Mapa de Gado - Mensagem</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" >Fechar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="nascimento_erro" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Nascimento - Mensagem</h4>
                        </div>
                        <div class="modal-body">
                            <p>Dias de Gestação ( <span id="calculo_dias_nascimento"></span> dias ) diferente do previsto (~ 282 dias)</p>    
                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-success" type="button" onclick="gravar_nascimento();">Confirmar Nascimento</button>

                            <button class="btn btn-danger" type="button" onclick="gravar_nascimento_monta_natural();">Substituir Cobertura</button>

                            <button data-dismiss="modal" class="btn btn-default" type="button" onclick="fechar_nascimento_erro();">Fechar</button>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="nascimento_gemelar" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Nascimento - Mensagem</h4>
                        </div>
                        <div class="modal-body">
                            <p>Fêmea já possui nascimento nessa estação!</p>    
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-success" onclick="volta_nascimento_mensagem();">Voltar e conferir a Fêmea</button>

                            <button type="button" class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Nascimento Gemelar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="nascimento_aborto_natimorto" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Nascimento - Mensagem</h4>
                        </div>
                        <div class="modal-body">
                            <p>Essa fêmea teve aborto ou natimorto nessa estação</p>    
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" onclick="volta_nascimento_mensagem();">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class='modal fade' id='modal_descricao_lote' tabindex='-1' role='dialog' 
                aria-labelledby='myModalLabel' aria-hidden='true' data-backdrop='static'>
                <div class='modal-dialog modal-dialog-centered' role='document'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
                            <h4 class='modal-title'>Movimentação Categoria/Cabeça</h4>
                        </div>
                        <div class='modal-body'>
                            <div class='row'>
                                <div class='form-group col-md-12'>

                                    <div class='alert alert-danger alert_descricao_lote' hidden='true'>
                                        <strong class='negrito'></strong><span></span>
                                    </div> 

                                    <label for='opcao_descricao' class='control-label' style='font-weight: bold;'><span class='required'>*</span> Quanto a DESCRIÇÃO de lote</label>

                                    <div class='clearfix'></div>

                                    <label class='radio-inline'>
                                    <input type='radio' name='opcao_descricao' value='1'>Manter neste pasto
                                    </label>

                                    <label class='radio-inline'>
                                    <input type='radio' name='opcao_descricao' value='2'>Mover para o pasto destino
                                    </label>
                                </div>
                            </div>

                        </div>
                        <div class='modal-footer'>
                            <button class='btn btn-success' type='button' onclick='reseta_confirma();confirmar_descricao_lote();'>Confirma</button>

                            <button data-dismiss='modal' class='btn btn-default' type='button'>Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="aguardar" tabindex="-1" role="dialog"    aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <p class="aguardar">Aguarde <i class='fa fa-spinner fa-spin fa-2x' ></i></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <?php
                    include "ajuda.php";
                ?>
            </div>

        </section>
        
    </section>

 <!--main content end-->
 <div class="text-center">
     <div class="credits">
         <font size="2"><p style="color:#C0C0C0">Copyright &copy; Boi Virtual 2023</p></font>
     </div>
 </div>

</section> <!-- container section start end -->
  
<!-- javascripts -->
<script src="js/jquery.js?<?php echo Versao; ?>"></script>
<script src="js/jquery.scrollTo.min.js?<?php echo Versao; ?>"></script>
<script src="js/jquery.nicescroll.js?<?php echo Versao; ?>" type="text/javascript"></script>
<script src="js/jquery-ui-1.9.2.custom.min.js?<?php echo Versao; ?>"></script>
<script src="js/ga.js?<?php echo Versao; ?>" type="text/javascript" ></script>
<script src="js/bootstrap-switch.js?<?php echo Versao; ?>"></script>
<script src="js/jquery.tagsinput.js?<?php echo Versao; ?>"></script>
<script src="js/jquery.hotkeys.js?<?php echo Versao; ?>"></script>
<script src="js/bootstrap-wysiwyg.js?<?php echo Versao; ?>"></script>
<script src="js/bootstrap-wysiwyg-custom.js?<?php echo Versao; ?>"></script>
<script src="js/moment.js?<?php echo Versao; ?>"></script>
<script src="js/scripts.js?<?php echo Versao; ?>"></script>

<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.22/r-2.2.6/datatables.min.js"></script>


<script src="https://igorescobar.github.io/jQuery-Mask-Plugin/js/jquery.mask.min.js?<?php echo Versao; ?>"></script> 

<script src="js/opcoes_menu.js?<?php echo Versao; ?>"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js?<?php echo Versao; ?>"></script>

<script src="js/select-1.13.14.js"></script>
<script src='js/typeahead.js'></script>

<script src='js/jquery.redirect.js'></script>

<script src="js/mapa_gados.js?<?php echo Versao; ?>" charset="utf-8" type="text/javascript" ></script>

<script>
    $(document).ready(function(){
 	   $('[data-toggle="tooltip"]').tooltip();   
    });
</script>

<script>
    $(document).ready(function(){
        $.ajax({
            type: 'post',
            url: 'monta_descricao_categoria.php',
            data: {
                'pasto_id': <?=$_POST['pasto_id']?>
            },
            success: function(data){
                $("div#consulta_mapa").html(data);
            }
        });
    });

</script>

</body>

</html>
