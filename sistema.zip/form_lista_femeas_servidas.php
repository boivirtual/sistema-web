<?php

include "conecta_mysql.inc";
$data_sistema = date("Y-m-d");

$codigo_local = $_POST["local"];
$tipo_cobertura = $_POST["tipo_cobertura"];
$id_estacao = $_POST["id_estacao"];

$previsao_parto_de = $_POST["previsao_parto_de"];
$previsao_parto_ate = $_POST["previsao_parto_ate"];

$diagnostico = $_POST["diagnostico"];

if ($previsao_parto_de=='') {
    $previsao_parto_de = '0000-00-00';
    $previsao_parto_ate = '9999-99-99';
}

$wsituacao  = "";
if (isset($_POST['situacao'])) {
    $situacao  = $_POST['situacao'];

    if(in_array("",  $situacao)) {
        $wsituacao ='';
    }
    else {
        $array_situacao = implode(',', $situacao);
        $array_situacao = explode(',', $array_situacao);

        if ($array_situacao[0]==' ') {
            $wsituacao  = " AND (tbl_ite_cobertura_nascido IN(";
            for ($i=0; $i < count($array_situacao); $i++) { 
                $wsituacao .= "'".$array_situacao[$i]."',";
            }
            $wsituacao = substr($wsituacao,0, -1);
            $wsituacao .= ") OR tbl_ite_cobertura_nascido IS NULL) ";
        }
        else {
            $wsituacao  = " AND tbl_ite_cobertura_nascido IN(";
            for ($i=0; $i < count($array_situacao); $i++) { 
                $wsituacao .= "'".$array_situacao[$i]."',";
            }
            $wsituacao = substr($wsituacao,0, -1);
            $wsituacao .= ") ";
        }
    }
}
else {
    $wsituacao ='';
}

if ($id_estacao==0) {
    $tbl_par = mysqli_query($conector, "SELECT * FROM tbl_parametro_estacao_monta 
                        WHERE tbl_par_codigo_local='$codigo_local' AND 
                              tbl_par_lixeira=0 AND 
                              tbl_par_estacao_monta_final>='$data_sistema'");  

    $num_rows = mysqli_num_rows($tbl_par);

    if ($num_rows!=0){
        $reg_para = mysqli_fetch_object($tbl_par);

        $id_estacao = $reg_para->tbl_par_estacao_id;
    }
}

$tbl_cobertura = mysqli_query($conector, "SELECT * FROM tbl_cobertura 
    INNER JOIN tbl_item_cobertura
            ON tbl_ite_cobertura_numero_id = tbl_cobertura_id
    INNER JOIN tbl_animais
            ON tbl_animal_codigo_id = tbl_ite_cobertura_codigo_id_animal
    WHERE tbl_cobertura_codigo_local = '$codigo_local' AND 
          tbl_cobertura_controle = 'C' AND 
          tbl_cobertura_codigo_estacao_monta = '$id_estacao' AND 
          tbl_cobertura_encerrada = 'S' AND
          tbl_ite_cobertura_resultado_diagnostico = '$diagnostico'" . $wsituacao .
    "ORDER BY tbl_ite_cobertura_codigo_animal ASC"); 

$num_rows_coberturas = mysqli_num_rows($tbl_cobertura);

if($num_rows_coberturas > 0){
    echo    '<div class="row">
                <div class="col-lg-12">
                    <section class="panel-group">
                        <form method="POST" action="#" enctype="multipart/form-data">

                            <div class="panel"> 
                                <div class=panel-body>
                                    <div class="tab-content">
                                        <div id="dados" class="tab-pane active">
                                            <div class="container" id="dados_cliente">';

        echo "<input type='hidden' id='local_id' value='$codigo_local'>";
        echo "<input type='hidden' id='estacao_id' value='$id_estacao'>";
        echo "<input type='hidden' id='diagnosticoT' value='$diagnostico'>";

        echo '<div class="row">
                <div class="form-group col-md-12">'; 
                if($diagnostico == 'P'){
                    echo '<button type="button" class="btn btn-default" onclick="listar_femeas_servidas_estacao(\'N\')">Ver Negativas</button>';
                }else{
                    echo '<button type="button" class="btn btn-default" onclick="listar_femeas_servidas_estacao(\'P\')">Ver Positivas</button>';
                }
        echo         '<button type="button" class="btn btn-success pull-right excel" style="margin-right: 6px;" 
                        onClick="listar_femeas_servidas_excel()">Excel</button>
                </div>
            </div>';

        echo '<table class="table table-striped table-advance table-hover" id="tabela_femeas_servidas" width="100%" style="font-size: 12px;">';

        echo "
        <thead>
            <tr>
                <th> Nº Fêmea</th>
                <th> Raça</th>
                <th style='text-align: center;'> Idade (meses)</th>
                <th style='text-align: center;'> Nº Partos</th>
                <th style='text-align: center;'> Nº Coberturas</th>
                <th style='text-align: center;'> Data Serviço</th>
                <th style='text-align: center;'> Semen</th>
                <th style='text-align: center;'> Previsão do Parto</th>";
                if($diagnostico == "P"){
                    echo "<th style='text-align: center;'> Confirma Diagnóstico?</th>";
                }
                else {
                    echo "<th style='text-align: center;'></th>";
                }
                echo "<th style='text-align: center;'> Qtd Diagnósticos</th>
                <th style='text-align: center;'> Nascido?</th>
            </tr>
        </thead>";

        echo '<tbody>';
            
            while($reg_cobertura = mysqli_fetch_object($tbl_cobertura)){
                $cobertura_id = $reg_cobertura->tbl_cobertura_id;
                $protocolo_id = $reg_cobertura->tbl_cobertura_protocoloiatf;
                $numero_item = $reg_cobertura->tbl_ite_cobertura_numero_item;
                $id_animal = $reg_cobertura->tbl_ite_cobertura_codigo_id_animal;
                $codigo_animal = $reg_cobertura->tbl_ite_cobertura_codigo_animal;
                $codigo_raca = $reg_cobertura->tbl_animal_codigo_raca;
                $num_coberturas = $reg_cobertura->tbl_animal_numero_coberturas;
                $qtd_diagnosticos = $reg_cobertura->tbl_ite_cobertura_qtd_diagnosticos_positivo;

                $nascido = $reg_cobertura->tbl_ite_cobertura_nascido;
                $nascido_outro = $reg_cobertura->tbl_ite_cobertura_situacao_femea_nascido_outro;

                switch ($nascido) {
                    case 'N':
                        $desc_nascido = 'Sim';
                        break;
                    case 'A':
                        $desc_nascido = 'Aborto';
                        break;
                    case 'M':
                       $desc_nascido = 'Natimorto';
                        break;
                    case 'O':
                       $desc_nascido = 'Outro';
                        break;
                    default:
                       $desc_nascido = '';
                       break;
                }

                if ($desc_nascido == 'Outro') {
                    switch ($nascido_outro) {
                        case 'V':
                            $desc_nascido = 'Fêmea Vendida';
                            break;
                        case 'M':
                            $desc_nascido = 'Fêmea Morreu';
                            break;
                        case 'O':
                           $desc_nascido = 'Fêmea Outra Saída';
                            break;
                        default:
                           $desc_nascido = 'Fêmea Outra Saída';
                           break;
                    }
                }

                $tbl_raca = mysqli_query($conector, "SELECT * FROM tabela_racas 
                                    WHERE tab_codigo_raca='$codigo_raca' AND 
                                          tab_registro_lixeira_raca=0");  

                $num_rows = mysqli_num_rows($tbl_raca);

                if ($num_rows!=0){
                    $reg_raca = mysqli_fetch_object($tbl_raca);

                    $desc_raca = $reg_raca->tab_descricao_raca;
                }
                else {
                    $desc_raca = '';
                }

                $data_nascimento= $reg_cobertura->tbl_animal_data_nascimento;
                $data_acompanhamento_calculo = date("Y-m-d");
                $date = new DateTime($data_nascimento); // Data de Nascimento
                $idade_acompanhamento = $date->diff(new DateTime($data_acompanhamento_calculo));
                $idade_acompanhamento_mostra_anos = $idade_acompanhamento->format('%Y')*12;
                $idade_acompanhamento_mostra_meses = $idade_acompanhamento->format('%m');
                $idade = $idade_acompanhamento_mostra_anos+$idade_acompanhamento_mostra_meses;

                $tbl_filhos = mysqli_query($conector,"select * from tbl_animais 
                                where tbl_animal_codigo_mae='$id_animal'
                                order by tbl_animal_codigo_numerico ASC"); 
                $numero_partos = mysqli_num_rows($tbl_filhos);

                $touro_semem = $reg_cobertura->tbl_ite_cobertura_codigo_touro_semen;

                if ($touro_semem!='') {
                    $semen = mysqli_query($conector, "select * from tbl_semem 
                                where tbl_semem_codigo_id='$touro_semem'"); 
                    $reg_semen = mysqli_fetch_object($semen);

                    $num_rows = mysqli_num_rows($semen);

                    if ($num_rows!=0) {
                        if($reg_semen->tbl_semem_nome == ""){
                            $desc_semen = $reg_semen->tbl_semem_codigo_alfa;
                        }
                        else {
                            $desc_semen = $reg_semen->tbl_semem_codigo_alfa .'-'. $reg_semen->tbl_semem_nome;
                        }
                    }
                    else {
                        $desc_semen = '';
                    }
                }
                else {
                    $desc_semen = '';   
                }

                $sql = mysqli_query($conector, "SELECT * FROM tbl_protocolo_cobertura 
                    WHERE tbl_protocolo_cobertura_codigo_id = '$cobertura_id'");
                $reg_protocolo_cobertura = mysqli_fetch_object($sql);

                $sql = mysqli_query($conector, "SELECT * FROM tbl_protocoloiatf 
                    WHERE tbl_protocoloiatf_id = '$protocolo_id' AND 
                          tbl_protocoloiatf_lixeira = 0");
                $reg_protocolo_iatf = mysqli_fetch_object($sql);

                $dias_diagnostico = $reg_protocolo_iatf->tbl_protocoloiatf_dias_diagnostico;

                $sql =  mysqli_query($conector,"SELECT * FROM tbl_item_protocoloiatf 
                    WHERE tbl_ite_protocoloiatf_lixeira = 0 AND 
                          tbl_ite_protocoloiatf_protocolo_id = '$protocolo_id' 
                    ORDER BY tbl_ite_protocoloiatf_id ASC");
        
                $dias_previsao_parto = 282;

                while($reg_itens = mysqli_fetch_object($sql)){
                    $dias = substr($reg_itens->tbl_ite_protocoloiatf_descricao, 3);

                    $data_servico = date("Y-m-d", strtotime($reg_protocolo_cobertura->tbl_protocolo_cobertura_data . "+{$dias} days"));

                    $data_previsao_parto = date("Y-m-d", strtotime($data_servico . "+{$dias_previsao_parto} days"));
                }

                $data_servico = date("d/m/Y", strtotime(str_replace('-', '/', $data_servico)));

                $data_previsao_parto_ed = date("d/m/Y", strtotime(str_replace('-', '/', $data_previsao_parto)));

                $cobertura_ordem = $cobertura_id . $numero_item;

                if ($data_previsao_parto>=$previsao_parto_de && 
                    $data_previsao_parto<=$previsao_parto_ate) {
                    echo "<tr>";
                    echo "<td width='10%'>".$codigo_animal."</td>";
                    echo "<td width='9%'>".$desc_raca."</td>";
                    echo "<td width='5%' align='center'>".$idade."</td>";
                    echo "<td width='5%' align='center'>".$numero_partos."</td>";
                    echo "<td width='9%' align='center'>".$num_coberturas."</td>";
                    echo "<td width='9%' align='center'>".$data_servico."</td>";
                    echo "<td width='9%'>".$desc_semen."</td>";
                    echo "<td width='9%' align='center'>".$data_previsao_parto_ed."</td>";
                    if($diagnostico == "P"){
                        if ($nascido=='N' || $nascido=='A' || $nascido=='M' || $nascido=='O') {
                            echo "<td width='17%' align='center'> 
                                <label><input type='radio' name='resultado$cobertura_ordem' id='resultadoP$cobertura_ordem' value='P' disabled> Sim</label>&nbsp;&nbsp;
                                
                                <label><input type='radio' name='resultado$cobertura_ordem' id='resultadoN$cobertura_ordem' value='N' disabled> Não</label>
                                </td>";
                        }
                        else {
                            echo "<td width='17%' align='center'> 
                                <label><input type='radio' name='resultado$cobertura_ordem' id='resultadoP$cobertura_ordem' value='P' onclick='gravar_diagnostico_positivo_femeas_servidas(this.id, this.value)'> Sim</label>&nbsp;&nbsp;
    
                                <label><input type='radio' name='resultado$cobertura_ordem' id='resultadoN$cobertura_ordem' value='N' onclick='resultadoCobertura(this.id, this.value)'> Não</label>
    
                                <input type='hidden' id='id_cobertura$cobertura_ordem' value='$cobertura_id'>
                                <input type='hidden' id='animal_id$cobertura_ordem' value='$id_animal'>
                                <input type='hidden' id='animal_codigo$cobertura_ordem' value='$codigo_animal'>
                                </td>";
                        }
                    }
                    else {
                        echo "<td width='9%'></td>";
                    }
                    echo "<td width='9%' align='center' id='qtd_diagnosticos$cobertura_ordem'>".$qtd_diagnosticos."</td>";
                    echo "<td width='9%'>".$desc_nascido."</td>";
                    echo "</tr>";

                }
            }

        echo '</tbody>';

        echo "</table>";

        echo '<div class="row">
                <div class="form-group col-md-12">  
                    <button type="button" class="btn btn-success pull-right excel" style="margin-right: 6px;" 
                        onClick="listar_femeas_servidas_excel()">Excel</button>
                </div>
            </div>';
}

echo '</div> 
        </div> 
            </div> 
                </div> 
                    </div> 
                        </form>
                          </section> 
                            </div> 
                                </div> ';

//echo "</section>";
echo '<script src="js/cobertura.js" charset="utf-8" type="text/javascript"></script>'; 

?>

            
                
