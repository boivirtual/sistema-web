<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";

    $data_sistema = date("Y-m-d");
    @ session_start(); 

    $local_filtro = $_REQUEST["local"];
    $produto_filtro = $_REQUEST["produto"];
    $data_inicial = $_REQUEST['data_inicial'];
    $data_final = $_REQUEST['data_final'];

    $local= array();
    $matriz_itens = explode(",", $local_filtro);
    $quantidade_itens = count($matriz_itens);

    for($i=0; $i < $quantidade_itens; $i++) {
        $local[$i]=$matriz_itens[$i];
    }

    $local = implode(',', $local);
    $local = substr($local,0, -1);

    $wlocal = '';

    if ($local_filtro!='') {
        $wlocal = " AND tbl_nutricao_codigo_local IN(";
        $wlocal.= $local;
        $wlocal.= ")";
    }

    $produto= array();
    $matriz_itens = explode(",", $produto_filtro);
    $quantidade_itens = count($matriz_itens);

    for($i=0; $i < $quantidade_itens; $i++) {
        $produto[$i]=$matriz_itens[$i];
    }

    $produto = implode(',', $produto);
    $produto = substr($produto,0, -1);

    $wproduto = '';

    if ($produto_filtro!='') {
        $wproduto = " AND tbl_nutricao_codigo_produto IN(";
        $wproduto.= $produto;
        $wproduto.= ")";
    }

    $descricao_filtro= $_REQUEST["descricao_filtro"];

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS 
  <link href="css/jquery-ui.css" rel="stylesheet" />-->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/style.css?<?php echo Versao;?>" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />

  <script src="https://kit.fontawesome.com/30604bf5d3.js" crossorigin="anonymous"></script>

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.22/r-2.2.6/datatables.min.css"/>

  <link rel="stylesheet" href="css/select-1.13.14.css"> 

<style type="text/css">
    table.dataTable thead th { border-bottom: 0;}
</style>

</head>

<body>
    <section id="container" class="">
        <?php
            include "cabecalho.php";
            include "opcoes_menu.php";
        ?>
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Relatórios <i class="fa fa-angle-right seta-direita"></i><a class="voltar-menu" href="form_relatorios_produtivos.php">Relatórios Produtivos</a><i class="fa fa-angle-right seta-direita"></i>
            <span class="titulo">Consumo de Nutrição</span></span>

            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><img src="img/nutricao.png"> Consumo de Nutrição</h3>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel-group">
                        <form method="POST" action="#" enctype="multipart/form-data">

                            <div class="panel"> 
                                <div class=panel-body>
                                    <div class="tab-content">
                                        <div id="dados" class="tab-pane active">
                                            <div class="container" id="dados_cliente">

                                                <input type="hidden" id="expande_tela" value="S">

                                                <input type="hidden" id="codigo_local_filtro"
                                                    <?php echo "value='".$local_filtro."'";?>>

                                                <input type="hidden" id="codigo_produto_filtro"
                                                    <?php echo "value='".$produto_filtro."'";?>>

                                                <input type="hidden" id="data_inicial"
                                                    <?php echo "value='".$data_inicial."'";?>>

                                                <input type="hidden" id="data_final"
                                                    <?php echo "value='".$data_final."'";?>>

                                                <input type="hidden" id="descricao_filtro"
                                                    <?php echo "value='".$descricao_filtro."'";?>>

                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <label class="label_consulta_rel">Filtros:</label>
                                                        <span><?php echo $descricao_filtro;?></span>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <button type="button" class="btn btn-info pull-right" onclick="voltar_filtro()">Voltar
                                                        </button>

                                                        <button type="button" class="btn btn-success pull-right" style="margin-right: 6px;" 
                                                        onClick="lista_consumo_nutricao_excel()">Excel</button>
                                                    </div>
                                                </div>

<table class="table table-striped table-advance table-hover" id="tabela_itens_consulta" width="100%" style="font-size: 10px;">

<tbody>

<?php
    $tbl_nutricao = mysqli_query($conector, "SELECT * from tbl_nutricao
        INNER JOIN tbl_pessoa
                ON tbl_nutricao_codigo_local = tbl_pessoa_id
        INNER JOIN tbl_produto
                ON tbl_nutricao_codigo_produto = tbl_produto_codigo_id 
        INNER JOIN tabela_unidade_produtos
                ON tab_codigo_unidade_id = tbl_produto_unidade 
        INNER JOIN tbl_apresentacao_produtos
                ON tab_codigo_apresentacao_id = tbl_produto_apresentacao 

        WHERE tbl_nutricao_lixeira=0 AND 
              tbl_nutricao_data>='$data_inicial' AND 
              tbl_nutricao_data<='$data_final'" . $wlocal . $wproduto .
        " ORDER BY tbl_nutricao_codigo_local, tbl_nutricao_codigo_produto ASC"); 

    $num_rows_nutricao = mysqli_num_rows($tbl_nutricao);

    $local_anterior = 0;
    $produto_anterior = 0;
    $total_produto = 0;
    $qtd_media = 0;
    $total_media = 0;

    if ($num_rows_nutricao!=0) {
        while ($reg_nutricao = mysqli_fetch_object($tbl_nutricao)) {
            $quantidade = $reg_nutricao->tbl_nutricao_quantidade_produto;
            $media_cabeca = $reg_nutricao->tbl_nutricao_media_cabeca;
            $codigo_local = $reg_nutricao->tbl_nutricao_codigo_local;
            $codigo_produto = $reg_nutricao->tbl_nutricao_codigo_produto;

            if ($local_anterior!=$codigo_local) {
                if ($local_anterior==0) {
                    $local_anterior=$reg_nutricao->tbl_nutricao_codigo_local;
                                $nome_fazenda = $reg_nutricao->tbl_pessoa_nome; 
                    $produto_anterior=$codigo_produto;
                    $descricao_produto = $reg_nutricao->tbl_produto_descricao;
                    $unidade_consumo = $reg_nutricao->tab_codigo_unidade_produtos;
                    $apresentacao = $reg_nutricao->tab_descricao_apresentacao_produtos;
                    $qtd_unidade = $reg_nutricao->tbl_produto_qtd_unidade;

                    $descricao_completa = $descricao_produto.' '.$apresentacao
                                                      .' '.$qtd_unidade.' '.$unidade_consumo;
                    $total_produto+=$quantidade; 
                    $qtd_media++;;
                    $total_media+=$media_cabeca;  
                }
                else {
                                //if ($produto_anterior!=$codigo_produto) {
                    $total_media = $total_media/$qtd_media;
                    echo '<tr>';
                    echo '<td width="25%">'.$nome_fazenda.'</td>';
                    echo '<td width="25%">'.$descricao_completa.'</td>';
                    echo '<td width="10%" style="text-align: right;">'.$total_produto.' '.$unidade_consumo.'</td>';
                    echo '<td width="10%" style="text-align: right;">'.number_format($total_media,2,',','.').' '.$unidade_consumo.'</td>';
                    echo '</tr>';                        

                    $local_anterior=$reg_nutricao->tbl_nutricao_codigo_local;
                    $nome_fazenda = $reg_nutricao->tbl_pessoa_nome; 
                    $total_produto = 0;
                    $qtd_media = 0;
                    $total_media = 0;
                    $qtd_media++;
                    $total_media+=$media_cabeca;  
                    $total_produto+=$quantidade;  
                    $produto_anterior=$codigo_produto;
                    $descricao_produto = $reg_nutricao->tbl_produto_descricao;
                                    $unidade_consumo = $reg_nutricao->tab_codigo_unidade_produtos;
                    $apresentacao = $reg_nutricao->tab_descricao_apresentacao_produtos;
                    $qtd_unidade = $reg_nutricao->tbl_produto_qtd_unidade;

                    $descricao_completa = $descricao_produto.' '.$apresentacao
                                                          .' '.$qtd_unidade.' '.$unidade_consumo;
                }
            }
            else {
                if ($produto_anterior!=$codigo_produto) {
                    $total_media = $total_media/$qtd_media;
                    echo '<tr>';
                    echo '<td width="25%">'.$nome_fazenda.'</td>';
                    echo '<td width="25%">'.$descricao_completa.'</td>';
                    echo '<td width="10%" style="text-align: right;">'.$total_produto.' '.$unidade_consumo.'</td>';
                    echo '<td width="10%" style="text-align: right;">'.number_format($total_media,2,',','.').' '.$unidade_consumo.'</td>';
                    echo '</tr>';                        

                    $local_anterior=$reg_nutricao->tbl_nutricao_codigo_local;
                                $nome_fazenda = $reg_nutricao->tbl_pessoa_nome; 
                    $total_produto = 0;
                    $qtd_media = 0;
                    $total_media = 0;
                    $qtd_media++;
                    $total_media+=$media_cabeca;  
                    $total_produto+=$quantidade;  
                    $produto_anterior=$codigo_produto;
                    $descricao_produto = $reg_nutricao->tbl_produto_descricao;
                    $unidade_consumo = $reg_nutricao->tab_codigo_unidade_produtos;
                    $apresentacao = $reg_nutricao->tab_descricao_apresentacao_produtos;
                    $qtd_unidade = $reg_nutricao->tbl_produto_qtd_unidade;

                    $descricao_completa = $descricao_produto.' '.$apresentacao
                                                      .' '.$qtd_unidade.' '.$unidade_consumo;
                }
                else {
                    $qtd_media++;
                    $total_media+=$media_cabeca;  
                    $total_produto+=$quantidade;  
                } 
            }
        }

        $total_media = $total_media/$qtd_media;
        echo '<tr>';
        echo '<td width="25%">'.$nome_fazenda.'</td>';
        echo '<td width="25%">'.$descricao_completa.'</td>';
        echo '<td width="10%" style="text-align: right;">'.$total_produto.' '.$unidade_consumo.'</td>';
        echo '<td width="10%" style="text-align: right;">'.number_format($total_media,2,',','.').' '.$unidade_consumo.'</td>';
        echo '</tr>';                        
    }

    echo '
    <script type="text/javascript">
        $("#aguardar").modal("hide");
    </script>
    ';
?>

</tbody>

<thead>
    <tr>
        <th>Fazenda</th>
        <th>Produto</th>
        <th>Consumo Total</th>
        <th>Consumo/Cabeça</th>
    </tr>

</thead>
</table>
                                            <div class="row">  
                                                <div class="col-md-12">
                                                <button type="button" class="btn btn-info pull-right" onclick="voltar_filtro()">Voltar
                                                </button>

                                                <button type="button" class="btn btn-success pull-right" style="margin-right: 6px;" 
                                                onClick="lista_consumo_nutricao_excel()">Excel</button>
                                                </div>
                                            </div>

                                            </div> <!-- fim container -->
                                        </div> <!-- dados-->
                                    </div> <!--tab-content -->

                                </div> <!--panel-body -->
                            </div> <!--panel -->      
                        </form>
                    </section> <!-- panel-group -->
                </div> <!--col-lg-12 2-->
            </div> <!--row 2-->

            <div class="modal fade" id="mensagem_retorno" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Relatório Consumo de Nutrição</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                        <button data-dismiss="modal" class="btn btn-default" type="button" onclick="finalizar_sair();">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_erro" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Relatório Consumo de Nutrição - Mensagem</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" >Fechar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="aguardar" tabindex="-1" role="dialog"    aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <p class="aguardar">Aguarde <i class='fa fa-spinner fa-spin fa-2x' ></i></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> <!-- wrapper -->
    </section><!--main-content -->


<?php 
  $javascript_file_name = 'nutricao.js';
  require 'rodape.php';
?>




