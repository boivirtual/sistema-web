<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";

    function diferenca_data($data_validade) {
            
    $data_inicial = $data_sistema = date("Y-m-d H:i:s");;
    $data_final = $data_validade;
    $time_inicial = strtotime($data_inicial);
    $time_final = strtotime($data_final);
    $diferenca = $time_final - $time_inicial; 
    $dias = (int)floor( $diferenca / (60 * 60 * 24)); 
    return $dias;
    }

    $conta_pagamento = mysqli_query($conector, "select * from tbl_conta_pagamento where tbl_conta_pagamento_lixeira=0"); 

    $conta_pagamento_individual = mysqli_query($conector, "select * from tbl_conta_pagamento where tbl_conta_pagamento_lixeira=0"); 

    $c_custo = mysqli_query($conector, "select * from tbl_centro_custo where tbl_cc_lixeira=0 order by tbl_cc_codigo_id ASC"); 

    $fornecedor = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_lixeira=0 and (tbl_pessoa_classe=3 or tbl_pessoa_classe=5) order by tbl_pessoa_nome ASC"); 

    $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_classe=4 and tbl_pessoa_lixeira=0"); 

  	$data_sistema = date("Y-m-d");

    $codigo_usuario = $_SESSION['id_usuario'];

    $tbl_usuario = "SELECT * FROM usuario 
        WHERE id_usuario = '$codigo_usuario' AND 
              lixeira_usuario=0 ";  
    $query = mysqli_query($conector_acesso, $tbl_usuario);

    $num_rows_usuario = mysqli_num_rows($query);

    if ($num_rows_usuario!=0){
        $reg_usuario = mysqli_fetch_assoc($query);

        $array_locais_usuario = explode(',', $reg_usuario['local_usuario']);
        $qtd_locais_usuario = count($array_locais_usuario);

        if ($qtd_locais_usuario==0) {
            $array_locais_usuario='';
        }
    }
    else {
        $array_locais_usuario='';
    }

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS -->
  <link href="css/jquery-ui.css" rel="stylesheet" />
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <link href="css/daterangepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-colorpicker.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="DataTables-1.10.18/css/dataTables.bootstrap4.min.css"rel="stylesheet" >
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

  <link rel="stylesheet" href="css/select-1.13.14.css"> 

</head>

<body>

  <?php

   @ session_start();   
    if(isset($_SESSION['menu_gestao_adm'])) {
        $array_gestao_adm = explode("!",$_SESSION['menu_gestao_adm']);

        if ($array_gestao_adm[1] == 0){
            echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
            echo '<strong class="negrito">Atenção! </strong><span>Você não tem acesso a esse programa!</span>';  
            echo '</div>';         
            exit;
        }
    }
    else {
        echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
        echo '<strong class="negrito">Atenção! </strong><span>Você não efetuol o login!</span>';  
        echo '</div>';         
        exit;
    }

    if ($_SESSION['data_inicio_ctp']==0){
      $data_inicial = $data_sistema;
    }
    else {
      $data_inicial =  $_SESSION['data_inicio_ctp'];  
    }

    if ($_SESSION['data_fim_ctp']==0){
      $data_final = $data_sistema;
    }
    else {
      $data_final =  $_SESSION['data_fim_ctp'];   
    }

    if ($_SESSION['tipo_data_ctp']==''){
      $tipo_data = "V";
    }
    else {
      $tipo_data =  $_SESSION['tipo_data_ctp'];   
    }

    if ($_SESSION['razao_nome_ctp']==''){
        $razao_nome = "";
    }
    else {
        $razao_nome = $_SESSION['razao_nome_ctp'];  
    }

    if ($_SESSION['codigo_c_custo_ctp']==0){
        $codigo_c_custo = 0;
    }
    else {
        $codigo_c_custo = $_SESSION['codigo_c_custo_ctp'];  
    }

    $array_fornecedor= '';

?>

<!-- container section start -->
<section id="container" class="">

    <!--sidebar start-->
    <?php
        include "cabecalho.php";
        include "opcoes_menu.php";
    ?>
    <!--sidebar end-->


    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Gestão Administrativa <i class="fa fa-angle-right seta-direita"></i>
            <span class="titulo">Contas a Pagar</span></span>

            <a href="#" style="color: gray; margin-left: 10px;" data-toggle='tooltip' data-placement='right' title="Orientações de uso" onclick="informacoes_uso()"><i class="far fa-question-circle"></i></a>

           <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fas fa-search-dollar"></i> Contas a Pagar</h3>
                </div>
            </div>

	        <div class="row">
		        <div class="col-lg-12">
                    <div  class="form-group opcoes_topo">
                        <a href="form_contas_pagar_incluir.php">
                            <input type="button" class="btn btn-primary" aria-label="Left Align" value="Incluir Nova"/>
                        </a>

                        <?php

                            @ session_start();   
                            if(isset($_SESSION['menu_gestao_adm'])) {
                                $array_gestao_adm = explode("!",$_SESSION['menu_gestao_adm']);

                                if ($array_gestao_adm[2] == 1){
                                    echo '<a href="form_contas_pagar_aceite.php">';
                                    echo '<input type="button" class="btn btn-info pull-right" aria-label="Left Align" 
                                          value="Aceite de Contas"/>';
                                    echo '</a>';
                                }
                            }
                        ?>                            
                    </div> 

                    <div class="row col-md-12" id="consulta_contas">
                        <form method="GET" action="form_contas_pagar.php" enctype="multipart/form-data" >
                            
                            <div class="tab-panel">
                                <div class="tab-pane active">
                                    <input id="lista_ctp_automatico" type="hidden"
                                    <?php echo "value='".$_SESSION['lista_ctp']."'";?>>

                                    <fieldset class="scheduler-border" id="dados_consulta">
                                        <legend class="scheduler-border fonte-legend">Dados para Consultar</legend>
                                        <div class="row ">
                                            <div class="form-group col-md-3">
                                                <label for="data_inicial" class="control-label">Data Incial</label>
                                                <input name="data_inicial" type="date" class="form-control" id="data_inicial"
                                                    <?php echo "value='".$data_inicial."'";?>>
                                            </div>

                                            <div class="form-group col-md-3">
                                                <label for="data_final" class="control-label">Data Final</label>
                                                <input name="data_final" type="date" class="form-control" id="data_final"
                                                    <?php echo "value='".$data_final."'";?>>
                                            </div>

                                            <div class="form-group">
                                                <label for="tipo_data" class="control-label">Tipo de Data</label>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label class="radio-inline">
                                                <input type="radio" name="tipo_data" value="V"   
                                                      checked="true" <?php if ($tipo_data == 'V'){echo "checked";}?>> Vencimento 
                                                </label>
                                                <label class="radio-inline">
                                                <input type="radio" name="tipo_data" value="E"
                                                       <?php if ($tipo_data == 'E'){echo "checked";}?>> Emissão
                                                </label>
                                                <label class="radio-inline">
                                                <input type="radio" name="tipo_data" value="P"
                                                       <?php if ($tipo_data == 'P'){echo "checked";}?> > Pagamento
                                                </label>
                                            </div>    
                                        </div>

                                        <div class="row">
                                            <div class="form-group col-md-4">
                                                <label for="razao_nome" class="control-label">Razão/Nome</label>
                                                <select class="form-control selectpicker" multiple data-live-search="true" name="razao_nome" id="razao_nome">

                                                <?php 
                                                    while($reg_for = mysqli_fetch_object($fornecedor)) { 
                                                    
//foreach ($array_fornecedor as $value) {
  //  $value = ltrim($value);
  //  $value = rtrim($value);
    
  //  if ($value==$reg_for->tbl_pessoa_id) {
        echo '<option value="'.$reg_for->tbl_pessoa_id.'">' .$reg_for->tbl_pessoa_nome. '</option>'; 
  //  }
//}
                                                    } 
                                                 ?>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label for="codigo_fazenda" class="control-label">Fazenda</label>
                                                <select class="form-control selectpicker" id="codigo_fazenda" multiple name="codigo_fazenda">
                                                <?php 
                                                    while($reg_local = mysqli_fetch_object($tbl_local)) { 
                                                    
                                                        foreach ($array_locais_usuario as $value) {
                                                            $value = ltrim($value);
                                                            $value = rtrim($value);
                                                            if ($value==$reg_local->tbl_pessoa_id) {
                                                                echo '<option value="'.$value.'">' .$reg_local->tbl_pessoa_nome. '</option>'; 
                                                            }
                                                        }
                                                    } 
                                                 ?>

                                                </select>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label for="codigo_cc" class="control-label">Centro de Custo</label>
                                                <select class="form-control" id="codigo_cc" name="codigo_cc">
                                                      
                                                <option value="0" selected="selected">Todos</option>

                                                <?php while($registo_cc = mysqli_fetch_object($c_custo)) { ?>

                                                <option value="<?php 
                                                   echo $registo_cc->tbl_cc_codigo_id ?>"

                                                <?php 
                                                    if($registo_cc->tbl_cc_codigo_id==$codigo_c_custo) 
                                                             { echo "selected"; }
                                                ?>>
                                                        
                                                <?php 
                                                    echo $registo_cc->tbl_cc_descricao;
                                                ?>
                                                </option>
                                                <?php } ?>

                                                </select>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="form-group col-md-12">
                                                <button type="button" class="btn btn-info pull-right" onclick="consultar_ctp()" >Consultar</button>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </form>
                    </div>    

                    <div id="lista_contas_pagar"></div>
    	        </div>
	        </div>

            <!-- page end-->
            <!-- modal baixa das contas selecionadas-->
            <div class="modal fade dados_baixa" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Contas a Pagar - Baixar Registros</h4>
                        </div>

                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="total_baixar" class="control-label">Valor total para baixar</label>
                                    <input name="total_baixar" type="text" class="form-control" id="total_baixar" readonly="">
                                </div>

                                <div class="form-group">
                                    <label for="data_pagamento" class="control-label">Data para Pagamento</label>
                                    <input name="data_pagamento" type="date" class="form-control" id="data_pagamento">
                                </div>

                                <div class="form-group">
                                    <label for="codigo_forma_rec" class="control-label">Conta Pagamento</label>
                                    <select class="form-control" id="codigo_forma_rec" name="codigo_forma_rec" >

                                    <option value="00" selected="selected">...</option>

                                    <?php while($reg_conta_pag = mysqli_fetch_object($conta_pagamento)) { ?>

                                    <option value="<?php 
                                        echo $reg_conta_pag->tbl_conta_pagamento_id ?>">
                                                    
                                        <?php 
                                            echo $reg_conta_pag->tbl_conta_pagamento_descricao;
                                        ?>
                                    </option>
                                    <?php } ?>
                                    </select>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-12">

                                        <button type="button" class="btn btn-primary pull-left" id="baixar_selecionadas"
                                            onClick="baixar_contas_selecionadas()">Confirme a Baixa
                                        </button>
                                        
                                        <button data-dismiss="modal" class="btn btn-info pull-right fecha_dados_baixa" type="button">Fechar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- modal baixa conta individual-->

            <div class="modal fade" id="modal_baixar" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Contas a Pagar - Baixar Registro</h4>
                        </div>

                        <div class="modal-body">
                            <form>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="number_doc_baixar" class="control-label">Nº Documento</label>
                                        <input name="number_doc_baixar" type="number" class="form-control" id="number_doc_baixar" data-toggle='tooltip' data-placement='top'  title="Caso não tenha o Nº, o sistema irá criar um automaticamente">
                                        <input name="chave_ind" type="hidden" class="form-control" id="chave_ind" readonly="">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="number_parcela_baixar" class="control-label">Parcela</label>
                                        <input name="number_parcela_baixar" type="text" class="form-control" id="number_parcela_baixar" readonly="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="vlr_total_baixar" class="control-label">Valor total para baixar</label>
                                    <input name="vlr_total_baixar" type="text" class="form-control" id="vlr_total_baixar" readonly="">

                                </div>

                                <div class="form-group">
                                    <label for="data_pagamento_baixar" class="control-label">Data para Pagamento</label>
                                    <input name="data_pagamento_baixar" type="date" class="form-control" id="data_pagamento_baixar">
                                </div>

                                <div class="form-group">
                                    <label for="codigo_forma_pagto_baixar" class="control-label">Conta Pagamento</label>
                                    <select class="form-control" id="codigo_forma_pagto_baixar" name="codigo_forma_pagto_baixar" >

                                    <option value="00" selected="selected">...</option>

                                    <?php while($reg_conta_pag = mysqli_fetch_object($conta_pagamento_individual)) { ?>

                                    <option value="<?php 
                                        echo $reg_conta_pag->tbl_conta_pagamento_id ?>">
                                                    
                                        <?php 
                                            echo $reg_conta_pag->tbl_conta_pagamento_descricao;
                                        ?>
                                    </option>
                                    <?php } ?>
                                    </select>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-12">

                                        <button type="button" class="btn btn-primary pull-left" id="baixar_selecionadas"
                                            onClick="baixar_conta_selecionada()" >Confirme a Baixa</button>
                                        
                                        <button data-dismiss="modal" class="btn btn-info pull-right" type="button" >Fechar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_retorno" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Contas a Pagar</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" onclick="location.reload();">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_erro" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Contas a Pagar - Erro</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" >Fechar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="aguardar" tabindex="-1" role="dialog"    aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <p class="aguardar">Aguarde <i class='fa fa-spinner fa-spin fa-2x' ></i></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <?php
                    include "ajuda.php";
                ?>
            </div>
            <!-- page end-->

        </section>
    </section>
</section>

<?php 
  $javascript_file_name = 'contas_pagar.js';
  require 'rodape.php';
?>



                
                
