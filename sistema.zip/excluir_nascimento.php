<?php 
@ session_start(); 
$nomeusuario = $_SESSION['nome_usuario'];

include "conecta_mysql.inc";

$num_mov_nascimento = $_POST['num_mov_nascimento'];
$codigo_animal_id = $_POST['codigo_animal_id'];
$codigo_mae_id = $_POST['codigo_mae_animal'];
$local = $_POST['local_id'];
$pasto_id = $_POST['pasto_id'];
$sexo = $_POST['sexo_animal'];
$desc_pasto = $_POST['desc_pasto'];

if ($sexo=='F') {
	$desc_sexo = 'Fêmea';
}
else {
	$desc_sexo = 'Macho';
}

$tbl_animal_pasto = mysqli_query($conector, "SELECT * FROM tbl_animal_pasto
	WHERE tbl_animal_pasto_local='$local' AND 
   	  	  tbl_animal_pasto_id ='$pasto_id' AND 
		  tbl_animal_pasto_categoria=1 AND 
		  tbl_animal_pasto_sexo='$sexo'");

$num_rows_animal_pasto = mysqli_num_rows($tbl_animal_pasto);	

if ($num_rows_animal_pasto==0) {
	header('Content-type: application/json');
	echo json_encode(array('error' => true, 'message' => 'Não existe bezerro ' . $desc_sexo . ' no pasto ' . $desc_pasto));
	exit;
}

$data_sistema = date("Y-m-d H:i:s");

if ($pasto_id=='000000000'){
	header('Content-type: application/json');
	echo json_encode(array('error' => true, 'message' => 'Informe o Pasto.'));
	exit;
}

if ($codigo_animal_id!=0) {
    $sql = ("DELETE FROM tbl_animais WHERE tbl_animal_codigo_id='$codigo_animal_id'");
	$resultado = mysqli_query($conector,$sql);
	$resposta = array('success' => true, 'message' => 'Registro animal excluido com sucesso.');
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	   	header('Content-type: application/json');
	   	echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na exclusão do animal no cadastro' . $erro_mysql));
		mysqli_close($conector);
    	exit;
	} 
}

$tbl_estoque = mysqli_query($conector, "select * from tbl_movimentacao_estoque
    where tbl_mov_estoque_numero_id ='$num_mov_nascimento'"); 

$reg_estoque = mysqli_fetch_object($tbl_estoque);
$data_nascimento = $reg_estoque->tbl_mov_estoque_nascimento;
$sexo = $reg_estoque->tbl_mov_estoque_sexo;
$peso = $reg_estoque->tbl_mov_estoque_primeiro_peso;

$tbl_animal_pasto = mysqli_query($conector, "SELECT * FROM tbl_animal_pasto
	WHERE tbl_animal_pasto_local='$local' AND 
   	  	  tbl_animal_pasto_id ='$pasto_id' AND 
		  tbl_animal_pasto_categoria=1 AND 
		  tbl_animal_pasto_sexo='$sexo' 
	ORDER BY tbl_animal_pasto_numero_item DESC LIMIT 1");

$num_rows_animal_pasto = mysqli_num_rows($tbl_animal_pasto);	

if ($num_rows_animal_pasto!=0) {
	$reg_animal_pasto = mysqli_fetch_object($tbl_animal_pasto);
	$numero_item =  $reg_animal_pasto->tbl_animal_pasto_numero_item;

	$sql = ("DELETE FROM tbl_animal_pasto 
		           WHERE tbl_animal_pasto_local='$local' AND 
	   		  			 tbl_animal_pasto_id ='$pasto_id' AND 
				         tbl_animal_pasto_numero_item='$numero_item'");
	$resultado = mysqli_query($conector,$sql);
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	   	header('Content-type: application/json');
	   	echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na exclusão do registro no pasto' . $erro_mysql));
		mysqli_close($conector);
	   	exit;
	}
}

// Exclui a movimentação do estoque

$sql = ("DELETE FROM tbl_movimentacao_estoque 
	           WHERE tbl_mov_estoque_numero_id ='$num_mov_nascimento'");
$resultado = mysqli_query($conector,$sql);
$resposta = array('success' => true, 'message' => 'Registro alterado com sucesso.');
$erro_mysql = mysqli_error($conector);

if (!$resultado){
   	header('Content-type: application/json');
   	echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na exclusão do registro do estoque' . $erro_mysql));
	mysqli_close($conector);
   	exit;
}

// excluir monta natural e ajusta registro de cobertura
$tbl_historico_monta = mysqli_query($conector, "select * from tbl_historico_monta_natural
    where tbl_historico_monta_codigo_id_animal_nascido ='$codigo_animal_id'"); 

$num_rows_historico = mysqli_num_rows($tbl_historico_monta);	

if ($num_rows_historico!=0) {
	$reg_historico = mysqli_fetch_object($tbl_historico_monta);
	$historico_id = $reg_historico->tbl_historico_monta_numero_id;
	$cobertura_id = $reg_historico->tbl_historico_monta_cobertura_id;
	$item_cobertura = $reg_historico->tbl_historico_monta_item_cobertura;

	$sql = ("UPDATE tbl_item_cobertura SET 
		    		tbl_ite_cobertura_resultado_diagnostico='P'
		 	  WHERE tbl_ite_cobertura_numero_id ='$cobertura_id' AND 
		 	        tbl_ite_cobertura_numero_item='$item_cobertura'");

	$resultado = mysqli_query($conector,$sql);

	$sql = ("DELETE FROM tbl_historico_monta_natural 
		           WHERE tbl_historico_monta_numero_id ='$historico_id'");
	
	$resultado = mysqli_query($conector,$sql);
}
// Fim excluir monta natural

// Altera o item de cobertura informando que houve aborto, absorção ou natimorto
$data_sistema = date("Y-m-d");

$tbl_par = mysqli_query($conector, "SELECT * FROM tbl_parametro_estacao_monta 
        WHERE tbl_par_codigo_local='$local' AND 
              tbl_par_lixeira=0 AND 
              tbl_par_estacao_monta_final>='$data_sistema'");  

$num_rows = mysqli_num_rows($tbl_par);

if ($num_rows!=0){
    $reg_para = mysqli_fetch_object($tbl_par);
    $id_estacao = $reg_para->tbl_par_estacao_id;
}
else {
  	$id_estacao = 0;
}

$tbl_item_cobertura = mysqli_query($conector, "SELECT * FROM tbl_item_cobertura 
	INNER JOIN tbl_cobertura
	        ON tbl_cobertura_id = tbl_ite_cobertura_numero_id
		 WHERE tbl_cobertura_codigo_local = '$local' AND
			   tbl_cobertura_controle = 'C' AND
			   tbl_ite_cobertura_codigo_id_animal = '$codigo_mae_id' AND 
			   tbl_ite_cobertura_resultado_diagnostico = 'P' AND 
			   tbl_ite_cobertura_nascido = 'N'"); 

$num_rows = mysqli_num_rows($tbl_item_cobertura);

if ($num_rows!=0){
    $reg_item = mysqli_fetch_object($tbl_item_cobertura);
    $cobertura_id = $reg_item->tbl_ite_cobertura_numero_id;
    $item_cobertura = $reg_item->tbl_ite_cobertura_numero_item;

	$sql = ("UPDATE tbl_item_cobertura SET 
			tbl_ite_cobertura_aborto_natimorto=null,
			tbl_ite_cobertura_nascido=null
		WHERE tbl_ite_cobertura_numero_id ='$cobertura_id' AND 
		      tbl_ite_cobertura_numero_item = '$item_cobertura'");

	$resultado = mysqli_query($conector,$sql);
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	  	header('Content-type: application/json');
	   	echo json_encode(array('error' => true, 'message' => 'Erro na atualização do item de cobertura.' . $erro_mysql));
		mysqli_close($conector);
		exit;
	}
}

// Subtrai registro do fechamento mensal
$data_hoje = date("Y-m-d");
$partes_hoje = explode("-", $data_hoje);
$anomes_inicial = $partes_hoje[0].$partes_hoje[1];

$partes_nascimento = explode("-", $data_nascimento);
$anomes_final = $partes_nascimento[0].$partes_nascimento[1];
$diferenca = $anomes_inicial - $anomes_final;

if ($diferenca!=0) {
	$date = new DateTime($data_nascimento);
	$date->modify('last day of this month');
	$data_fechamento = $date->format('Y-m-d');

	$tbl_fechamento = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque
   		WHERE tbl_fechamento_local='$local' AND
       		  tbl_fechamento_data='$data_fechamento' AND 
       		  tbl_fechamento_categoria='001' AND 
       		  tbl_fechamento_sexo='$sexo'");

	$num_rows = mysqli_num_rows($tbl_fechamento);    

	if ($num_rows!=0) {
		$reg = mysqli_fetch_object($tbl_fechamento);
		$fechamento_id = $reg->tbl_fechamento_id;
		$qtd_fechamento = $reg->tbl_fechamento_qtd;
		$peso_fechamento = $reg->tbl_fechamento_peso;

		$qtd_fechamento--;
		$peso_fechamento-=$peso;

		$sql = ("UPDATE tbl_fechamento_mensal_estoque SET 
				   		tbl_fechamento_qtd='$qtd_fechamento',
				   		tbl_fechamento_peso='$peso_fechamento'
		 	WHERE tbl_fechamento_id ='$fechamento_id'");

		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado) {
	   		header('Content-type: application/json');
	   		echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na alteração do fechamento mensal' . $erro_mysql));
			mysqli_close($conector);
			exit;
		}
    }

    $tbl_fechamento_ent_sai = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque_ent_sai_peso
    	WHERE tbl_fechamento_local='$local' AND
       		  tbl_fechamento_data='$data_fechamento'");

    $num_rows = mysqli_num_rows($tbl_fechamento_ent_sai);    

    if ($num_rows!=0) {
    	$reg = mysqli_fetch_object($tbl_fechamento_ent_sai);
    	$fechamento_id = $reg->tbl_fechamento_id;
    	$peso_nascimento = $reg->tbl_fechamento_peso_ent_nascimento;
	    $peso_final = $reg->tbl_fechamento_peso_final;

    	$peso_nascimento-=$peso;
    	$peso_final-=$peso;

		$sql = ("UPDATE tbl_fechamento_mensal_estoque_ent_sai_peso SET 
			   		tbl_fechamento_peso_ent_nascimento='$peso_nascimento',
			   		tbl_fechamento_peso_final='$peso_final'
		 	WHERE tbl_fechamento_id ='$fechamento_id'");

		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado) {
	   		header('Content-type: application/json');
	   		echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na alteração do fechamento mensal Ent/Sai' . $erro_mysql));
			mysqli_close($conector);
			exit;
		}
    }
}

// Fim Subritrai registro


$resposta = array('success' => true, 'message' => 'Registro excluído com sucesso.');
header('Content-type: application/json');
echo json_encode($resposta);
mysqli_close($conector);
exit;


?>