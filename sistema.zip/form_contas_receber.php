<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";

    $data_sistema = date("Y-m-d");

    $conta_pagamento = mysqli_query($conector, "select * from tbl_conta_pagamento where tbl_conta_pagamento_lixeira=0"); 

    $conta_pagamento_modal_baixar = mysqli_query($conector, "select * from tbl_conta_pagamento where tbl_conta_pagamento_lixeira=0"); 

    $c_custo = mysqli_query($conector, "select * from tbl_centro_custo where tbl_cc_lixeira=0 order by tbl_cc_codigo_id ASC"); 

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS -->
  <link href="css/jquery-ui.css" rel="stylesheet" />
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <link href="css/daterangepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-colorpicker.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="DataTables-1.10.18/css/dataTables.bootstrap4.min.css"rel="stylesheet" >
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>

<body>

  <?php

   @ session_start();   
    if(isset($_SESSION['menu_gestao_adm'])) {
        $array_gestao_adm = explode("!",$_SESSION['menu_gestao_adm']);

        if ($array_gestao_adm[3] == 0){
            echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
            echo '<strong class="negrito">Atenção! </strong><span>Você não tem acesso a esse programa!</span>';  
            echo '</div>';         
            exit;
        }
    }
    else {
        echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
        echo '<strong class="negrito">Atenção! </strong><span>Você não efetuou o login!</span>';  
        echo '</div>';         
        exit;
    }

    if ($_SESSION['data_inicio_ctr']==0 && $_SESSION['razao_nome_ctr']==''){
        $data_inicial = $data_sistema;
    }
    else {
        $data_inicial =  $_SESSION['data_inicio_ctr'];  
    }

    if ($_SESSION['data_fim_ctr']==0 && $_SESSION['razao_nome_ctr']==''){
        $data_final = $data_sistema;
    }
    else {
        $data_final =  $_SESSION['data_fim_ctr'];   
    }

    if ($_SESSION['tipo_data_ctr']==''){
        $tipo_data = "V";
    }
    else {
        $tipo_data =  $_SESSION['tipo_data_ctr'];   
    }

    if ($_SESSION['razao_nome_ctr']==''){
        $razao_nome = "";
    }
    else {
        $razao_nome = $_SESSION['razao_nome_ctr'];  
    }

    if ($_SESSION['codigo_c_custo_ctr']==0){
        $codigo_c_custo = "";
    }
    else {
        $codigo_c_custo = $_SESSION['codigo_c_custo_ctr'];  
    }

    $total_parcelas = 0;

?>

<!-- container section start -->
<section id="container" class="">

    <!--sidebar start-->
    <?php
        include "cabecalho.php";
        include "opcoes_menu.php";
    ?>
    <!--sidebar end-->

  <!-- container section start -->
  <section id="container" class="">

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Gestão Administrativa <i class="fa fa-angle-right seta-direita"></i><span class="titulo">Contas a Receber</span></span>

            <a href="#" style="color: gray; margin-left: 10px;" data-toggle='tooltip' data-placement='right' title="Orientações de uso" onclick="informacoes_uso()"><i class="far fa-question-circle"></i></a>

           <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fas fa-hand-holding-usd"></i> Contas a Receber</h3>
                </div>
            </div>

	        <div class="row">
		        <div class="col-lg-12">
                        <div  class="form-group">
                              <a href="form_contas_receber_incluir.php">
                                  <input type="button" class="btn btn-primary" aria-label="Left Align" 
                                  value="Incluir Nova"/>
                              </a>
                        </div> 

                        <div class="row col-md-12" id="consulta_contas">
                            <form method="GET" action="form_contas_receber.php" enctype="multipart/form-data" >
                            
                                <div class="tab-panel">
                                    <div class="tab-pane active">
                                    	<input id="lista_ctr_automatico" type="hidden"
                                    	<?php echo "value='".$_SESSION['lista_ctr']."'";?>>

                                        <fieldset class="scheduler-border dados_consulta">
                                            <legend class="scheduler-border fonte-legend">Dados para Consultar</legend>
                                            <div class="row ">
                                                <div class="form-group col-md-3">
                                                    <label for="data_inicial" class="control-label">Data Incial</label>
                                                    <input name="data_inicial" type="date" class="form-control" id="data_inicial"
                                                    <?php echo "value='".$data_inicial."'";?>>
                                                </div>

                                                <div class="form-group col-md-3">
                                                    <label for="data_final" class="control-label">Data Final</label>
                                                    <input name="data_final" type="date" class="form-control" id="data_final"
                                                    <?php echo "value='".$data_final."'";?>>
                                                </div>

                                                <div class="form-group">
                                                    <label for="tipo_data" class="control-label">Tipo de Data</label>
                                                </div>

                                                <div class="form-group col-md-4">
                                                    <label class="radio-inline">
                                                      <input type="radio" name="tipo_data" value="V" 
                                                      <?php if ($tipo_data == 'V'){echo "checked";}?>> Vencimento 
                                                    </label>
                                                    <label class="radio-inline">
                                                      <input type="radio" name="tipo_data" value="E"
                                                      <?php if ($tipo_data == 'E'){echo "checked";}?>> Emissão
                                                    </label>
                                                    <label class="radio-inline">
                                                      <input type="radio" name="tipo_data" value="P"
                                                      <?php if ($tipo_data == 'P'){echo "checked";}?>>Recebimento
                                                    </label>
                                                </div>    
                                            </div>

											<div class="row">
                                                <div class="form-group col-md-6">
                                                    <label for="razao_nome" class="control-label">Razão/Nome</label>
                                                    <input name="razao_nome" type="text" class="form-control" id="razao_nome"
                                                    <?php echo "value='".$razao_nome."'";?>>
                                                </div>

                                                <div class="form-group col-md-6">
                                                    <label for="codigo_cc" class="control-label">Centro de Custo</label>
                                                    <select class="form-control" id="codigo_cc" name="codigo_cc">
                                                      
                                                      <option value="" selected="selected">Todos</option>

                                                      <?php while($registo_cc = mysqli_fetch_object($c_custo)) { ?>

                                                      <option value="<?php 
                                                       echo $registo_cc->tbl_cc_codigo_id ?>"

                                                        <?php 
                                                          if($registo_cc->tbl_cc_codigo_id==$codigo_c_custo) 
                                                             { echo "selected"; }
                                                       ?>>
                                                        
                                                      <?php 
                                                          echo $registo_cc->tbl_cc_descricao;
                                                      ?>
                                                      </option>
                                                      <?php } ?>

                                                    </select>

                                                </div>

											</div>

                                            <div class="row">
                                                <div class="form-group col-md-12">

                                                    <button type="button" class="btn btn-info pull-right" onclick="consultar_ctr()">Consultar</button>
                                                </div>

                                            </div>
                                        </fieldset>


                                    </div>
                                </div>
                            </form>
                        </div>    

                    <div id="lista_contas_receber">
                    	<?php   
						?>
                    </div>
    	        </div>
	        </div>

            <!-- modal baixa das contas selecionadas-->
            <div class="modal fade dados_baixa" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Contas a Receber - Baixar Registros</h4>
                        </div>

                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="total_baixar" class="control-label">Valor total para baixar</label>
                                    <input name="total_baixar" type="text" class="form-control" id="total_baixar" readonly="">
                                </div>

                                <div class="form-group">
                                    <label for="data_pagamento" class="control-label">Data para Pagamento</label>
                                    <input name="data_pagamento" type="date" class="form-control" id="data_pagamento">
                                </div>

                                <div class="form-group">
                                    <label for="codigo_conta_rec" class="control-label">Conta Pagamento</label>
                                    <select class="form-control" id="codigo_conta_rec" name="codigo_conta_rec" >

                                    <option value="00" selected="selected">...</option>

                                    <?php while($reg_conta_pag = mysqli_fetch_object($conta_pagamento)) { ?>

                                    <option value="<?php 
                                        echo $reg_conta_pag->tbl_conta_pagamento_id ?>">
                                                    
                                        <?php 
                                            echo $reg_conta_pag->tbl_conta_pagamento_descricao;
                                        ?>
                                    </option>
                                    <?php } ?>
                                    </select>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-12">

                                        <button type="button" class="btn btn-primary pull-left" id="baixar_selecionadas"
                                            onClick="baixar_contas_selecionadas()" >Confirme a Baixa</button>
                                        
                                        <button data-dismiss="modal" class="btn btn-info pull-right fecha_dados_baixa" type="button">Fechar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- modal baixa conta individual-->
            <div class="modal fade" id="modal_baixar" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Contas a Receber - Baixar Registro</h4>
                        </div>

                        <div class="modal-body">
                            <form>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="number_doc_baixar" class="control-label">Nº Documento</label>
                                        <input name="number_doc_baixar" type="text" class="form-control" id="number_doc_baixar">
                                        <input name="chave_ind" type="hidden" class="form-control" id="chave_ind" readonly="">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="number_parcela_baixar" class="control-label">Parcela</label>
                                        <input name="number_parcela_baixar" type="text" class="form-control" id="number_parcela_baixar" readonly="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="vlr_total_baixar" class="control-label">Valor total para baixar</label>
                                    <input name="vlr_total_baixar" type="text" class="form-control" id="vlr_total_baixar" readonly="">

                                </div>

                                <div class="form-group">
                                    <label for="data_pagamento_baixar" class="control-label">Data para Recebimento</label>
                                    <input name="data_pagamento_baixar" type="date" class="form-control" id="data_pagamento_baixar">
                                </div>

                                <div class="form-group">
                                    <label for="codigo_conta_pagto_baixar" class="control-label">Conta Pagamento</label>
                                    <select class="form-control" id="codigo_conta_pagto_baixar" name="codigo_conta_pagto_baixar" >

                                    <option value="00" selected="selected">...</option>

                                    <?php while($reg_conta_pag = mysqli_fetch_object($conta_pagamento_modal_baixar)) { ?>

                                    <option value="<?php 
                                        echo $reg_conta_pag->tbl_conta_pagamento_id ?>">
                                                    
                                        <?php 
                                            echo $reg_conta_pag->tbl_conta_pagamento_descricao;
                                        ?>
                                    </option>
                                    <?php } ?>
                                    </select>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-12">

                                        <button type="button" class="btn btn-primary pull-left" id="baixar_selecionadas"
                                            onClick="baixar_conta_selecionada()" >Confirme a Baixa</button>
                                        
                                        <button data-dismiss="modal" class="btn btn-info pull-right fecha_dados_baixa" type="button" >Fechar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

	        <!-- page end-->
            <div class="modal fade" id="mensagem_retorno" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Contas a Receber</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" onclick="location.reload();">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_erro" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Contas a Receber - Erro</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" >Fechar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <?php
                    include "ajuda.php";
                ?>
            </div>

        </section>
    </section>

<?php 
  $javascript_file_name = 'contas_receber.js';
  require 'rodape.php';
?>



                
                
