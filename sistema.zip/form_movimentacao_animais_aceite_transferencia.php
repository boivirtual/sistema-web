<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";

    $data_sistema = date("Y-m-d");

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS -->
  <link href="css/jquery-ui.css" rel="stylesheet" />
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <link href="css/daterangepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-colorpicker.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="DataTables-1.10.18/css/dataTables.bootstrap4.min.css"rel="stylesheet" >
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>

<body>

  <?php

   @ session_start();   
    if(isset($_SESSION['menu_manejo_animais'])) {
        $array_movimentacao = explode("!",$_SESSION['menu_manejo_animais']);

        if ($array_movimentacao[2] == 0){
            echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
            echo '<strong class="negrito">Atenção! </strong><span>Você não tem acesso a esse programa!</span>';  
            echo '</div>';         
            exit;
        }
    }
    else {
        echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
        echo '<strong class="negrito">Atenção! </strong><span>Você não efetuou o login!</span>';  
        echo '</div>';         
        exit;
    }

    $codigo_usuario = $_SESSION['id_usuario'];

    $tbl_usuario = "SELECT * FROM usuario WHERE id_usuario = '$codigo_usuario' AND 
                                           lixeira_usuario=0 ";  
    $query = mysqli_query($conector_acesso, $tbl_usuario);

    $num_rows_usuario = mysqli_num_rows($query);

    if ($num_rows_usuario!=0){
        $reg_usuario = mysqli_fetch_assoc($query);

        $array_locais_usuario = explode(',', $reg_usuario['local_usuario']);
        $qtd_locais_usuario = count($array_locais_usuario);

        if ($qtd_locais_usuario==0) {
            $array_locais_usuario='';
        }
    }
    else {
        $array_locais_usuario='';
    }

?>

<!-- container section start -->
<section id="container" class="">

    <!--sidebar start-->
    <?php
        include "cabecalho.php";
        include "opcoes_menu.php";
    ?>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Animais <i class="fa fa-angle-right seta-direita"></i><a class="voltar-menu" href="form_movimentacao_animais.php"> Movimentações</a> <i class="fa fa-angle-right seta-direita"></i>
            <span class="titulo">Aceite Transferência</span></span>

            <a href="#" style="color: gray; margin-left: 10px;" data-toggle='tooltip' data-placement='right' title="Orientações de uso" onclick="informacoes_uso()"><i class="far fa-question-circle"></i></a>

           <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-cogs"></i> Aceite Transferência</h3>
                </div>
            </div>

            <div class="row col-lg-12">
                <div class="form-group">
                    <button type="button" class="btn btn-primary" 
                        onClick="confirmar_aceite_transferencia_selecionados()">Confirmar Selecionados</button>

                   <button type="button" class="btn btn-info pull-right" 
                        onClick="finalizar_sair()">Voltar</button>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                    <div class="table-responsive">
                        <table class="table table-borderless table-hover" width="100%" 
                        style="font-size: 12px">
                        <thead>
                            <tr>
                                <th><input type="checkbox" class='checkbox1' data-toggle='tooltip' data-placement='top' id="seleciona_todos_aceite" title="Selecionar Todos"></th> 
                                <th>Data</th> 
                                <th>Local Origem</th>
                                <th>Local Destino</th> 
                                <th>Qtde Animais</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $chave_anterior = '';

                                $rs = mysqli_query($conector, "SELECT * FROM tbl_movimentacao
                                    INNER JOIN tbl_pessoa
                                            ON tbl_pessoa_id =tbl_movimentacao_codigo_local_origem
                                         WHERE tbl_movimentacao_tipo=5 AND 
                                               tbl_movimentacao_situacao='N'
                                      ORDER BY tbl_movimentacao_data ASC");
                                    
                                while ($fila = mysqli_fetch_object($rs)){
                                    $local_destino = $fila->tbl_movimentacao_codigo_local_destino;

                                    foreach ($array_locais_usuario as $value) {
                                        $value = ltrim($value);
                                        $value = rtrim($value);

                                        if ($value==$local_destino) {
                                            $data_emissao = new DateTime($fila->tbl_movimentacao_data);
                                            $data_emissao_edi = $data_emissao->format('d/m/Y');
                                            $numero_id = $fila->tbl_movimentacao_id ;
                                            $desc_origem = $fila->tbl_pessoa_nome;
                                            $qtd_animais = $fila->tbl_movimentacao_qtd_animais_pesados;

                                            $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_id='$local_destino'");
                                            $num_rows = mysqli_num_rows($tbl_local);

                                            if ($num_rows!=0){
                                                $reg = mysqli_fetch_object($tbl_local);
                                                $desc_destino = $reg->tbl_pessoa_nome;
                                            }
                                            else {
                                                $desc_destino = '';
                                            }

                                            echo "<tr>";
                                            echo "<td width='2%'>
                                                <input type='checkbox' class='checkbox1' name='id_mov' data-toggle='tooltip' data-placement='top' title='Seleciome para Confirmar o aceite' value='".$numero_id."'>
                                                      </td>";
                                            echo "<td width='15%'>".$data_emissao_edi."</td>";
                                            echo "<td width='30%'>".$desc_origem."</td>";
                                            echo "<td width='30%'>".$desc_destino."</td>";
                                            echo "<td width='10%' align='center'>".$qtd_animais."</td>";
                                            echo "</tr>";
                                        }
                                    }
                                }
                            ?>    
                        </tbody>

                        <tfoot>
                            
                        </tfoot>
                        </table>

                      <!--  <div class="row col-md-12">
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" 
                                 onClick="confirmar_aceite()">Confirmar Selecionados</button>

                                <button type="button" class="btn btn-info pull-right" 
                                 onClick="aceite_sair()">Voltar</button>
                            </div>
                        </div> -->
                    </div> <!-- fecha div responsivo -->
                    </section>
                </div>
            </div>

            <div>
                <?php
                    include "ajuda.php";
                ?>
            </div>

        </section>
    </section>

<?php 
  $javascript_file_name = 'movimentacao.js';
  require 'rodape.php';
?>



                
                
