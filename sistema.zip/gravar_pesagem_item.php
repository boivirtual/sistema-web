<?php 
	include "conecta_mysql.inc";

	@ session_start(); 
	$nomeusuario = $_SESSION['nome_usuario'];
    $controle_estoque= $_SESSION['controle_estoque'];
	$data_sistema = date("Y-m-d H:i:s");
	$numero_pesagem_id= $_POST['numero_pesagem_id'];
	$epoca_pesagem= $_POST['epoca_pesagem'];
	$descricao_lote= $_POST['lote'];
	$data_pesagem= $_POST['data_pesagem'];
	$finalizar_pesagem= $_POST['finalizar_pesagem'];
	$excluir_id= $_POST['excluir_id'];

	if ($finalizar_pesagem=='S') {
		$sql = ("DELETE FROM tbl_item_pesagem
							   WHERE tbl_ite_pesagem_numero_id = '$numero_pesagem_id' AND 
							         tbl_ite_pesagem_peso = 0");
		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		   	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro ao excluir o item.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		} 

		$sql = "UPDATE tbl_pesagem SET
				tbl_pesagem_data='$data_pesagem',
		  		tbl_pesagem_finalizada='$finalizar_pesagem'
		WHERE tbl_pesagem_id='$numero_pesagem_id'";

		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		   	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro ao atualizar a pesagem.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		} 
		else {
		   	header('Content-type: application/json');
		   	echo json_encode(array('success' => true, 'message' => 'Pesagem finalizada com suscesso'));
			mysqli_close($conector);
			exit;
		}
	}

	$qtd_a_pesar= $_POST['qtd_a_pesar'];
	$qtd_pesado= $_POST['qtd_pesado'];
	$peso_total_kg= $_POST['peso_total_kg'];
	$peso_total_arroba= $_POST['peso_total_arroba'];
	$peso_medio_kg= $_POST['peso_medio_kg'];
	$peso_medio_arroba= $_POST['peso_medio_arroba'];

	$codigo_id= $_POST['codig_id'];
	$item_id= $_POST['item_id'];
	$peso= $_POST['peso_id'];
	$observacao = $_POST['obs_id'];

	$sql = "UPDATE tbl_pesagem SET
			tbl_pesagem_data='$data_pesagem',
	  		tbl_pesagem_lote='$descricao_lote',
			tbl_pesagem_qtd_animais_pesados='$qtd_pesado',
			tbl_pesagem_peso_kg='$peso_total_kg',
			tbl_pesagem_peso_arroba='$peso_total_arroba',
			tbl_pesagem_peso_medio_kg='$peso_medio_kg',
			tbl_pesagem_peso_medio_arroba='$peso_medio_arroba',
			tbl_pesagem_alterado_em='$data_sistema',
			tbl_pesagem_alterado_por='$nomeusuario'
	WHERE tbl_pesagem_id='$numero_pesagem_id'";

	$resultado = mysqli_query($conector,$sql);
	$erro_mysql = mysqli_error($conector);

	if (!$resultado){
	   	header('Content-type: application/json');
	   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro ao atualizar a pesagem.' . $erro_mysql));
		mysqli_close($conector);
		exit;
	} 

	if ($excluir_id=="S") {
		$sql = ("DELETE FROM tbl_item_pesagem
							   WHERE tbl_ite_pesagem_numero_id = '$numero_pesagem_id' AND 
							         tbl_ite_pesagem_numero_item = '$item_id' AND 
							         tbl_ite_pesagem_codigo_id_animal = '$codigo_id'");
		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		   	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro ao excluir o item.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		} 
		else {
		   	header('Content-type: application/json');
		   	echo json_encode(array('success' => true, 'message' => 'Item excluir com suscesso'));
			mysqli_close($conector);
			exit;
		}
	}

	$peso_arroba = $peso/30;

	$sql = "UPDATE tbl_item_pesagem SET
		  		tbl_ite_pesagem_data_emissao='$data_pesagem',
				tbl_ite_pesagem_peso='$peso',
				tbl_ite_pesagem_peso_medio='$peso',
				tbl_ite_pesagem_arroba='$peso_arroba',
				tbl_ite_pesagem_arroba_media='$peso_arroba',
				tbl_ite_pesagem_observacao='$observacao'
	WHERE tbl_ite_pesagem_numero_id='$numero_pesagem_id' AND tbl_ite_pesagem_numero_item='$item_id'";

	$resultado = mysqli_query($conector,$sql);
    $erro_mysql = mysqli_error($conector);

	if (!$resultado){
	   	header('Content-type: application/json');
	   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro na atualização do item da pesagem.' . $erro_mysql));
		mysqli_close($conector);
		exit;
	} 

    if ($peso!=0) {
        if ($epoca_pesagem==1) {
		    $sql = "UPDATE tbl_animais SET
				tbl_animal_primeiro_peso='$peso',
				tbl_animal_lote_primeiro_peso='$descricao_lote',
				tbl_animal_data_primeiro_peso='$data_pesagem'
		    WHERE tbl_animal_codigo_id='$codigo_id'";

        }
        else if ($epoca_pesagem==2 || $epoca_pesagem==8) {
		    $sql = "UPDATE tbl_animais SET
				tbl_animal_peso_desmama='$peso',
				tbl_animal_lote_desmama='$descricao_lote',
				tbl_animal_data_desmama='$data_pesagem'
		    WHERE tbl_animal_codigo_id='$codigo_id'";

        }
        else {
		    $sql = "UPDATE tbl_animais SET
				tbl_animal_ultimo_peso='$peso',
				tbl_animal_lote_ultimo='$descricao_lote',
				tbl_animal_data_ultimo='$data_pesagem'
		    WHERE tbl_animal_codigo_id='$codigo_id'";
        }
    }

    $resultado = mysqli_query($conector,$sql);
    $erro_mysql = mysqli_error($conector);

	if (!$resultado){
	   	header('Content-type: application/json');
	   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro na atualização do animal.' . $erro_mysql));
		mysqli_close($conector);
		exit;
	} 

	mysqli_close($conector);
	exit;

?>