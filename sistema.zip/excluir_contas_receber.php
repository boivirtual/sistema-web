<?php

	$valor[0]=0;
	$valor[1]='';

	$numero_doc = $_POST['id'];
	$numero_parcela = $_POST['parcela'];
	$opcao = $_POST['opcao'];
    $data_sistema = date("Y-m-d H:i:s");

	@ session_start(); 
    $nomeusuario = $_SESSION['nome_usuario'];

	include "conecta_mysql.inc";

	switch ($opcao) {
    case 1:
		$sql = ("UPDATE contas_receber SET ctr_lixeira='1',
			                               ctr_lixeira_em='$data_sistema',
			                               ctr_lixeira_por='$nomeusuario'
		                             WHERE ctr_numero_doc='$numero_doc' AND 
										   ctr_parcela='$numero_parcela'");

		//$sql = ("DELETE FROM contas_receber WHERE ctr_numero_doc='$numero_doc' AND 
												  //ctr_parcela='$numero_parcela'");
		$resultado = mysqli_query($conector,$sql);
		$mysql_erro = mysqli_error($conector);

		if (!$resultado){
	       $valor[0]=9;
	       $valor[1]='Erro ao excluir o registro! ' . $mysql_erro;
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
		else {
	       $valor[0]=0;
	       $valor[1]='Registro excluido com sucesso! ';
	       $str = $valor[0] . '<|>' . $valor[1] . '<|>';
	       die ($str);
		}
        break;
	} 
		

	mysql_close($conector);

?>