<?php
    include "conecta_mysql.inc";
    include "valida_sessao.inc";

    $data_sistema = date("Y-m-d");

    $data_inicial = date("Y-m");
    $data_final = date("Y-m");

    $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_classe=4 and tbl_pessoa_lixeira=0"); 

    $tbl_contas = mysqli_query($conector, "select * from tbl_plano_contas 
        where tbl_plano_contas_debito_credito='D' AND 
              tbl_plano_contas_ana_sin='A' AND 
              tbl_plano_contas_lixeira=0
        order by tbl_plano_contas_descricao ASC");

    $tbl_categoria = mysqli_query($conector, "select * from tabela_categoria_idade where tab_registro_lixeira_categoria_idade=0"); 

    @ session_start(); 
    $codigo_usuario = $_SESSION['id_usuario'];
    $grupo_usuario = $_SESSION['grupo_usuario'];
    $array_categoria = '';

    $tbl_usuario = "SELECT * FROM usuario WHERE id_usuario = '$codigo_usuario' AND 
                                           lixeira_usuario=0 ";  
    $query = mysqli_query($conector_acesso, $tbl_usuario);

    $num_rows_usuario = mysqli_num_rows($query);

    if ($num_rows_usuario!=0){
        $reg_usuario = mysqli_fetch_assoc($query);

        $array_locais_usuario = explode(',', $reg_usuario['local_usuario']);
        $qtd_locais_usuario = count($array_locais_usuario);

        if ($qtd_locais_usuario==0) {
            $array_locais_usuario='';
        }
    }
    else {
        $array_locais_usuario='';
    }

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
    <title>Boi Virtual</title>

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/style.css?<?php echo Versao; ?>" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay"  rel="stylesheet" crossorigin="anonymous">

    <link href="css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/fixedcolumns/3.3.1/css/fixedColumns.dataTables.min.css" rel="stylesheet">
    <link href="css/select-1.13.14.css" rel="stylesheet" > 

    <!--<link href="assets/materialize/css/materialize.css?<?php echo Versao;?>" rel="stylesheet" media="screen,projection" />-->

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
    <!-- LOTAÇÃO DA FAZENDA (LINHAS) -->
    <script type="text/javascript">

    </script>    

    <script type="text/javascript">
        function processar_dados() {
            var data_inicial = $("#data_inicial").val();
            var data_final = $("#data_final").val();
            var local = $("#codigo_local").val();
            var codigo_conta = $("#codigo_conta").val();

            if (data_inicial==0) {
                $("#mensagem_erro").modal();
                $("#mensagem_erro .modal-body").html('Informe as Datas Inicial e Final!');
                $("#data_inicial").focus();
                document.getElementById("data_inicial").style.borderColor = "#FF0000";
                $(".dashboard-cards").hide();
                return;
            }

            if (data_final<data_inicial) {
                $("#mensagem_erro").modal();
                $("#mensagem_erro .modal-body").html('Data Final menor que a Data Inicial!');
                $("#data_final").focus();
                document.getElementById("data_final").style.borderColor = "#FF0000";
                $(".dashboard-cards").hide();
                return;
            }

            if (codigo_conta==null) {
                $("#mensagem_erro").modal();
                $("#mensagem_erro .modal-body").html('Selecione Contas para o Gráfico Custo/Cabeça, máximo 5 contas!');
                $('#codigo_conta').selectpicker('refresh');
                return;
            }

            if (codigo_conta.length > 5) {
                $("#mensagem_erro").modal();
                $("#mensagem_erro .modal-body").html('Selecione no máximo 5 contas para o Gráfico Custo/Cabeça!');
                $('#codigo_conta').selectpicker('refresh');
                return;
            }

            var filtro_categoria = $("#categoria option:selected").text();
            $("#filtro_gmd_global").text('Filtro GMD: ' + filtro_categoria);

            if (filtro_categoria=='Selecione Categorias'){
                $("#mensagem_erro").modal();
                $("#mensagem_erro .modal-body").html('Selecione Categorias para o cálculo GMD Global!');
                return;
            }

            var expande_tela = $("#expande_tela").val();

            if (expande_tela=="S"){
                if (jQuery('#sidebar > ul').is(":visible") === true) {
                    jQuery('#main-content').css({
                        'margin-left': '0px'
                    });
                    jQuery('#sidebar').css({
                        'margin-left': '-180px'
                    });
                    jQuery('#sidebar > ul').hide();
                    jQuery("#container").addClass("sidebar-closed");
                }
            }

            $(".dashboard-cards").show();
            $(".exibe_mais_filtros").hide();
            $(".mais_filtros").show();
            $(".menos_filtros").hide();

            $.post("lista_estoque_cabeca_painel.php",{local: local, data_inicial:data_inicial, data_final:data_final}, function(retorno){
                var php = retorno.split("<|>");

                $("#total_unidade").text(php[0] + ' Un');
                $("#total_peso").text(php[1] + ' Kg');
                $("#total_arroba").text(php[2] + ' @');

                $("#media_unidade").text(php[3] + ' Un');
                $("#media_peso").text(php[4] + ' Kg');
                $("#media_arroba").text(php[5] + ' @');

                $("#locacao_unidade").text(php[6] + ' Cab/Ha');
                $("#lotacao_media").text(php[7] + ' KgPc/Ha');
                $("#lotacao_ua").text(php[8] + ' Ua/Ha');

                // LOTAÇÃO DA FAZENDA (GRAFICO LINHAS)
                google.charts.load('current', {'packages':['corechart'], 'language': 'pt-BR'});
                google.charts.setOnLoadCallback(lineChart);

                function lineChart() {
                    var data = google.visualization.arrayToDataTable([
                      [{type: 'date', label: 'Mês/Ano'}, {type: 'number', label: 'KgPc/Ha'}, {type: 'number', label: 'Lotação Média'}],
                      ["Date(2023, 0, 31)", 372.67, php[7]],
                      ["Date(2023, 1, 28)", 472.65, php[7]],
                      ["Date(2023, 2, 31)", 322.65, php[7]],
                    ]);

                    var options = {
                        seriesType: 'line',
                        series: {
                            2: {
                                type: 'line',
                                tooltip: {
                                    isHtml: false,
                                },
                            },
                        },

                        vAxis: {
                            minValue: 0,
                            //maxValue: 1000,
                            format: 'decimal'
                        }, 

                        hAxis: {
                            format: 'MMM',
                            gridlines: {color: 'none'},
                            ticks: [new Date(2023, 0, 31), new Date(2023, 1, 28), new Date(2023, 2, 31)],
                        },

                        titlePosition: 'none',
                        backgroundColor: 'transparent',
                        fontName: 'Futura Std Light',
                        fontSize: 12,
                        chartArea: {
                            left: 80,
                            bottom:50,  
                            top:5,                    
                            width: "70%",
                            height: "100%"
                        },
                      //curveType: 'function',
                        legend: { position: 'bottom' }
                    };

                    var chart = new google.visualization.LineChart(document.getElementById('line_chart'));

                    chart.draw(data, options);
                }
                // FIM DA FAZENDA (GRAFICO LINHAS)

            });

            contas = JSON.parse(readContas(local, data_inicial, data_final));

            contas.sort(function(a,b) {
                if(a.valor > b.valor) {
                    return -1;
                } 
                else {
                    return true;
                }
            });

            //GASTO POR CONTAS (PIZZA) 
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var dataArray = [['Conta', 'Valor'],];

                for (var i = 0; i < contas.length; i++) {

                    var row = [contas[i].descricao, contas[i].valor];
                    dataArray.push(row);
                }
                
                var data = google.visualization.arrayToDataTable(dataArray);
                
                var options = {
                    titlePosition: 'none',
                    backgroundColor: 'transparent',
                    fontName: 'Futura Std Light',
                    fontSize: 12,
                    chartArea: {
                        left: 20,
                        bottom:25,  
                        top:5,                    
                        width: "90%",
                        height: "auto"
                    },
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                chart.draw(data, options);

            }// FIM GASTO POR CONTAS (PIZZA)
            
        } // FIM FUNÇÃO PROCESSAR_DADOS

        function readContas(local, data_inicial, data_final) {
            return $.ajax({
                type: "GET",
                data: { local: local, data_inicial: data_inicial, data_final: data_final },
                url: "ler_contas_pagar_painel.php",
                async: false,
            }).responseText;
        }
    </script>

    <!-- CUSTO POR CABEÇA (BARRAS) -->
    <script type="text/javascript">

        google.charts.load('current', {packages: ['corechart', 'bar']});
        google.charts.setOnLoadCallback(drawBasic);

        function drawBasic() {

            var data = google.visualization.arrayToDataTable([
                ['Conta', 'Custo',],
                ['Pastagens', 120],
                ['Vacinas', 900],
                ['Medicamentos', 300],
                ['Nutrição', 2300],
                ['Pessoas', 2000],
            ]);

            var options = {
                titlePosition: 'none',
                backgroundColor: 'transparent',
                fontName: 'Futura Std Light',
                fontSize: 12,
                chartArea: {
                left:80,
                bottom:25,  
                top:5,                    
                    width: "60%",
                    height: "auto"
                },
            };

            var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
    </script>

    <style type="text/css">
        @media (max-width: 767.98px) {
            .fc .fc-toolbar.fc-header-toolbar {
            display: block;
            text-align: center;
            }

            .fc-header-toolbar .fc-toolbar-chunk {
            display: block;
            }
        }

        @media (min-width: 400px) {
            /*#chart_div, #piechart {
                width: 90%;
            }*/
        }

        @media (max-width: 420px) {
            .margem_row {
                margin-top: 20px;
            }
        }

        .card {
          position: relative;
          margin: 0 0 0 0;
          background-color: #fff;
          transition: box-shadow .25s;
          border-radius: 2px;
          box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12), 0 3px 1px -2px rgba(0, 0, 0, 0.2);
        }

        .card-title {
            color: #939ba2;
            font-size: .925rem;
            font-weight: 600;
            padding-left: 10px;
            padding-top: 10px;
        }

        table.dataTable thead th{
            border-bottom: 1px solid transparent;
            padding-bottom: 1px; 
            padding-top: 1px;
            font-weight: 600;        
        }

        table.dataTable tfoot th{
            border-top: 1px solid transparent;
        }

        table.dataTable {
            border: 1px solid transparent;
            font-weight: 600;
        }

        .chart-title {
            color: #6b6d6e;
            font-size: 16px;
            font-weight: 600;
            padding: 0;
            margin: 0;
            text-align: center;
            margin-top: 20px;
            margin-bottom: 5px;
            opacity: 0.8;
        }

        .margem_esquerda {
            margin-left: 2px;
        }
    </style>
</head>

<body>
    <!-- container section start -->
    <section id="container" class="">

        <?php
            include "cabecalho.php";
            include "opcoes_menu.php";
            include "start_session.php";
        ?>

        <!--main content start-->
        <section id="main-content">
            <section class="wrapper"> 
                <span class="caminho-programa">Relatórios <i class="fa fa-angle-right seta-direita"></i> 
                <span class="titulo">Painel Estratégico</span></span>

                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"><i class="fa fa-laptop"></i> 
                        Painel Estratégico</h3>
                    </div>
                </div>

                <div class="row">
                    <input type="hidden" id="expande_tela" value="S">

                    <div class="col-lg-12">
                        <div class="row col-md-12 card" id="consulta_contas">
                            <div class="row">  
                                <div class="form-group col-md-3" >
                                    <label for="data_inicial" class="control-label" style="font-size: 14px;"><span class="required">*</span> Data Incial</label>
                                    <input name="data_inicial" type="month" class="form-control" id="data_inicial" <?php //echo "value='".$data_inicial."'";?>>
                                </div>

                                <div class="form-group col-md-3"> 
                                    <label for="data_final" class="control-label" style="font-size: 14px;"><span class="required">*</span> Data Final</label>
                                    <input name="data_final" type="month" class="form-control" id="data_final" <?php //echo "value='".$data_final."'";?>>
                                </div>

                                <div class="form-group col-md-4">
                                    <label for="codigo_local" class="control-label" style="font-size: 14px;"><span class="required">*</span> Fazenda</label>
                                    <select class="form-control" id="codigo_local" name="codigo_local">
                                        <option value="000000000">Todas</option>
                                    <?php 
                                        while($reg_local = mysqli_fetch_object( $tbl_local)) { 
                                            foreach ($array_locais_usuario as $value) {
                                                $value = ltrim($value);
                                                $value = rtrim($value); 

                                                if ($value==$reg_local->tbl_pessoa_id) {
                                                    echo '<option value="'.$value.'">' .$reg_local->tbl_pessoa_nome. '</option>'; 
                                                }
                                            }
                                        } 
                                    ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-1 mais_filtros" hidden>
                                    <label class="control-label">&nbsp;</label>

                                    <p><a href="#" class="control-label" data-toggle='tooltip' data-placement='top' title="Mais Filtros" onclick="exibe_mais_filtros()"> 
                                    <i class="fas fa-filter"></i> +
                                    </a></p>
                                </div>

                                <div class="form-group col-md-1 menos_filtros" hidden>
                                    <label class="control-label">&nbsp;</label>

                                    <p><a href="#" class="control-label" data-toggle='tooltip' data-placement='top' title="Menos Filtros" onclick="exibe_menos_filtros()"> 
                                    <i class="fas fa-filter"></i> -
                                    </a></p>
                                </div>

                                <div class="form-group col-md-1">
                                    <label class="control-label">&nbsp;</label>

                                    <button type="button" class="form-control btn btn-primary pull-right" onclick="processar_dados()">Listar
                                    </button>
                                </div>
                            </div> 

                            <div class="row exibe_mais_filtros">
                                <div class="form-group col-md-5">
                                    <label for="codigo_conta" class="control-label" style="font-size: 14px;"><span class="required">*</span> Contas Custo/Cabeça (máx 5 contas)</label>
                                    <select class="form-control selectpicker" multiple id="codigo_conta" name="codigo_conta">
                                    <?php 
                                        while($reg_conta = mysqli_fetch_object($tbl_contas)) { 
                                            echo '<option value="'.$reg_conta->tbl_plano_contas_codigo_id.'">' .$reg_conta->tbl_plano_contas_descricao. '
                                                </option>'; 
                                        } 
                                    ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-5">
                                    <label for="categoria" class="control-label" style="font-size: 14px;"><span class="required">*</span> Categoria para cálculo GMD Global</label>
                                    <select class="form-control"  id="categoria" name="categoria">
                                        <option value="000">Selecione Categorias</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="page-inner">
                    <div class="dashboard-cards"> 
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="card card-title">

                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <span class="titulo_gray"> 
                                                ZOOTÉCNICO
                                            </span>
                                                
                                            <img src="img/categoria.png" class="img-categoria" alt="">
                                                
                                        </div>
                                    </div>

                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <table class="" style="width:100%; font-size: 1.35rem; margin-top: 15px;">
                                                <tbody>
                                                    <tr> 
                                                        <td width="20%">Rebanho Total:</td>
                                                        <td id="total_unidade" width="20%" align="right" style="color: #548235 !important;"></td>
                                                        <td id="total_peso" width="20%" align="right" style="color: #548235 !important"></td>
                                                        <td id="total_arroba" width="20%" align="right" style="color: #548235 !important"></td>
                                                        <td width="20%"></td>

                                                    </tr>
                                                    <tr> 
                                                        <td width="20%">Rebanho Médio:</td>
                                                        <td id="media_unidade" width="20%" align="right" style="color: #548235 !important"></td>
                                                        <td id="media_peso" width="20%" align="right" style="color: #548235 !important"></td>
                                                        <td id="media_arroba" width="20%" align="right" style="color: #548235 !important"></td>
                                                        <td width="20%"></td>
                                                    </tr>
                                                    <tr> 
                                                        <td width="20%">Lotação Média:</td>
                                                        <td id="locacao_unidade" width="20%" align="right" style="color: #548235 !important">1,37 Cab/Ha</td>
                                                        <td id="lotacao_media" width="20%" align="right" style="color: #548235 !important">874 KgPc/Ha</td>
                                                        <td id="lotacao_ua" width="20%" align="right" style="color: #548235 !important">125 Ua/Ha</td>
                                                        <td width="20%"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <h2 class="chart-title">Lotação da Fazenda KgPc/Ha</h2>
                                            <div id="line_chart" style="height: 400px;">
                                            </div>
                                        </div>
                                    </div>

                                    <hr align="center">

                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <table class="" style="width:100%; font-size: 1.35rem; margin-top: 5px; margin-bottom: 15px;">
                                                <tbody>
                                                    <tr> 
                                                        <td width="15%">GMD Global:</td>
                                                        <td id="gmd_global" width="8%" align="right" style="color: #548235 !important">0,022</td>
                                                    </tr>

                                                    <tr>
                                                        <td width="15%">Produção @:</td>
                                                        <td id="producao_arroba" width="8%" align="right" style="color: #548235 !important">503 @</td>
                                                        <td width="77%"></td>
                                                    </tr>

                                                    <tr>
                                                        <td width="15%">Giro Estoque:</td>
                                                        <td id="giro_estoque" width="8%" align="right" style="color: #548235 !important">0</td>
                                                        <td width="77%"></td>
                                                    </tr>

                                                    <tr> 
                                                        <td  width="100%" colspan="3" id="filtro_gmd_global" style="font-size: 10px;"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="card card-title">
                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <span class="titulo_gray"> 
                                                FINANCEIROS
                                            </span>

                                            <img src="img/financeiro.png" class="img_financeiro" alt="">
                                        </div>
                                    </div>

                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <table class="" style="width:100%; font-size: 1.35rem; margin-top: 15px;">
                                                <tbody>
                                                    <tr> 
                                                        <td width="20%">Custo Total/Cab:</td>
                                                        <td id="custo_total" width="20%" align="right" style="color: #548235 !important;">R$ 12.352,69</td>
                                                        <td width="60%"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <h2 class="chart-title">Custo/Cabeça</h2>
                                            <div id="chart_div" style="height: 260px; padding: 0; margin: 0;">
                                            </div>
                                        </div>
                                    </div>

                                    <hr align="center">

                                    <div class="row margem_esquerda">
                                        <div class="col-md-12">
                                            <h2 class="chart-title" style="margin-top: 0;">% Gastos por Conta</h2>
                                            <div id="piechart" style="margin-top: 0; height: 420px; padding: 0;">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="mensagem_erro" tabindex="-1" role="dialog" 
                    aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    <h4 class="modal-title">Relatórios Estratégicos - Mensagem</h4>
                            </div>
                            <div class="modal-body"></div>
                            <div class="modal-footer">
                                <button data-dismiss="modal" class="btn btn-default" type="button" >Fechar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="categoria_gmd" tabindex="-1" role="dialog" 
                    aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    <h4 class="modal-title">Categorias para Cálculo do GMD Glocal</h4>
                            </div>

                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="categorias_gmd" style="width:100%;">
                                            <tbody>
                                                <tr> 
                                                    <td width="28%">
                                                        <input type="checkbox" id="c001">&nbsp;&nbsp;00 a 07 meses
                                                    </td>
                                                    <td width="20%" class="sexo1">
                                                        <input type="checkbox" id="M001">&nbsp;&nbsp;Macho

                                                        <input type="checkbox" id="F001">&nbsp;&nbsp;Fêmea
                                                    </td>
                                                    <td width="52%"></td>
                                                </tr>
                                                <tr> 
                                                    <td width="28%">
                                                        <input type="checkbox" id="c002">&nbsp;&nbsp;
                                                        08 a 12 meses
                                                    </td>
                                                    <td width="20%" class="sexo2">
                                                        <input type="checkbox" id="M002">&nbsp;&nbsp;Macho

                                                        <input type="checkbox" id="F002">&nbsp;&nbsp;Fêmea
                                                    </td>
                                                    <td width="52%"></td>
                                                </tr>
                                                <tr> 
                                                    <td width="28%">
                                                        <input type="checkbox" id="c003">&nbsp;&nbsp;
                                                        13 a 24 meses
                                                    </td>
                                                    <td width="20%" class="sexo3">
                                                        <input type="checkbox" id="M003">&nbsp;&nbsp;Macho

                                                        <input type="checkbox" id="F003">&nbsp;&nbsp;Fêmea
                                                    </td>
                                                    <td width="52%"></td>
                                                </tr>
                                                <tr> 
                                                    <td width="28%">
                                                        <input type="checkbox" id="c004">&nbsp;&nbsp;
                                                        25 a 36 meses
                                                    </td>
                                                    <td width="20%" class="sexo4">
                                                        <input type="checkbox" id="M004">&nbsp;&nbsp;Macho

                                                        <input type="checkbox" id="F004">&nbsp;&nbsp;Fêmea
                                                    </td>
                                                    <td width="52%"></td>
                                                </tr>
                                                <tr> 
                                                    <td width="28%">
                                                        <input type="checkbox" id="c005">&nbsp;&nbsp;
                                                        > 36 meses
                                                    </td>
                                                    <td width="20%" class="sexo5">
                                                        <input type="checkbox" id="M005">&nbsp;&nbsp;Macho

                                                        <input type="checkbox" id="F005">&nbsp;&nbsp;Fêmea
                                                    </td>
                                                    <td width="52%"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button data-dismiss="modal" class="btn btn-primary" onclick="gerar_categoria()" type="button">Confirmar
                                </button>
                                <button data-dismiss="modal" class="btn btn-info pull-right" type="button">Voltar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </section> <!--main content end-->
        </section>   <!-- container section start -->

        <div class="text-center">
            <div class="credits">
                <font size="2"><p style="color:#C0C0C0">Copyright &copy; Boi Virtual 2023</p></font>
            </div>
        </div>

    </section> <!-- container section start end -->

    <!--<script src="js/jquery.js?<?php echo Versao; ?>"></script>
    <script src="js/jquery.nicescroll.js?<?php echo Versao; ?>" type="text/javascript"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js?<?php echo Versao; ?>"></script>
    <script src="js/scripts.js?<?php echo Versao; ?>"></script>
    <script src="https://cdn.datatables.net/v/bs4/dt-1.10.22/r-2.2.6/datatables.min.js" type="text/javascript" ></script>
    <script src="js/opcoes_menu.js?<?php echo Versao; ?>"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js?<?php echo Versao; ?>"></script>
    <script src='js/jquery.redirect.js'></script>
    <script src="js/select-1.13.14.js"></script>-->

    <script src="js/jquery.js?<?php echo Versao; ?>"></script>
    <script src="js/jquery.nicescroll.js?<?php echo Versao; ?>" type="text/javascript"></script>
    <script src="js/scripts.js?<?php echo Versao; ?>"></script>
    <script src="js/relatorios_estrategicos.js?<?php echo Versao; ?>" charset="utf-8" type="text/javascript" ></script>
    <script src="js/opcoes_menu.js?<?php echo Versao; ?>"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js?<?php echo Versao; ?>"></script>

    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js" charset="utf-8" type="text/javascript" >
    </script>

    <script src="https://cdn.datatables.net/fixedcolumns/3.3.1/js/dataTables.fixedColumns.min.js
    " charset="utf-8" type="text/javascript" >
    </script>
    <script src="js/select-1.13.14.js"></script>


    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip({html:true}); 
        });
    </script>




</body>

</html>
