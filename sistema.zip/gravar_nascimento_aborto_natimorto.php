<?php 

@ session_start(); 
$nomeusuario = $_SESSION['nome_usuario'];
$controle_estoque = $_SESSION['controle_estoque'];

$tipo_gravacao = $_POST['tipo_gravacao'];
$num_mov_nascimento = $_POST['num_mov_nascimento'];

$local = $_POST['local_id'];
$pasto_id = $_POST['pasto_id'];
$ocorrencia = $_POST['opcao_nascimento'];
$data_ocorrencia = $_POST['nascimento_animal'];
$codigo_mae = $_POST['codigo_mae_animal'];
$data_sistema = date("Y-m-d");

$cobertura_id = $_POST['cobertura_id'];
$item_cobertura = $_POST['item_cobertura'];

// dados para a tabela tbl_movimentacao
$movimentacao_finalizada='N';
$codigo_tipo = 881;
$total_digitados = 1;
$peso_total_kg = 0.00;
$peso_total_arroba = 0.00;
$peso_medio_kg = 0.00;
$peso_medio_arroba = 0.00;
$data_inclusao = date("Y-m-d H:i:s");
$codigo_motivo_morte = 7;
$numero_item = 1;
$numero_movimentacao=0;

$data = date('d-m-Y', strtotime($data_ocorrencia));
$data_nascimento = str_replace("-", "/", $data);

/*$resposta = array('success' => true, 'message' => $data_nascimento);

header('Content-type: application/json');
echo json_encode($resposta);
exit;
*/

if ($local=='000000000'){
	header('Content-type: application/json');
	echo json_encode(array('error' => true, 'message' => 'Informe o Local.'));
	exit;
}

if ($codigo_mae==''){
	header('Content-type: application/json');
	echo json_encode(array('error' => true, 'message' => 'Informe o Nº da Fêmea.'));
	exit;
}

if ($data_ocorrencia==''){
	header('Content-type: application/json');
	echo json_encode(array('error' => true, 'message' => 'Informe a Data da Ocorrência.'));
	exit;
}

if(!isset($_POST['sexo_animal'])) { 
	$sexo = 'N';
}
else {
	$sexo = $_POST['sexo_animal'];
}

// entrada_saida = A (Aborto/Absorsao)
// entrada_saida = E (Entrada)

// ocorrencia = A (Aborto)
// ocorrencia = B (Absorção)
// ocorrencia = M (Nascimento - Natimorto)

if ($ocorrencia=='A') {
	$entrada_saida = "A";
	$tipo_movimentacao = "A";
	$nascido = 'A';
}
else if ($ocorrencia=='B') {
	$entrada_saida = "A";
	$tipo_movimentacao = "B";
	$nascido = 'A';
}
else {
	$entrada_saida = "E";
	$tipo_movimentacao = "N";
	$nascido = 'M';
}

/*$resposta = array('success' => true, 'message' => 'Registro incluído com sucesso.');

header('Content-type: application/json');
echo json_encode($resposta);
exit;*/


include "conecta_mysql.inc";

$id_animal = 999999999;

if ($codigo_mae!=''){
	$rs = mysqli_query($conector, "SELECT * FROM tbl_animais
	    WHERE tbl_animal_codigo_id='$codigo_mae'");

	$num_rows = mysqli_num_rows($rs);
	if ($num_rows!=0) {
	   	$reg_animal = mysqli_fetch_object($rs);
		$codigo_numerico_mae = $reg_animal->tbl_animal_codigo_alfa.$reg_animal->tbl_animal_codigo_numerico;
	}
}
else {
	$codigo_numerico_mae = '';
}

// tipo de gravacao = 0 Inclusao
if ($tipo_gravacao==0) {
	// Ocorrencia A = Aborto ou B = Absorsão, então tem que somar 1 aborto no cadastro de animal codigo da mae 
	if ($ocorrencia=='A' || $ocorrencia=='B') {
		$sql = "INSERT INTO tbl_movimentacao_estoque
			                (tbl_mov_estoque_codigo_id_animal,
			                 tbl_mov_estoque_data_emissao,
			                 tbl_mov_estoque_nascimento,
			                 tbl_mov_estoque_local,
			                 tbl_mov_estoque_entrada_saida,
			                 tbl_mov_estoque_tipo_movimentacao,
			                 tbl_mov_estoque_local_origem,
			                 tbl_mov_estoque_local_destino,
			                 tbl_mov_estoque_codigo_movimentacao,
			                 tbl_mov_estoque_codigo_pasto,
			                 tbl_mov_estoque_codigo_raca,
			                 tbl_mov_estoque_codigo_pelagem,
			                 tbl_mov_estoque_sexo,
			                 tbl_mov_estoque_primeiro_peso,
			                 tbl_mov_estoque_codigo_mae
			                ) 
			                VALUES ('$id_animal',
			                        '$data_sistema',
			                        '$data_ocorrencia',
			                        '$local',
			                        '$entrada_saida',
			                        '$tipo_movimentacao',
			                        '$local',
			                        null,
			                        '$numero_movimentacao',
			                        '$pasto_id',
			                        null,
			                        null,
			                        '$sexo',
			                        null,
			                        '$codigo_mae'
			                )";
			        
		$resultado = mysqli_query($conector,$sql);
		$resposta = array('success' => true, 'message' => 'Registro incluído com sucesso.');
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		 	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Erro na gravacao histórico do animal.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		}

		$tbl_animal = mysqli_query($conector, "SELECT * FROM tbl_animais
		    WHERE tbl_animal_codigo_id ='$codigo_mae'");

		$num_rows_animal = mysqli_num_rows($tbl_animal);	

		if ($num_rows_animal!=0) {
			$reg_animal = mysqli_fetch_object($tbl_animal);
			$numero_aborto =  $reg_animal->tbl_animal_numero_abortos;
			$numero_aborto++;
		}
		else {
			$numero_aborto = 1;
		}

		$sql = ("UPDATE tbl_animais SET 
				tbl_animal_numero_abortos='$numero_aborto'
			WHERE tbl_animal_codigo_id ='$codigo_mae'");

	    $resultado = mysqli_query($conector,$sql);
		$resposta = array('success' => true, 'message' => 'Registro incluido com sucesso.');
	    $erro_mysql = mysqli_error($conector);

		if (!$resultado){
		  	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Erro na atualização do número de abortos do animal.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		}
	}

	// Ocorrencia M = Natimorto, então tem que gerar um historico de morte
	if ($ocorrencia=='M') {

		$sql = "INSERT INTO tbl_movimentacao (
			    	tbl_movimentacao_controle,
			    	tbl_movimentacao_data,
					tbl_movimentacao_codigo_local_origem,
					tbl_movimentacao_codigo_local_destino,
					tbl_movimentacao_tipo,
					tbl_movimentacao_qtd_animais_pesados,
					tbl_movimentacao_peso_kg,
					tbl_movimentacao_peso_arroba,
					tbl_movimentacao_peso_medio_kg,
					tbl_movimentacao_peso_medio_arroba,
					tbl_movimentacao_filtros,
					tbl_movimentacao_situacao,
					tbl_movimentacao_incluido_em,
					tbl_movimentacao_incluido_por,
					tbl_movimentacao_alterado_em,
					tbl_movimentacao_alterado_por,
					tbl_movimentacao_lixeira,
					tbl_movimentacao_lixeira_em,
					tbl_movimentacao_lixeira_por,
					tbl_movimentacao_aceite_transferencia_em,
					tbl_movimentacao_aceite_transferencia_por,
					tbl_movimentacao_aceite_financeiro_em,
					tbl_movimentacao_aceite_financeiro_por,
					tbl_movimentacao_codigo_pesagem
			        ) VALUES (
			        '$controle_estoque',
			        '$data_ocorrencia',
					'$local',
					null,
					'$codigo_tipo',
					'$total_digitados',
					'$peso_total_kg',
					'$peso_total_arroba',
					'$peso_medio_kg',
					'$peso_medio_arroba',
					null,
					'$movimentacao_finalizada',
					'$data_inclusao',
					'$nomeusuario',
					null,
					null,
					0,
					null,
					null,
					null,
					null,
					null,
					null,
					null
				)";

		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		   	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro ao registrar a movimentação da morte'. $erro_mysql));
		   	mysqli_close($conector);
			exit;
		} 

		$numero_movimentacao = mysqli_insert_id($conector);
		$numero_movimentacao = str_pad($numero_movimentacao, 9, "0", STR_PAD_LEFT);

		$sql = "INSERT INTO tbl_item_movimentacao (
			            tbl_ite_movimentacao_numero_id,
			            tbl_ite_movimentacao_numero_item,
			            tbl_ite_movimentacao_data_emissao,
			            tbl_ite_movimentacao_codigo_id_animal,
			            tbl_ite_movimentacao_codigo_animal,
						tbl_ite_movimentacao_peso,
						tbl_ite_movimentacao_sexo,
						tbl_ite_movimentacao_nascimento,
						tbl_ite_movimentacao_raca,
						tbl_ite_movimentacao_pelagem,
						tbl_ite_movimentacao_mae,
						tbl_ite_movimentacao_observacao,
						tbl_ite_movimentacao_motivo_morte,
						tbl_ite_movimentacao_codigo_pasto,
						tbl_ite_movimentacao_codigo_categoria
			        ) VALUES (
			            '$numero_movimentacao',
			            '$numero_item',
			            '$data_ocorrencia',
			            '$id_animal',
			            0,
			            null,
			            '$sexo',
			            '$data_nascimento',
			            null,
			            null,
			            '$codigo_numerico_mae',
			            null,
			            '$codigo_motivo_morte',
			            '$pasto_id',
			            1
			    )";

		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		  	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro na gravação do item na morte.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		} 

		// Grava o Nascimento
		$sql = "INSERT INTO tbl_movimentacao_estoque
			                (tbl_mov_estoque_codigo_id_animal,
			                 tbl_mov_estoque_data_emissao,
			                 tbl_mov_estoque_nascimento,
			                 tbl_mov_estoque_local,
			                 tbl_mov_estoque_entrada_saida,
			                 tbl_mov_estoque_tipo_movimentacao,
			                 tbl_mov_estoque_local_origem,
			                 tbl_mov_estoque_local_destino,
			                 tbl_mov_estoque_codigo_movimentacao,
			                 tbl_mov_estoque_codigo_pasto,
			                 tbl_mov_estoque_codigo_raca,
			                 tbl_mov_estoque_codigo_pelagem,
			                 tbl_mov_estoque_sexo,
			                 tbl_mov_estoque_primeiro_peso,
			                 tbl_mov_estoque_codigo_mae
			                ) 
			                VALUES ('$id_animal',
			                        '$data_sistema',
			                        '$data_ocorrencia',
			                        '$local',
			                        '$entrada_saida',
			                        '$tipo_movimentacao',
			                        '$local',
			                        null,
			                        '$numero_movimentacao',
			                        '$pasto_id',
			                        null,
			                        null,
			                        '$sexo',
			                        null,
			                        '$codigo_mae'
			                )";
			        
		$resultado = mysqli_query($conector,$sql);
		$resposta = array('success' => true, 'message' => 'Registro incluído com sucesso.');
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		 	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Erro na gravacao histórico do animal.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		}

		// Grava a Morte
		$sql = "INSERT INTO tbl_movimentacao_estoque
					                (tbl_mov_estoque_codigo_id_animal,
					                 tbl_mov_estoque_data_emissao,
					                 tbl_mov_estoque_nascimento,
					                 tbl_mov_estoque_local,
					                 tbl_mov_estoque_entrada_saida,
					                 tbl_mov_estoque_tipo_movimentacao,
					                 tbl_mov_estoque_local_origem,
					                 tbl_mov_estoque_local_destino,
					                 tbl_mov_estoque_codigo_movimentacao,
					                 tbl_mov_estoque_codigo_pasto,
					                 tbl_mov_estoque_codigo_raca,
					                 tbl_mov_estoque_codigo_pelagem,
					                 tbl_mov_estoque_sexo,
					                 tbl_mov_estoque_primeiro_peso,
					                 tbl_mov_estoque_codigo_mae
					                ) 
					                VALUES ('$id_animal',
					                        '$data_sistema',
					                        '$data_ocorrencia',
					                        '$local',
					                        'S',
					                        'M',
					                        '$local',
					                        null,
					                        '$numero_movimentacao',
					                        '$pasto_id',
					                        null,
					                        null,
					                        '$sexo',
					                        null,
					                        '$codigo_mae'
					                )";
					        
		$resultado = mysqli_query($conector,$sql);
		$resposta = array('success' => true, 'message' => 'Registro incluído com sucesso.');
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
		  	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Erro na gravacao histórico de morte do animal .' . $erro_mysql));
			mysqli_close($conector);
			exit;
		}
	}

    // Altera o item de cobertura informando que houve aborto, absorção ou natimorto

	$sql = ("UPDATE tbl_item_cobertura SET 
			tbl_ite_cobertura_aborto_natimorto=1,
	   		tbl_ite_cobertura_nascido='$nascido'
		WHERE tbl_ite_cobertura_numero_id ='$cobertura_id' AND 
		      tbl_ite_cobertura_numero_item = '$item_cobertura'");

    $resultado = mysqli_query($conector,$sql);
	$resposta = array('success' => true, 'message' => 'Registro incluido com sucesso.');
    $erro_mysql = mysqli_error($conector);

	if (!$resultado){
	  	header('Content-type: application/json');
	   	echo json_encode(array('error' => true, 'message' => 'Erro na atualização do item de cobertura.' . $erro_mysql));
		mysqli_close($conector);
		exit;
	}
}

header('Content-type: application/json');
echo json_encode($resposta);
mysqli_close($conector);
exit;

?>