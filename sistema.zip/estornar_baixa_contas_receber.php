<?php

include "conecta_mysql.inc";
$mensagem = 0;

$bcr_chave_baixa = $_POST['bcr_chave'];
$numero = substr($bcr_chave_baixa, 0, 10);
$parcela = substr($bcr_chave_baixa, 10, 3);
$sequencia = substr($bcr_chave_baixa, 13, 9);

$sql = ("DELETE FROM baixa_contas_receber WHERE bcr_numero_id='$numero' and 
                                                bcr_parcela='$parcela' and 
							                    bcr_sequencia='$sequencia'");

$resultado = mysqli_query($conector,$sql);

$ssql = "select * from baixa_contas_receber 
                 where bcr_numero_id='$numero' and 
                       bcr_parcela='$parcela'";

$conta_baixada = mysqli_query($conector,$ssql);

$num_rows = mysqli_num_rows($conta_baixada);

if ($num_rows != 0) {
    $sql = ("UPDATE contas_receber SET ctr_situacao='C'
	         WHERE ctr_numero_doc='$numero' and ctr_parcela='$parcela'");
} else {
    $sql = ("UPDATE contas_receber SET ctr_situacao=''
	         WHERE ctr_numero_doc='$numero' and ctr_parcela='$parcela'");
}

$resultado = mysqli_query($conector,$sql);

if (!$resultado) {
    $mensagem = "Erro na atualizacao da conta" . "\n" . mysql_error();
}

echo $mensagem;

mysqli_close($conector);
?>


