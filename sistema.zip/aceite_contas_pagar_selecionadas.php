<?php

@ session_start();
$usuario_agendamento = $_SESSION['nome_usuario'];
$data_sistema = date("Y/m/d H:i:s");
$mensagem = 0;

$grupo_contas = $_POST['grupo_contas'];
$matriz_contas = explode("<|>", $grupo_contas);
$quantidade_itens = count($matriz_contas);

include "conecta_mysql.inc";
			
for($i=0; $i < $quantidade_itens; $i++) {
    $codigo_fornecedor = substr($matriz_contas[$i],0,9);
	$numero_ctp = substr($matriz_contas[$i],9,15);

	$sql = ("UPDATE contas_pagar SET ctp_aceite='S',
   	                                 ctp_data_aceite='$data_sistema',
            				 		 ctp_usuario_aceite='$usuario_agendamento'
                               WHERE ctp_numero_documento='$numero_ctp' AND 
                                     ctp_codigo_fornecedor='$codigo_fornecedor'");
    $resultado = mysqli_query($conector, $sql);
    if (!$resultado) {
    	$mensagem = "Erro no aceite da conta" . "\n" . mysqli_error($conector);
	}
}

echo $mensagem;
mysqli_close($conector);

?>