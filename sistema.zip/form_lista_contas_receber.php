<?php
    include "conecta_mysql.inc";

    function tirarAcentos($string){
        return preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/","/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/"),explode(" ","a A e E i I o O u U n N"),$string);
    }


    $data_inicial = $_REQUEST["data_inicial"];
    $data_final = $_REQUEST["data_final"];
    $tipo_data = $_REQUEST["tipo_data"];
    $razao_nome = $_REQUEST["razao_nome"];
    $codigo_c_custo = $_REQUEST["codigo_c_custo"];

    @ session_start(); 
    $codigo_grupo_usuario = $_SESSION['grupo_usuario'];

    $_SESSION['data_inicio_ctr']=$data_inicial;
    $_SESSION['data_fim_ctr']=$data_final;
    $_SESSION['tipo_data_ctr']=$tipo_data;
    $_SESSION['razao_nome_ctr']=$razao_nome;
    $_SESSION['codigo_c_custo_ctr']=$codigo_c_custo;
    $_SESSION['lista_ctr']='S'; 

    $total_geral_parcelas = 0;
    $total_geral_pagos = 0;
    $total_pago=0;
    $data_sistema = date("Y-m-d");

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet">
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <link href="DataTables-1.10.18/css/dataTables.bootstrap4.min.css"rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

</head>

<body>
	<section class="panel">

        <table class="table table-striped table-advance table-hover" id="tabela_contas_receber" 
         width="100%" >
                          
            <tbody>
                <?php
                    $criterio="";

                    if ($razao_nome=='' && $codigo_c_custo==0){
                        if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="V"){
                            $criterio = " WHERE ctr_data_vencimento >='$data_inicial' and
                                                ctr_data_vencimento <='$data_final' and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_vencimento, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="E"){
                            $criterio = " WHERE ctr_data_emissao >='$data_inicial' and
                                                ctr_data_emissao <='$data_final' and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_emissao, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="P"){
                            $criterio = " WHERE bcr_data_pagamento >='$data_inicial' and
                                                bcr_data_pagamento <='$data_final'  and 
                                                ctr_lixeira = 0
                                       ORDER BY bcr_data_pagamento, bcr_numero_id ASC";
                        }
                    }
                    else if ($razao_nome=='' && $codigo_c_custo!=0){
                        if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="V"){
                            $criterio = " WHERE ctr_data_vencimento >='$data_inicial' and
                                                ctr_data_vencimento <='$data_final' and
                                                ctr_codigo_c_custo = $codigo_c_custo and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_vencimento, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="E"){
                            $criterio = " WHERE ctr_data_emissao >='$data_inicial' and
                                                ctr_data_emissao <='$data_final'  and
                                                ctr_codigo_c_custo = $codigo_c_custo and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_emissao, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="P"){
                            $criterio = " WHERE bcr_data_pagamento >='$data_inicial' and
                                                bcr_data_pagamento <='$data_final'  and
                                                ctr_codigo_c_custo = $codigo_c_custo and 
                                                ctr_lixeira = 0
                                       ORDER BY bcr_data_pagamento, bcr_numero_id ASC";
                        }
                    }
                    else {
                        if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="V" && $codigo_c_custo==0){
                            $criterio = " WHERE ctr_data_vencimento >='$data_inicial' and
                                                ctr_data_vencimento <='$data_final' and
                                                ctr_nome_cliente like '%" . $razao_nome . "%' and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_vencimento, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="V" && $codigo_c_custo!=0){
                            $criterio = " WHERE ctr_data_vencimento >='$data_inicial' and
                                                ctr_data_vencimento <='$data_final' and
                                                ctr_nome_cliente like '%" . $razao_nome . "%'  and
                                                ctr_codigo_c_custo = $codigo_c_custo and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_vencimento, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="E" && $codigo_c_custo==0){
                            $criterio = " WHERE ctr_data_emissao >='$data_inicial' and
                                                ctr_data_emissao <='$data_final'  and
                                                ctr_nome_cliente like '%" . $razao_nome . "%' and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_emissao, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="E" && $codigo_c_custo!=0){
                            $criterio = " WHERE ctr_data_emissao >='$data_inicial' and
                                                ctr_data_emissao <='$data_final'  and
                                                ctr_nome_cliente like '%" . $razao_nome . "%'  and
                                                ctr_codigo_c_custo = $codigo_c_custo and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_emissao, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="P" && $codigo_c_custo==0){
                            $criterio = " WHERE bcr_data_pagamento >='$data_inicial' and
                                                bcr_data_pagamento <='$data_final'  and
                                                ctr_nome_cliente like '%" . $razao_nome . "%' and 
                                                ctr_lixeira = 0
                                       ORDER BY bcr_data_pagamento, bcr_numero_id ASC";
                        }
                        else if ($data_inicial!=0 && $data_final!=0 && $tipo_data=="P" && $codigo_c_custo!=0){
                            $criterio = " WHERE bcr_data_pagamento >='$data_inicial' and
                                                bcr_data_pagamento <='$data_final'  and
                                                ctr_nome_cliente like '%" . $razao_nome . "%'  and
                                                ctr_codigo_c_custo = $codigo_c_custo and 
                                                ctr_lixeira = 0
                                       ORDER BY bcr_data_pagamento, bcr_numero_id ASC";
                        }
                        else if ($data_inicial==0 && $data_final==0 && $codigo_c_custo==0){
                            $criterio = " WHERE ctr_nome_cliente like '%" . $razao_nome . "%' and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_emissao, ctr_numero_doc ASC";
                        }
                        else if ($data_inicial==0 && $data_final==0 && $codigo_c_custo!=0){
                            $criterio = " WHERE ctr_nome_cliente like '%" . $razao_nome . "%'  and
                                                ctr_codigo_c_custo = $codigo_c_custo and 
                                                ctr_lixeira = 0
                                       ORDER BY ctr_data_emissao, ctr_numero_doc ASC";
                        }
                    }

                    if ($criterio=='') {
                        mysqli_close($conector);
                        exit;
                    }
                    else {    
                        if ($tipo_data=="P"){
                            $ssql = "SELECT * FROM baixa_contas_receber
                                        INNER JOIN contas_receber
                                                ON bcr_numero_id=ctr_numero_doc AND
                                                   bcr_parcela=ctr_parcela" . $criterio; 
                        }
                        else {
                            $ssql = "SELECT * FROM contas_receber" . $criterio; 
                        }
                        $rs = mysqli_query($conector, $ssql); 
                                
                        $total_geral_parcelas = 0;
                        $total_geral_pagos = 0;
                        $total_aberto = 0;
                        $registros_encontrados = mysqli_num_rows($rs);

                        while ($registro_ctr = mysqli_fetch_object($rs)){
                                    //$dias_vencimento = diferenca_data($registro_ctr->cliente_validade_contrato); 
                            if ($tipo_data=="P"){
                                $numero_doc = $registro_ctr->bcr_numero_id;
                                $numero_parcela = $registro_ctr->bcr_parcela;
                                $razao = tirarAcentos($registro_ctr->ctr_nome_cliente); 
                                $data_pagamento = $registro_ctr->bcr_data_pagamento; 
                                $total_pago = $registro_ctr->bcr_valor_pagamento; 
                                $situacao = $registro_ctr->bcr_situacao;
                                $codigo_forma_pagto = $registro_ctr->ctr_codigo_forma_recebimento;
                                $codigo_conta_pagto = $registro_ctr->ctr_codigo_conta_recebimento;
                                $data_emissao = $registro_ctr->ctr_data_emissao; 
                                $data_vencimento = $registro_ctr->ctr_data_vencimento; 
                                $vlr_parcela = $registro_ctr->ctr_valor_parcela; 
                                $vlr_juros = $registro_ctr->ctr_valor_juros; 
                                $vlr_desconto = $registro_ctr->ctr_valor_desconto; 
                                $vlr_acrescimo = $registro_ctr->ctr_valor_acrescimo; 
                                $vlr_parcela = $vlr_parcela + $vlr_juros + $vlr_acrescimo - $vlr_desconto;

                                $codigo_conta = $registro_ctr->ctr_codigo_conta;

                                $conta = "SELECT * FROM tbl_plano_contas
                                                   WHERE tbl_plano_contas_codigo_id='$codigo_conta'"; 
                                $conta_query = mysqli_query($conector, $conta);
                                $reg_conta = mysqli_fetch_object($conta_query);
                                $desc_conta = substr($reg_conta->tbl_plano_contas_descricao, 0,10);

                                $doc_parcela = $numero_doc . '-' . $numero_parcela;
                                $chave_ctr = $numero_doc . $numero_parcela;
                                $emissao_edi = new DateTime($data_emissao);
                                $vencimento_edi = new DateTime($data_vencimento);
                                $pagamento_edi = new DateTime($data_pagamento);

                                $total_geral_parcelas+= $vlr_parcela;
                                $total_geral_pagos+= $total_pago;
                            }
                            else {
                                $numero_doc = $registro_ctr->ctr_numero_doc;
                                $numero_parcela = $registro_ctr->ctr_parcela;
                                $razao = tirarAcentos($registro_ctr->ctr_nome_cliente); 
                                $data_emissao = $registro_ctr->ctr_data_emissao; 
                                $data_vencimento = $registro_ctr->ctr_data_vencimento; 
                                $vlr_parcela = $registro_ctr->ctr_valor_parcela; 
                                $vlr_juros = $registro_ctr->ctr_valor_juros; 
                                $vlr_desconto = $registro_ctr->ctr_valor_desconto; 
                                $vlr_acrescimo = $registro_ctr->ctr_valor_acrescimo; 
                                $vlr_parcela = $vlr_parcela + $vlr_juros + $vlr_acrescimo - $vlr_desconto;
                                $codigo_forma_pagto = $registro_ctr->ctr_codigo_forma_recebimento;
                                $codigo_conta_pagto = $registro_ctr->ctr_codigo_conta_recebimento;
                                $situacao = $registro_ctr->ctr_situacao;
                                $codigo_conta = $registro_ctr->ctr_codigo_conta;

                                $conta = "SELECT * FROM tbl_plano_contas
                                                   WHERE tbl_plano_contas_codigo_id='$codigo_conta'"; 
                                $conta_query = mysqli_query($conector, $conta);
                                $reg_conta = mysqli_fetch_object($conta_query);
                                $desc_conta = substr($reg_conta->tbl_plano_contas_descricao, 0,10);

                                $contas_baixadas = mysqli_query($conector, "SELECT * FROM 
                                                 baixa_contas_receber
                                                 WHERE bcr_numero_id='$numero_doc' AND
                                                       bcr_parcela='$numero_parcela'"); 

                                $num_rows_contas = mysqli_num_rows($contas_baixadas);
                                $total_pago=0;

                                if ($num_rows_contas!=0){
                                    while ($fila_baixada = mysqli_fetch_object($contas_baixadas)) {
                                        $valor_pagamento = $fila_baixada->bcr_valor_pagamento;
                                        $total_pago = $total_pago + $valor_pagamento;
                                        $data_pagamento = $fila_baixada->bcr_data_pagamento;
                                        $pagamento_edi = new DateTime($data_pagamento);

                                    }
                                }   
                                else {
                                    $pagamento_edi = "";
                                } 

                                $doc_parcela = $numero_doc . '-' . $numero_parcela;
                                $chave_ctr = $numero_doc . $numero_parcela;
                                $emissao_edi = new DateTime($data_emissao);
                                $vencimento_edi = new DateTime($data_vencimento);

                                $total_geral_parcelas+= $vlr_parcela;
                                $total_geral_pagos+= $total_pago;

                            }

                            $total_aberto = $total_geral_parcelas - $total_geral_pagos;

                            echo "<tr>";

                            if ($situacao=="P"){
                                echo "<td width='2%'><i class='btn icon_check' style='color:green' data-toggle='tooltip' data-placement='left' title='Pago' ></i></td>";
                                echo "<td width='13%'>".$doc_parcela."</td>";
                                echo "<td width='10%'>".$desc_conta."</td>";
                                echo "<td width='8%'>".$vencimento_edi->format('d/m/Y')."</td>";
                                echo "<td width='8%'>".$emissao_edi->format('d/m/Y')."</td>";
                                echo "<td width='20%'>".$razao."</td>";
                                echo "<td width='8%'>".number_format($vlr_parcela, 2, ",", ".")."</td>";
                                echo "<td width='8%'>".$pagamento_edi->format('d/m/Y')."</td>";
                                echo "<td width='8%'>".number_format($total_pago, 2, ",", ".")."</td>";

                                if ($codigo_grupo_usuario==1 || $codigo_grupo_usuario==2 || $codigo_grupo_usuario==4){
                                    echo "<td width='15%'>";
                                    echo "<div class='btn-group'>";
                                    echo "<a class='btn' href='form_contas_receber_editar.php?id=".$numero_doc."&parcela=".$numero_parcela."'><i class='icon_pencil' data-toggle='tooltip' data-placement='left' title='Editar esse registro' ></i></a>";
                                    echo "</div>";
                                    echo "</td>";
                                }   
                                else {
                                    echo "<td width='15%'>";
                                    echo "<div class='btn-group'>";
                                    echo "<a class='btn' href='form_contas_receber_editar.php?id=".$numero_doc."&parcela=".$numero_parcela."'><i class='icon_search' data-toggle='tooltip' data-placement='left' title='Consultar esse registro' ></i></a>";
                                    echo "</div>";
                                    echo "</td>";

                                }                              
                            }
                            else {
                                if ($data_vencimento<$data_sistema) {
                                    echo "<td width='2%'>
                                        <input type='checkbox' name='id_ctr' class='checkbox1' data-toggle='tooltip' data-placement='top' 
                                           title='Seleciona esse registro para baixar' 
                                         onClick='somar_total_para_baixar()' value='" . $chave_ctr . "'></td>";
                                    echo "<td width='13%' style='color:#B22222'>".$doc_parcela."</td>";
                                    echo "<td width='10%' style='color:#B22222'>".$desc_conta."</td>";
                                    echo "<td width='8%' style='color:#B22222'>".$vencimento_edi->format('d/m/Y')."</td>";
                                    echo "<td width='8%' style='color:#B22222'>".$emissao_edi->format('d/m/Y')."</td>";
                                    echo "<td width='20%' style='color:#B22222'>".$razao."</td>";
                                    echo "<td width='8%' style='color:#B22222'>".number_format($vlr_parcela, 2, ",", ".")."</td>";

                                    if ($situacao=="P" || $situacao=="C"){
                                        echo "<td width='8%' style='color:#B22222'>".$pagamento_edi->format('d/m/Y')."</td>";
                                        echo "<td width='8%' style='color:#B22222'>".number_format($total_pago, 2, ",", ".")."</td>";
                                    }
                                    else {
                                        echo "<td width='8%'></td>";
                                        echo "<td width='8%'></td>";
                                    }

                                    if ($codigo_grupo_usuario==1 || $codigo_grupo_usuario==2 || $codigo_grupo_usuario==4){
                                        echo "<td width='15%'>";
                                        echo "<div class='btn-group'>";
                                        echo "<a class='btn' href='form_contas_receber_editar.php?id=".$numero_doc."&parcela=".$numero_parcela."'><i class='icon_pencil' data-toggle='tooltip' data-placement='left' title='Editar esse registro' ></i></a>";
                                        echo "<a class='btn' href='#'><i class='icon_trash_alt' data-toggle='tooltip' data-placement='left' title='Excluir esse registro' onClick='enviar_lixeira(\"{$numero_doc}\",\"{$numero_parcela}\",1)' ></i></a>"; 

                                        echo '<a class="btn" href="#" 
                                                data-toggle="modal" 
                                                data-target="#modal_baixar" 
                                                data-wdoc="'.$numero_doc.'"
                                                data-wparcela="'.$numero_parcela.'"
                                                data-wvalor="'.$vlr_parcela.'"
                                                data-wvencimento="'.$data_vencimento.'"
                                                data-wcontapag="'.$codigo_conta_pagto.'"
                                                >
                                                <i class="icon_folder_download" data-toggle="tooltip" data-placement="left"  title="Baixar esse registro" ></i>
                                                </a>';
                                        echo "</div>";
                                        echo "</td>";
                                    }
                                    else {
                                        echo "<td width='15%'>";
                                        echo "<div class='btn-group'>";
                                        echo "<a class='btn' href='form_contas_receber_editar.php?id=".$numero_doc."&parcela=".$numero_parcela."'><i class='icon_search' data-toggle='tooltip' data-placement='left' title='Consultar esse registro' ></i></a>";
                                        echo '<a class="btn" href="#" 
                                                data-toggle="modal" 
                                                data-target="#modal_baixar" 
                                                data-wdoc="'.$numero_doc.'"
                                                data-wparcela="'.$numero_parcela.'"
                                                data-wvalor="'.$vlr_parcela.'"
                                                data-wvencimento="'.$data_vencimento.'"
                                                data-wcontapag="'.$codigo_conta_pagto.'"
                                                >
                                                <i class="icon_folder_download" data-toggle="tooltip" data-placement="left"  title="Baixar esse registro" ></i>
                                                </a>';
                                        echo "</div>";
                                        echo "</td>";
                                    }
                                }
                                else {
                                    echo "<td width='2%'>
                                        <input type='checkbox' name='id_ctr' class='checkbox1' 
                                         data-toggle='tooltip' data-placement='top'
                                         title='Seleciona esse registro para baixar' 
                                         onClick='somar_total_para_baixar()' value='" . $chave_ctr . "'</td>";
                                    echo "<td width='13%'>".$doc_parcela."</td>";
                                    echo "<td width='10%'>".$desc_conta."</td>";
                                    echo "<td width='8%'>".$vencimento_edi->format('d/m/Y')."</td>";
                                    echo "<td width='8%'>".$emissao_edi->format('d/m/Y')."</td>";
                                    echo "<td width='20%'>".$razao."</td>";
                                    echo "<td width='8%'>".number_format($vlr_parcela, 2, ",", ".")."</td>";

                                    if ($situacao=="P" || $situacao=="C"){
                                        echo "<td width='8%'>".$pagamento_edi->format('d/m/Y')."</td>";
                                        echo "<td width='8%'>".number_format($total_pago, 2, ",", ".")."</td>";
                                    }
                                    else {
                                        echo "<td width='8%'></td>";
                                        echo "<td width='8%'></td>";
                                    }

                                    if ($codigo_grupo_usuario==1 || $codigo_grupo_usuario==2 || $codigo_grupo_usuario==4){
                                        echo "<td width='15%'>";
                                        echo "<div class='btn-group'>";
                                        echo "<a class='btn' href='form_contas_receber_editar.php?id=".$numero_doc."&parcela=".$numero_parcela."'><i class='icon_pencil' data-toggle='tooltip' data-placement='left' title='Editar esse registro' ></i></a>";
                                        echo "<a class='btn' href='#'><i class='icon_trash_alt' data-toggle='tooltip' data-placement='left' title='Excluir esse registro' onClick='enviar_lixeira(\"{$numero_doc}\",\"{$numero_parcela}\",1)' ></i></a>"; 

                                        echo '<a class="btn" href="#" 
                                                data-toggle="modal" 
                                                data-target="#modal_baixar" 
                                                data-wdoc="'.$numero_doc.'"
                                                data-wparcela="'.$numero_parcela.'"
                                                data-wvalor="'.$vlr_parcela.'"
                                                data-wvencimento="'.$data_vencimento.'"
                                                data-wcontapag="'.$codigo_conta_pagto.'"
                                                >
                                                <i class="icon_folder_download" data-toggle="tooltip" data-placement="left"  title="Baixar esse registro" ></i>
                                                </a>';
                                        echo "</div>";
                                        echo "</td>";
                                    }
                                    else {
                                        echo "<td width='15%'>";
                                        echo "<div class='btn-group'>";
                                        echo "<a class='btn' href='form_contas_receber_editar.php?id=".$numero_doc."&parcela=".$numero_parcela."'><i class='icon_search' data-toggle='tooltip' data-placement='left' title='Consultar esse registro' ></i></a>";
                                        echo '<a class="btn" href="#" 
                                                data-toggle="modal" 
                                                data-target="#modal_baixar" 
                                                data-wdoc="'.$numero_doc.'"
                                                data-wparcela="'.$numero_parcela.'"
                                                data-wvalor="'.$vlr_parcela.'"
                                                data-wvencimento="'.$data_vencimento.'"
                                                data-wcontapag="'.$codigo_conta_pagto.'"
                                                >
                                                <i class="icon_folder_download" data-toggle="tooltip" data-placement="left"  title="Baixar esse registro" ></i>
                                                </a>';
                                        echo "</div>";
                                        echo "</td>";

                                    }

                                }
                            }
                            echo "</tr>";
                        }         
                    }

                    mysqli_close($conector);
                ?>
            </tbody>


            <thead>
                <tr>
                    <div class="row col-md-8" id="total_contas">
                        <div class="form-group col-md-3">
                            <label class="control-label">Registros encontrados</label>
                            <input class="form-control form-control-sm" type="text" readonly=""
                            <?php echo "value='".$registros_encontrados."'";?>>
                        </div>

                        <div class="form-group col-md-3">
                            <label class="control-label">Total em Aberto</label>
                            <input class="form-control form-control-sm" type="text" readonly=""
                            <?php echo "value='".number_format($total_aberto, 2, ",", ".")."'";?>>
                        </div>

                        <div class="form-group col-md-3">
                            <label class="control-label">Total Recebido</label>
                            <input class="form-control form-control-sm" type="text" readonly=""
                            <?php echo "value='".number_format($total_geral_pagos, 2, ",", ".")."'";?>>
                        </div>

                        <div class="form-group col-md-3">
                            <label class="control-label">Total Geral</label>
                            <input class="form-control form-control-sm" type="text" readonly=""
                            <?php echo "value='".number_format($total_geral_parcelas, 2, ",", ".")."'";?>>
                        </div>
                    </div>
                </tr>

                <tr>
                    <div class="row col-md-8 confirmar_baixa_selecionados" hidden="">
                        <div class="form-group col-md-3">
                            <button type="button" class="btn btn-primary pull-left" id="baixar_selecionadas"
                            onClick="modal_baixar()" >Baixar Selecionados</button>
                        </div>
                    </div>
                </tr>

                <tr>
                    <th>
                        <input type="checkbox" class='checkbox1' id="seleciona_todos_somar" data-toggle="tooltip" data-placement="top" title="Selecionar Todos os registros para baixar">
                    </th> 
                    <th> Documento</th> 
                    <th> Conta</th>
                    <th> Vencimento</th>
                    <th> Emissão</th>
                    <th> Razão Social/Nome</th>
                    <th> Valor Parcela</th>
                    <th> Recebimento</th>
                    <th> Valor</th>
                    <th> <i class="icon_cogs"></i> Ações</th>
                </tr>
            </thead>
            <tfoot>
            </tfoot>
        </table>
    </section>


    <script src="js/contas_receber.js" charset="utf-8" type="text/javascript" ></script>

    <script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
    });
    </script>

</body>
</html>


                
                
