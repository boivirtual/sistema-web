<?php 
	include "conecta_mysql.inc";

	$mensagem_erro = '';
	$data_sistema = date("Y-m-d H:i:s");

	@ session_start(); 
	$nomeusuario = $_SESSION['nome_usuario'];
	$numero_cobertura= $_POST['numero_doc'];
	$local= $_POST['codigo_local'];
	$femeas_listadas= $_POST['femeas_listadas'];

	$uploaddir = 'planilhas_excel/';
	$uploadfile = $uploaddir . basename($_FILES['arquivo_excel']['name']);

    move_uploaded_file($_FILES['arquivo_excel']['tmp_name'], $uploadfile);

	require 'vendor/autoload.php'; //autoload do projeto

	use PhpOffice\PhpSpreadsheet\IOFactory; //classe responsável pelo load dos arquivos de planilha
	use PhpOffice\PhpSpreadsheet\Spreadsheet; //classe responsável pela manipulação da planilha

	$spreadsheet = IOFactory::load($uploadfile); //carregando a planilha spreadsheet2 em um objeto PHP

	$sheet = $spreadsheet->getActiveSheet(); //retornando a aba ativa

	$num_planilha = $sheet->getCell('B3')->getValue();

	if ($num_planilha!=$numero_cobertura) {
		$mensagem_erro = 'O nº da planilha não corresponde ao nº do documento informado';
		echo '
			<script type="text/javascript">
				location.href="form_selecao_matrizes.php?editar=true&erro='.$mensagem_erro.'";
			</script>';
		mysqli_close($conector);
		exit;
	}

	$numero_linhas = $femeas_listadas + 5;
	$tem_item_confirmado = '';

	for ($i=6; $i <=$numero_linhas; $i++) { 
		$celula = "A" . $i;
		$confirma = $sheet->getCell($celula)->getValue(); //$cellA1 recebe os dados da célula A1

		if ($confirma!='') {
			$tem_item_confirmado = 'S';
		}
	}
	
	if ($tem_item_confirmado=='') {
		$mensagem_erro = 'Não existem fêmeas confirmadas nessa tabela';
		echo '
			<script type="text/javascript">
				location.href="form_selecao_matrizes.php?editar=true&erro='.$mensagem_erro.'";
			</script>';
		mysqli_close($conector);
		exit;
	}

	for ($i=6; $i <=$numero_linhas; $i++) { 
		$celula = "A" . $i;
		$confirma = $sheet->getCell($celula)->getValue(); //$cellA1 recebe os dados da célula A1

		$celula = "B" . $i;
		$codigo = $sheet->getCell($celula)->getValue(); //$cellA1 recebe os dados da célula A1

	 	$tbl_item_cobertura = mysqli_query($conector, "SELECT * FROM tbl_item_cobertura
	             WHERE tbl_ite_cobertura_numero_id ='$numero_cobertura' AND 
	             	   tbl_ite_cobertura_codigo_animal='$codigo'");

	    $num_rows = mysqli_num_rows($tbl_item_cobertura);

	    if ($num_rows!=0) {
		    $reg_item = mysqli_fetch_object($tbl_item_cobertura);
		    $codigo_animal_id = $reg_item->tbl_ite_cobertura_codigo_id_animal;
		    $numero_item = $reg_item->tbl_ite_cobertura_numero_item;

		    if ($confirma=='') {
			    $sql = ("DELETE FROM tbl_item_cobertura 
				    	WHERE tbl_ite_cobertura_numero_id = '$numero_cobertura' AND 
				    		  tbl_ite_cobertura_numero_item = '$numero_item'");

				$resultado = mysqli_query($conector,$sql);
				$erro_mysql = mysqli_error($conector);

				if (!$resultado){
					$mensagem_erro = 'Ocorreu um erro na exclusão do item. Id animal: ' . 
					$codigo . ' ' . $erro_mysql;
					echo '
						<script type="text/javascript">
							location.href="form_selecao_matrizes.php?editar=true&erro='.$mensagem_erro.'";
						</script>';
					mysqli_close($conector);
					exit;
				}

				$femeas_listadas--;
			} 
		}
	}

	if ($femeas_listadas>0) {
		$sql = "UPDATE tbl_cobertura SET
		  		tbl_cobertura_qtd_animais='$femeas_listadas',
				tbl_cobertura_alterado_em='$data_sistema',
				tbl_cobertura_alterado_por='$nomeusuario',
				tbl_cobertura_planilha_processada='S'
		WHERE tbl_cobertura_id='$numero_cobertura'";

		$resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
			$mensagem_erro = 'Ocorreu um erro ao alterar o registro do cobertura ' . $erro_mysql;
			echo '
				<script type="text/javascript">
					location.href="form_selecao_matrizes.php?editar=true&erro='.$mensagem_erro.'";
				</script>';
			mysqli_close($conector);
			exit;
		} 
	}

unlink($uploadfile);
mysqli_close($conector);

$mensagem_erro = 'Planilha processada com sucesso';

echo '
	<script type="text/javascript">

		location.href="form_selecao_matrizes_incluir.php?editar=true&id_cobertura='.$numero_cobertura.'";
	</script>';

?>