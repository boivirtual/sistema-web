<?php
    include "conecta_mysql.inc";

    $tipo_registro = $_POST['tipo_registro'];
    $local = $_POST['local'];
    $estacao_monta = $_POST["estacao_monta"];

    @ session_start(); 

    $_SESSION['local_matrizes']=$local;
    $_SESSION['estacao_monta_matrizes']=$estacao_monta; 
    $_SESSION['tipo_registro_matrizes']=$tipo_registro;
    $_SESSION['lista_matrizes']='S';    
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet">
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <link href="DataTables-1.10.18/css/dataTables.bootstrap4.min.css"rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

  <style>
/*      .table_overflow table thead th{
        position: sticky;
        top: 0;
        z-index: 1;
      }
      .table_overflow th{
        background-color: #eee;
      }
      
      table.dataTable.no-footer{
          border: none;
      }

      #tabela_cobertura_wrapper{
          width: 100% !important;
          overflow-x: scroll !important;
          overflow-y: scroll !important;
          max-height: 300px;
      }

      #tabela_cobertura_filter{
          float: right;
      }*/
  </style>

</head>

<body> 

  <?php    
	echo '<section class="panel">';
    echo '<table class="table table-striped table-advance table-hover" id="tabela_matrizes" style="font-size: 12px">';
                          
    echo '<tbody>';
          
    $tbl_matrizes = mysqli_query($conector, "SELECT * FROM tbl_cobertura 
        WHERE tbl_cobertura_lixeira=0 AND 
              tbl_cobertura_controle='$tipo_registro' AND 
              tbl_cobertura_codigo_local='$local' AND 
              tbl_cobertura_codigo_estacao_monta='$estacao_monta'
        ORDER BY tbl_cobertura_codigo_local, tbl_cobertura_codigo_grupo ASC"); 

    $num_rows_matrizes = mysqli_num_rows($tbl_matrizes);

    if ($num_rows_matrizes!=0) {
        while ($reg_matrizes = mysqli_fetch_object($tbl_matrizes)){
            $codigo = $reg_matrizes->tbl_cobertura_id;
            $codigo_local = $reg_matrizes->tbl_cobertura_codigo_local;
            $codigo_grupo = $reg_matrizes->tbl_cobertura_codigo_grupo;
            $codigo_estacao = $reg_matrizes->tbl_cobertura_codigo_estacao_monta;
            $qtd_animais = $reg_matrizes->tbl_cobertura_qtd_animais;
            $protocolo = $reg_matrizes->tbl_cobertura_protocoloiatf;
            $iniciou_protocolo = '';
            $planilha_processada = $reg_matrizes->tbl_cobertura_planilha_processada;

            $itens = mysqli_query($conector, "SELECT * FROM tbl_item_cobertura
                    WHERE tbl_ite_cobertura_numero_id ='$codigo'");
            $num_rows_itens = mysqli_num_rows($itens);

            if ($num_rows_itens!=0){
                while ($fila = mysqli_fetch_object($itens)){
                    $dia_1 = $fila->tbl_ite_cobertura_dia_1;
                    $dia_2 = $fila->tbl_ite_cobertura_dia_2;
                
                    if ($dia_1=='S' || $dia_2=='S') {
                        $iniciou_protocolo = 'S';
                    }
                }
            }

            $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_id='$codigo_local'");
            $num_rows = mysqli_num_rows($tbl_local);

            if ($num_rows!=0){
                $reg = mysqli_fetch_object($tbl_local);
                $desc_local = $reg->tbl_pessoa_nome;
            }
            else {
                $desc_local = '';
            }

            $tbl_grupo = mysqli_query($conector, "select * from tbl_grupo_estacao_monta
                    where tbl_grupo_id='$codigo_grupo' and 
                          tbl_grupo_codigo_local='$codigo_local' and 
                          tbl_grupo_codigo_estacao_monta='$codigo_estacao'");
            $num_rows = mysqli_num_rows($tbl_grupo);

            if ($num_rows!=0){
                $reg = mysqli_fetch_object($tbl_grupo);
                $desc_grupo = $reg->tbl_grupo_descricao;
            }
            else {
                $desc_grupo = '';
            }

            $tbl_protocolo = mysqli_query($conector, "select * from tbl_protocoloiatf
                    where tbl_protocoloiatf_id ='$protocolo'");
            $num_rows = mysqli_num_rows($tbl_protocolo);

            if ($num_rows!=0){
                $reg = mysqli_fetch_object($tbl_protocolo);
                $desc_protocolo = $reg->tbl_protocoloiatf_descricao;
            }
            else {
                $desc_protocolo = '';
            }

            $data_matrizes = new DateTime($reg_matrizes->tbl_cobertura_data);
            $data_cobertura_edi = $data_matrizes->format('d/m/Y');

            echo "<tr>";

            if ($codigo_grupo==0){
                echo "<td width='5%' class='status_nao'>".$codigo_grupo."</td>";
                echo "<td width='10%' class='status_nao'>".$desc_grupo."</td>";
                echo "<td width='10%' class='status_nao'>".$data_cobertura_edi."</td>";
                echo "<td width='15%' class='status_nao'>".$desc_local."</td>";
                echo "<td width='8%' class='status_nao'>".$qtd_animais."</td>";
                echo "<td width='20%' class='status_nao'>".$desc_protocolo."</td>";
                echo "<td width='17%' class='status_nao'>Definir Grupos para Reprodução</td>";
                echo "<td width='15%'>";    
                echo "<div class='btn-group'>";

                //echo "<a class='btn' href='form_selecao_matrizes_consultar.php?id=".$codigo."'><i class='icon_search_alt' data-toggle='tooltip' data-placement='left' title='Consultar esse registro'></i></a>"; 

                echo "<a class='btn' href='#'>
                    <i class='icon_pencil' data-toggle='tooltip' data-placement='left'  title='Registrar grupos' onClick='registrar_grupos_cobertura(\"{$codigo}\")'>
                    </i></a>";

                if ($planilha_processada=='') {
                    echo "<a class='btn' href='#'>
                        <i class='fa fa-file-excel-o' data-toggle='tooltip' data-placement='left' title='Importar excel da lista de Fêmeas' onClick='importar_excel_lista_femeas(\"{$codigo}\",\"{$desc_local}\",\"{$qtd_animais}\",\"{$codigo_local}\")'>
                                    </i></a>";
                }

                echo "<a class='btn' href='#'>
                    <i class='icon_trash_alt' data-toggle='tooltip' data-placement='left'  title='Estornar esse registro' onClick='excluir_lista_cobertura(\"{$codigo}\",\"{$desc_local}\",\"{$qtd_animais}\")'>
                        </i></a>";
                echo "</div>";
                echo "</td>";
            }
            else { 
                echo "<td width='5%'>".$codigo_grupo."</td>";
                echo "<td width='10%'>".$desc_grupo."</td>";
                echo "<td width='10%'>".$data_cobertura_edi."</td>";
                echo "<td width='15%'>".$desc_local."</td>";
                echo "<td width='8%'>".$qtd_animais."</td>";
                echo "<td width='20%'>".$desc_protocolo."</td>";
                echo "<td width='17%'></td>";
                echo "<td width='15%'>";    
                echo "<div class='btn-group'>";
                echo "<a class='btn' href='form_selecao_matrizes_consultar.php?id=".$codigo."'><i class='icon_search_alt' data-toggle='tooltip' data-placement='left' title='Consultar esse registro'></i></a>"; 

                if ($iniciou_protocolo=='') {
                    echo "<a class='btn' href='#'>
                        <i class='icon_trash_alt' data-toggle='tooltip' data-placement='left'  title='Estornar esse registro' onClick='excluir_lista_cobertura(\"{$codigo}\",\"{$desc_local}\",\"{$qtd_animais}\")'>
                        </i></a>";
                }
                echo "</div>";
                echo "</td>";
            }
            echo "</tr>";
        }
    }

    mysqli_close($conector);
            
    echo '</tbody>';
    echo '<thead>
        <tr>
        <th> Grupo</th>
        <th> Descrição</th>
        <th> Data</th>
        <th> Local</th>
        <th> Qtd Animais</th>
        <th> Protocolo</th>
        <th></th>
        <th><i class="icon_cogs"></i> Ações</th>
        </tr>
        </thead>';
    echo '</table>';
    echo '</section>';
?>

<script src="js/matrizes.js" charset="utf-8" type="text/javascript" ></script>
<script>
    $(document).ready(function() {
    /*    var table = $('#tabela_matrizes').DataTable( {
                sDom: 'lfr<"table_overflow"t>ip',
                paging:   false,
                search:   true,
                info: false,
                ordering: false,
                language: {
                  sSearch: "Buscar na lista:",
                  zeroRecords: "Nada encontrado",
                  info: "Animais listados: _END_ ",
                  infoEmpty: "Nenhum registro disponível",
                  infoFiltered: "(filtrado de _MAX_ registros no total)",
                }
        });*/
    });

    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>

</body>
</html> 
          
                
