<?php 
	include "conecta_mysql.inc";

	@ session_start(); 
	$controle_estoque= $_SESSION['controle_estoque'];
	$nomeusuario = $_SESSION['nome_usuario'];

	$local_origem= $_POST['local_morte'];
	$data_movimentacao= $_POST['data_morte_animal'];
	$movimentacao_finalizada='N';
    $codigo_tipo = 888;
	$tipo_gravacao=1;	
	$data_sistema = date("Y-m-d H:i:s");

	$array_itens = $_POST['array_itens'];
	$matriz_itens = explode("<|>", $array_itens);
	$quantidade_itens = count($matriz_itens);

	$total_digitados = 1;
	$peso_total_kg = 0.00;
	$peso_total_arroba = 0.00;
	$peso_medio_kg = 0.00;
	$peso_medio_arroba = 0.00;
	$data_nascimento = '0000-00-00';

	if ($controle_estoque=='I') {

		for($i=0; $i < $quantidade_itens; $i++) {
    		$tabela_itens = $matriz_itens[$i];
    		$itens = explode("|", $tabela_itens);

			$sexo = $itens[2];
			$nascimento = $itens[3];
			$codigo_id = $itens[8];
			$codigo_pasto = $itens[11];
			$codigo_categoria = $itens[12];
			$desc_categoria='';

			$rs = mysqli_query($conector, "SELECT * FROM tbl_animais
	              WHERE tbl_animal_codigo_id='$codigo_id'");

	    	$num_rows = mysqli_num_rows($rs);
	    	if ($num_rows!=0) {
	        	$reg_animal = mysqli_fetch_object($rs);
	            $nascimento = $reg_animal->tbl_animal_data_nascimento;
                $primeiro_peso = $reg_animal->tbl_animal_primeiro_peso; 
                $peso_desmama = $reg_animal->tbl_animal_peso_desmama; 
                $ultimo_peso = $reg_animal->tbl_animal_ultimo_peso; 

                if ($ultimo_peso!=0 && $ultimo_peso!='') {
                    $peso = $ultimo_peso;
                }
                else if ($peso_desmama!=0 && $peso_desmama!='') {
                    $peso = $peso_desmama;
                }
                else if ($primeiro_peso!=0 && $primeiro_peso!=''){
                    $peso = $primeiro_peso;
                }
                else {
                    $peso = 0;
                }
	        }

			switch ($codigo_categoria) {
			    case '001':
			        $desc_categoria= '00 a 07 meses';
			        break;
			    case '002':
			        $desc_categoria= '08 a 12 meses';
			        break;
			    case '003':
			        $desc_categoria= '13 a 24 meses';
			        break;
			    case '004':
			        $desc_categoria= '25 a 36 meses';
			        break;
			    case '005':
			        $desc_categoria= '> 36 meses';
			        break;
			}

			$tbl_pasto = mysqli_query($conector, "SELECT * FROM tbl_animal_pasto 
				WHERE tbl_animal_pasto_local = '$local_origem' AND 
				      tbl_animal_pasto_id ='$codigo_pasto' AND 
				      tbl_animal_pasto_sexo = '$sexo' AND 
				      tbl_animal_pasto_categoria = '$codigo_categoria'");

	        $num_rows_pasto = mysqli_num_rows($tbl_pasto);    

	        if ($num_rows_pasto!=0) {
				$reg_pasto = mysqli_fetch_object($tbl_pasto);
				$numero_item = $reg_pasto->tbl_animal_pasto_numero_item;

				$sql = ("DELETE FROM tbl_animal_pasto 
						WHERE tbl_animal_pasto_local ='$local_origem' AND 
							tbl_animal_pasto_numero_item='$numero_item'");

				$resultado = mysqli_query($conector,$sql);
				$erro_mysql = mysqli_error($conector);

				if (!$resultado){
				 	header('Content-type: application/json');
				   	echo json_encode(array('error' => true, 'message' => 'Erro na alteração do registro no pasto.' . $erro_mysql));
					mysqli_close($conector);
					exit;
				}

				// Subtrai categoria no fechamento mensal se a data for do mes anterior

				$data_hoje = date("Y-m-d");
				$partes_hoje = explode("-", $data_hoje);
				$anomes_inicial = $partes_hoje[0].$partes_hoje[1];

				$partes_movimentacao = explode("-", $data_movimentacao);
				$anomes_final = $partes_movimentacao[0].$partes_movimentacao[1];
				$diferenca = $anomes_inicial - $anomes_final;

				if ($diferenca!=0) {
					$date = new DateTime($data_movimentacao);
					$date->modify('last day of this month');
					$data_fechamento = $date->format('Y-m-d');

					$tbl_fechamento = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque
		        		WHERE tbl_fechamento_local='$local_origem' AND
		              		  tbl_fechamento_data='$data_fechamento' AND 
		              		  tbl_fechamento_categoria='$codigo_categoria' AND
		              		  tbl_fechamento_sexo='$sexo'");

		    		$num_rows = mysqli_num_rows($tbl_fechamento);    

		    		if ($num_rows!=0) {
		    			$reg = mysqli_fetch_object($tbl_fechamento);
		    			$fechamento_id = $reg->tbl_fechamento_id;
		    			$qtd_fechamento = $reg->tbl_fechamento_qtd;
    					$peso_fechamento = $reg->tbl_fechamento_peso;

		    			$qtd_fechamento--;
    					$peso_fechamento-=$peso;

						$sql = ("UPDATE tbl_fechamento_mensal_estoque SET 
						   		tbl_fechamento_qtd='$qtd_fechamento',
				   				tbl_fechamento_peso='$peso_fechamento'
						 	WHERE tbl_fechamento_id ='$fechamento_id'");

						$resultado = mysqli_query($conector,$sql);
						$erro_mysql = mysqli_error($conector);

						if (!$resultado) {
						 	header('Content-type: application/json');
						   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro na alteração do fechamento mensal!' . $erro_mysql));
							mysqli_close($conector);
							exit;
						}
		    		}
				}

				$tbl_fechamento_ent_sai = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque_ent_sai_peso
	        		WHERE tbl_fechamento_local='$local_origem' AND
	              		  tbl_fechamento_data='$data_fechamento'");

	    		$num_rows = mysqli_num_rows($tbl_fechamento_ent_sai);    

	    		if ($num_rows!=0) {
	    			$reg = mysqli_fetch_object($tbl_fechamento_ent_sai);
	    			$fechamento_id = $reg->tbl_fechamento_id;
	    			$peso_morte = $reg->tbl_fechamento_peso_sai_morte;
	    			$peso_final = $reg->tbl_fechamento_peso_final;

	    			$peso_morte+=$peso;
			    	$peso_final-=$peso;

					$sql = ("UPDATE tbl_fechamento_mensal_estoque_ent_sai_peso SET 
					   		tbl_fechamento_peso_sai_morte='$peso_morte',
					   		tbl_fechamento_peso_final='$peso_final'
					 	WHERE tbl_fechamento_id ='$fechamento_id'");

					$resultado = mysqli_query($conector,$sql);
					$erro_mysql = mysqli_error($conector);

					if (!$resultado) {
				   		header('Content-type: application/json');
				   		echo json_encode(array('error' => $erro_mysql, 'message' => 'Ocorreu um erro na alteração do fechamento mensal Ent/Sai' . $erro_mysql));
						mysqli_close($conector);
						exit;
					}
	    		}

				// Fim adiciona fechamento mensal

	        }
	        else {
			 	header('Content-type: application/json');
			   	echo json_encode(array('error' => true, 'message' => 'Não existem animais com o sexo '.$sexo.' e categoria '.$desc_categoria.' no pasto.'));
				mysqli_close($conector);
				exit;
	        }
		}
	}
	else {
		for($i=0; $i < $quantidade_itens; $i++) {
    		$tabela_itens = $matriz_itens[$i];
    		$itens = explode("|", $tabela_itens);

			$sexo = $itens[2];
			$codigo_pasto = $itens[11];
			$codigo_categoria = $itens[12];
			$desc_categoria='';

			switch ($codigo_categoria) {
			    case '001':
			        $desc_categoria= '00 a 07 meses';
			        break;
			    case '002':
			        $desc_categoria= '08 a 12 meses';
			        break;
			    case '003':
			        $desc_categoria= '13 a 24 meses';
			        break;
			    case '004':
			        $desc_categoria= '25 a 36 meses';
			        break;
			    case '005':
			        $desc_categoria= '> 36 meses';
			        break;
			}

			$tbl_pasto = mysqli_query($conector, "SELECT * FROM tbl_animal_pasto 
				WHERE tbl_animal_pasto_local = '$local_origem' AND 
				      tbl_animal_pasto_id ='$codigo_pasto' AND 
				      tbl_animal_pasto_sexo = '$sexo' AND 
				      tbl_animal_pasto_categoria = '$codigo_categoria'");

	        $num_rows_pasto = mysqli_num_rows($tbl_pasto);    

	        if ($num_rows_pasto!=0) {
				$reg_pasto = mysqli_fetch_object($tbl_pasto);
			    $numero_item = $reg_pasto->tbl_animal_pasto_numero_item;
	            $data_nascimento = $reg_pasto->tbl_animal_pasto_nascimento;

				$sql = ("DELETE FROM tbl_animal_pasto 
				         WHERE tbl_animal_pasto_local ='$local_origem' AND 
				               tbl_animal_pasto_numero_item='$numero_item'");
				$resultado = mysqli_query($conector,$sql);
				$erro_mysql = mysqli_error($conector);

				if (!$resultado){
				 	header('Content-type: application/json');
				   	echo json_encode(array('error' => true, 'message' => 'Erro na alteração do registro no pasto.' . $erro_mysql));
					mysqli_close($conector);
					exit;
				}

				// Subtrai categoria no fechamento mensal se a data for do mes anterior

				$data_hoje = date("Y-m-d");
				$partes_hoje = explode("-", $data_hoje);
				$anomes_inicial = $partes_hoje[0].$partes_hoje[1];

				$partes_movimentacao = explode("-", $data_movimentacao);
				$anomes_final = $partes_movimentacao[0].$partes_movimentacao[1];
				$diferenca = $anomes_inicial - $anomes_final;

				if ($diferenca!=0) {
					$date = new DateTime($data_movimentacao);
					$date->modify('last day of this month');
					$data_fechamento = $date->format('Y-m-d');

					$tbl_fechamento = mysqli_query($conector, "SELECT * FROM tbl_fechamento_mensal_estoque
		        		WHERE tbl_fechamento_local='$local_origem' AND
		              		  tbl_fechamento_data='$data_fechamento' AND 
		              		  tbl_fechamento_categoria='$codigo_categoria' AND
		              		  tbl_fechamento_sexo='$sexo'");

		    		$num_rows = mysqli_num_rows($tbl_fechamento);    

		    		if ($num_rows!=0) {
		    			$reg = mysqli_fetch_object($tbl_fechamento);
		    			$fechamento_id = $reg->tbl_fechamento_id;
		    			$qtd_fechamento = $reg->tbl_fechamento_qtd;

		    			$qtd_fechamento--;

						$sql = ("UPDATE tbl_fechamento_mensal_estoque SET 
						   		tbl_fechamento_qtd='$qtd_fechamento'
						 	WHERE tbl_fechamento_id ='$fechamento_id'");

						$resultado = mysqli_query($conector,$sql);
						$erro_mysql = mysqli_error($conector);

						if (!$resultado) {
						 	header('Content-type: application/json');
						   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro na alteração do fechamento mensal!' . $erro_mysql));
							mysqli_close($conector);
							exit;
						}
		    		}
				}
				// Fim adiciona fechamento mensal
			}
			else {
			 	header('Content-type: application/json');
			   	echo json_encode(array('error' => true, 'message' => 'Não existe animais com o sexo '.$sexo.' e categoria '.$desc_categoria.' no pasto.'));
				mysqli_close($conector);
				exit; 
			}

	        /*$codigo_categoria_pasto = 0;

	        if ($num_rows_pasto!=0) {
	           	while ($reg_pasto = mysqli_fetch_object($tbl_pasto)) {
                    $data_nascimento = $reg_pasto->tbl_animal_pasto_nascimento;  
                    $data_acompanhamento_calculo = date("Y-m-d");
                    $date = new DateTime($data_nascimento); // Data de Nascimento
                    $idade_acompanhamento = $date->diff(new DateTime($data_acompanhamento_calculo));
                    $idade_acompanhamento_mostra_anos = $idade_acompanhamento->format('%Y')*12;
                    $idade_acompanhamento_mostra_meses = $idade_acompanhamento->format('%m');
                    $idade = $idade_acompanhamento_mostra_anos+$idade_acompanhamento_mostra_meses;

		            $tbl_categoria = mysqli_query($conector, "SELECT * FROM tabela_categoria_idade
		                        WHERE tab_registro_lixeira_categoria_idade='0'");
		            $num_rows_categoria = mysqli_num_rows($tbl_categoria);    

	                while ($reg_categoria = mysqli_fetch_object($tbl_categoria)) {
	                    $idade_de = $reg_categoria->tab_categoria_idade_de;
	                    $idade_ate = $reg_categoria->tab_categoria_idade_ate;

	                    if ($idade >= $idade_de && $idade <= $idade_ate) {
	                        $codigo_categoria_pasto = $reg_categoria->tab_codigo_categoria_idade;
	                    }

	                    if ($codigo_categoria_pasto==$codigo_categoria) {
			            	$numero_item = $reg_pasto->tbl_animal_pasto_numero_item;
	                        $data_nascimento = $data_nascimento_pasto;
			            	$codigo_categoria = 0;
							$sql = ("DELETE FROM tbl_animal_pasto 
								           WHERE tbl_animal_pasto_local ='$local_origem' AND 
								                 tbl_animal_pasto_numero_item='$numero_item'");
							$resultado = mysqli_query($conector,$sql);
							$erro_mysql = mysqli_error($conector);

							if (!$resultado){
							 	header('Content-type: application/json');
							   	echo json_encode(array('error' => true, 'message' => 'Erro na alteração do registro no pasto.' . $erro_mysql));
								mysqli_close($conector);
								exit;
							}
			            	break;
	                    }
	                }
			    }

                if ($codigo_categoria_pasto!=$codigo_categoria && $codigo_categoria!=0) {
				 	header('Content-type: application/json');
				   	echo json_encode(array('error' => true, 'message' => 'Não a categoria do animal no pasto.'));
					mysqli_close($conector);
					exit;
                }
	        }
	        else {
			 	header('Content-type: application/json');
			   	echo json_encode(array('error' => true, 'message' => 'Não existe animais com o sexo ' .$sexo . ' no pasto '));
				mysqli_close($conector);
				exit;
	        }*/
		}
	}

    if ($tipo_gravacao==1){
	    $sql = "INSERT INTO tbl_movimentacao (
	    	tbl_movimentacao_controle,
	    	tbl_movimentacao_data,
			tbl_movimentacao_codigo_local_origem,
			tbl_movimentacao_codigo_local_destino,
			tbl_movimentacao_tipo,
			tbl_movimentacao_qtd_animais_pesados,
			tbl_movimentacao_peso_kg,
			tbl_movimentacao_peso_arroba,
			tbl_movimentacao_peso_medio_kg,
			tbl_movimentacao_peso_medio_arroba,
			tbl_movimentacao_filtros,
			tbl_movimentacao_situacao,
			tbl_movimentacao_incluido_em,
			tbl_movimentacao_incluido_por,
			tbl_movimentacao_alterado_em,
			tbl_movimentacao_alterado_por,
			tbl_movimentacao_lixeira,
			tbl_movimentacao_lixeira_em,
			tbl_movimentacao_lixeira_por,
			tbl_movimentacao_aceite_transferencia_em,
			tbl_movimentacao_aceite_transferencia_por,
			tbl_movimentacao_aceite_financeiro_em,
			tbl_movimentacao_aceite_financeiro_por,
			tbl_movimentacao_codigo_pesagem
	        ) VALUES (
	        '$controle_estoque',
	        '$data_movimentacao',
			'$local_origem',
			null,
			'$codigo_tipo',
			'$total_digitados',
			'$peso_total_kg',
			'$peso_total_arroba',
			'$peso_medio_kg',
			'$peso_medio_arroba',
			null,
			'$movimentacao_finalizada',
			'$data_sistema',
			'$nomeusuario',
			null,
			null,
			0,
			null,
			null,
			null,
			null,
			null,
			null,
			null
		)";

	    $resultado = mysqli_query($conector,$sql);
		$erro_mysql = mysqli_error($conector);

		if (!$resultado){
	    	header('Content-type: application/json');
	    	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro ao registrar a movimentação'. $erro_mysql));
	    	mysqli_close($conector);
			exit;
		} 

		$numero_movimentacao = mysqli_insert_id($conector);
		$numero_movimentacao = str_pad($numero_movimentacao, 9, "0", STR_PAD_LEFT);

		for($i=0; $i < $quantidade_itens; $i++) {
    		$tabela_itens = $matriz_itens[$i];

    		$itens = explode("|", $tabela_itens);
			$codigo_animal = ltrim($itens[0]);
			$codigo_animal = rtrim($codigo_animal);
			$peso = $itens[1];
			$sexo = $itens[2];
			$nascimento = $itens[3];
			$raca = $itens[4];
			$pelagem = $itens[5];
			$mae = $itens[6];
			$observacao = ltrim($itens[7]);
			$observacao = rtrim($observacao);
			$codigo_id = $itens[8];
			$codigo_motivo_morte = $itens[10];
			$codigo_pasto = $itens[11];
			$codigo_categoria = $itens[12];

			/*if ($controle_estoque=='I') {
				$codigo_categoria=$codigo_categoria_pasto;
			}*/

			$numero_item = $i + 1;
			
		    $sql = "INSERT INTO tbl_item_movimentacao (
		            tbl_ite_movimentacao_numero_id,
		            tbl_ite_movimentacao_numero_item,
		            tbl_ite_movimentacao_data_emissao,
		            tbl_ite_movimentacao_codigo_id_animal,
		            tbl_ite_movimentacao_codigo_animal,
					tbl_ite_movimentacao_peso,
					tbl_ite_movimentacao_sexo,
					tbl_ite_movimentacao_nascimento,
					tbl_ite_movimentacao_raca,
					tbl_ite_movimentacao_pelagem,
					tbl_ite_movimentacao_mae,
					tbl_ite_movimentacao_observacao,
					tbl_ite_movimentacao_motivo_morte,
					tbl_ite_movimentacao_codigo_pasto,
					tbl_ite_movimentacao_codigo_categoria
		        ) VALUES (
		            '$numero_movimentacao',
		            '$numero_item',
		            '$data_movimentacao',
		            '$codigo_id',
		            '$codigo_animal',
		            '$peso',
		            '$sexo',
		            '$nascimento',
		            '$raca',
		            '$pelagem',
		            '$mae',
		            '$observacao',
		            '$codigo_motivo_morte',
		            '$codigo_pasto',
		            '$codigo_categoria'
		    )";
		    $resultado = mysqli_query($conector,$sql);
			$erro_mysql = mysqli_error($conector);
		}    

		if (!$resultado){
		  	header('Content-type: application/json');
		   	echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro na gravação dos itens.' . $erro_mysql));
			mysqli_close($conector);
			exit;
		} 
		
		for($i=0; $i < $quantidade_itens; $i++) {
    		$tabela_itens = $matriz_itens[$i];
    		$itens = explode("|", $tabela_itens);
			$sexo=$itens[2];
			$observacao = ltrim($itens[7]);
			$observacao = rtrim($observacao);
			$codigo_id = $itens[8];
			$motivo_morte = $itens[9];
			$codigo_pasto = $itens[11];
			$codigo_categoria = $itens[12];

			/*if ($controle_estoque=='I') {
				$codigo_categoria=$codigo_categoria_pasto;
			}*/

			$atualizar_animal = gravar_movimento_animal($conector, $codigo_id, $observacao, $codigo_tipo, $motivo_morte, $local_origem, $data_movimentacao, $numero_movimentacao, $codigo_pasto, $codigo_categoria, $sexo, $controle_estoque, $data_nascimento);

			if ($atualizar_animal=='Gravei') {
			    $resposta = array('success' => true, 'message' => 'Movimentação de morte processada com sucesso.');
			   	header('Content-type: application/json');
			   	echo json_encode($resposta);
				mysqli_close($conector);
				exit;
			}
			else {
			    $resposta = array('error' => true, 'message' => $atualizar_animal);
			   	header('Content-type: application/json');
			   	echo json_encode($resposta);
				mysqli_close($conector);
				exit;
			}
		}

    	//header('Content-type: application/json');
    	//echo json_encode(array('success' => true, 'message' => 'Reistro gravado com sucesso'));
    	//mysqli_close($conector);
		//exit;
	}

    function gravar_movimento_animal($conector, $codigo_id, $observacao, $codigo_tipo, $motivo_morte, $local_origem, $data_movimentacao, $numero_movimentacao, $codigo_pasto, $codigo_categoria, $sexo, $controle_estoque, $data_nascimento) {

		@ session_start(); 
		$nomeusuario = $_SESSION['nome_usuario'];
		$data_sistema = date("Y-m-d H:i:s");

		if ($controle_estoque=='I') {
			$rs = mysqli_query($conector, "SELECT * FROM tbl_animais
	              WHERE tbl_animal_codigo_id='$codigo_id'");

	    	$num_rows = mysqli_num_rows($rs);
	    	if ($num_rows!=0) {
	        	$reg_animal = mysqli_fetch_object($rs);
	        	$codigo_origem_anterior = $reg_animal->tbl_animal_codigo_origem;
	        	$codigo_fazenda_anterior = $reg_animal->tbl_animal_codigo_fazenda;
	            $data_nascimento = $reg_animal->tbl_animal_data_nascimento;
            	$codigo_animal = $reg_animal->tbl_animal_codigo_alfa .' '.
                             	 $reg_animal->tbl_animal_codigo_numerico;

		        $observacao = 'Motivo da morte: ' . $motivo_morte . '. Obs: ' . $observacao;
				$sql = "UPDATE tbl_animais SET
						tbl_animal_ativo='N',
						tbl_animal_baixado_em='$data_movimentacao',
						tbl_animal_baixado_por='$nomeusuario',
						tbl_animal_observacao='$observacao',
						tbl_animal_codigo_origem_anterior='$codigo_origem_anterior',
						tbl_animal_codigo_fazenda_anterior='$codigo_fazenda_anterior',
						tbl_animal_situacao='M'
				    WHERE tbl_animal_codigo_id='$codigo_id'";

			    $resultado = mysqli_query($conector,$sql);
				$erro_mysql = mysqli_error($conector);

				if (!$resultado){
					return 'Ocorreu um erro na atualização do animal.' . $erro_mysql;
				  	//header('Content-type: application/json');
				   	//echo json_encode(array('error' => true, 'message' => 'Ocorreu um erro na atualização do animal.' . $erro_mysql));
					//mysqli_close($conector);
					//exit;
				} 
	    	}
		}

		if ($controle_estoque=='I') {
	        $sql = "INSERT INTO tbl_movimentacao_estoque
	                (tbl_mov_estoque_codigo_id_animal,
	                 tbl_mov_estoque_data_emissao,
	                 tbl_mov_estoque_nascimento,
	                 tbl_mov_estoque_local,
	                 tbl_mov_estoque_entrada_saida,
	                 tbl_mov_estoque_tipo_movimentacao,
	                 tbl_mov_estoque_local_origem,
	                 tbl_mov_estoque_local_destino,
	                 tbl_mov_estoque_codigo_movimentacao,
	                 tbl_mov_estoque_codigo_pasto,
	                 tbl_mov_estoque_codigo_categoria,
	                 tbl_mov_estoque_codigo_raca,
	                 tbl_mov_estoque_codigo_pelagem,
	                 tbl_mov_estoque_sexo,
	                 tbl_mov_estoque_primeiro_peso
	                ) 
	                VALUES ('$codigo_id',
	                        '$data_movimentacao',
	                        '$data_nascimento',
	                        '$local_origem',
	                        'S',
	                        'M',
	                        '$local_origem',
	                        null,
	                        '$numero_movimentacao',
	                        '$codigo_pasto',
	                        '$codigo_categoria',
	                        null,
	                        null,
	                        '$sexo',
	                        null
	                )";
	        
	        $resultado = mysqli_query($conector,$sql);
	        $erro_mysql = mysqli_error($conector);

	        if (!$resultado){
				return 'Erro na gravacao histórico saída morte.' . $erro_mysql;
				//header('Content-type: application/json');
				//echo json_encode(array('error' => true, 'message' => 'Erro na gravacao histórico saída morte.' . $erro_mysql));
				//mysqli_close($conector);
				//exit;
	        }
		}
		else {
        	$sql = "INSERT INTO tbl_movimentacao_estoque
	                (tbl_mov_estoque_codigo_id_animal,
	                 tbl_mov_estoque_data_emissao,
	                 tbl_mov_estoque_nascimento,
	                 tbl_mov_estoque_local,
	                 tbl_mov_estoque_entrada_saida,
	                 tbl_mov_estoque_tipo_movimentacao,
	                 tbl_mov_estoque_local_origem,
	                 tbl_mov_estoque_local_destino,
	                 tbl_mov_estoque_codigo_movimentacao,
	                 tbl_mov_estoque_codigo_pasto,
	                 tbl_mov_estoque_codigo_categoria,
	                 tbl_mov_estoque_codigo_raca,
	                 tbl_mov_estoque_codigo_pelagem,
	                 tbl_mov_estoque_sexo,
	                 tbl_mov_estoque_primeiro_peso
	                ) 
	                VALUES ('$codigo_id',
	                        '$data_movimentacao',
	                        '$data_nascimento',
	                        '$local_origem',
	                        'S',
	                        'M',
	                        '$local_origem',
	                        null,
	                        '$numero_movimentacao',
	                        '$codigo_pasto',
	                        '$codigo_categoria',
	                        null,
	                        null,
	                        '$sexo',
	                        null
	                )";
	        
	        $resultado = mysqli_query($conector,$sql);
	        $erro_mysql = mysqli_error($conector);

	        if (!$resultado){
				return 'Erro na gravacao histórico saída morte.' . $erro_mysql;
			  	//header('Content-type: application/json');
			   	//echo json_encode(array('error' => true, 'message' => 'Erro na gravacao histórico saída morte.' . $erro_mysql));
				//mysqli_close($conector);
				//exit;
	        }
		}

	    // Inclui o flag de morte na tabela tbl_item_cobertura
        $item_cobertura = mysqli_query($conector, "SELECT * FROM tbl_item_cobertura
	        INNER JOIN tbl_cobertura 
	        	    ON tbl_cobertura_id = tbl_ite_cobertura_numero_id
	        WHERE tbl_cobertura_controle='C' AND 
	              tbl_cobertura_encerrada='S' AND
	              tbl_ite_cobertura_codigo_id_animal='$codigo_id' AND 
	              tbl_ite_cobertura_resultado_diagnostico='P'");

 //AND (tbl_ite_cobertura_nascido='' OR tbl_ite_cobertura_nascido IS NULL)
		$num_rows = mysqli_num_rows($item_cobertura);

		if ($num_rows!=0) {
			$situacao='M';
		
		   	$reg_item = mysqli_fetch_object($item_cobertura);
		   	$cobertura_id = $reg_item->tbl_ite_cobertura_numero_id;
		   	$numero_item = $reg_item->tbl_ite_cobertura_numero_item;
				    
			$sql = "UPDATE tbl_item_cobertura SET
				tbl_ite_cobertura_nascido='O',
				tbl_ite_cobertura_situacao_femea_nascido_outro='$situacao'
		 		WHERE tbl_ite_cobertura_numero_id ='$cobertura_id' AND 
		 			  tbl_ite_cobertura_numero_item='$numero_item'";
		       	
			$resultado = mysqli_query($conector,$sql);
			$erro_mysql = mysqli_error($conector);

			if (!$resultado){
				return 'Ocorreu um erro na atualização do item de cobertura animal ' . $codigo_animal . ' erro ' . $erro_mysql;
			} 
		}
	    // Fim inclui flag de vendido, morte ou outra saida

		return 'Gravei';	

		/*
		$excluiu_no_pasto = '';

		if ($controle_estoque=='I') {
            $data_inicial = $data_nascimento;
            $data_final = date("Y-m-d");
            $diferenca = strtotime($data_final) - 
                         strtotime($data_inicial);
            $idade = floor($diferenca / (60 * 60 * 24 * 30));
            $idade = str_pad($idade, 2, "0", STR_PAD_LEFT);

            $tbl_categoria = mysqli_query($conector, "SELECT * FROM tabela_categoria_idade
                        WHERE tab_registro_lixeira_categoria_idade='0'");

            $num_rows = mysqli_num_rows($tbl_categoria);    

            if ($num_rows!=0) {
                while ($reg_categoria = mysqli_fetch_object($tbl_categoria)) {
                    $idade_de = $reg_categoria->tab_categoria_idade_de;
                    $idade_ate = $reg_categoria->tab_categoria_idade_ate;

                    if ($idade >= $idade_de && $idade <= $idade_ate) {
                        $codigo_categoria = $reg_categoria->tab_codigo_categoria_idade;
                    }
                }
            }                   

		    $tbl_pasto = "SELECT * FROM tbl_pasto WHERE tbl_pasto_id ='$codigo_pasto'";
		    $rs = mysqli_query($conector, $tbl_pasto);
		    $reg_pasto = mysqli_fetch_object($rs);

		    $array_categoria = explode("!", $reg_pasto->tbl_pasto_array_categoria);
		    $array_qtd_macho = explode("!", $reg_pasto->tbl_pasto_array_qtd_animais_macho);
		    $array_qtd_femea = explode("!", $reg_pasto->tbl_pasto_array_qtd_animais_femea);
		    $array_qtd_ambos = explode("!", $reg_pasto->tbl_pasto_array_qtd_animais_ambos);

		    for ($i=0; $i<5; $i++) { 
		    	if ($array_categoria[$i]>=$codigo_categoria) {

				    if ($array_qtd_macho[$i]=='') {
				    	$qtd_macho = 0;
				    }
				    else {
					    $qtd_macho = intval($array_qtd_macho[$i]);
				    }

				    if ($array_qtd_femea[$i]=='') {
				    	$qtd_femea = 0;
				    }
				    else {
					    $qtd_femea = intval($array_qtd_femea[$i]);
				    }

				    if ($array_qtd_ambos[$i]=='') {
				    	$qtd_ambos = 0;
				    }
				    else {
					    $qtd_ambos = intval($array_qtd_ambos[$i]);
				    }

				    if ($qtd_macho==0 && $qtd_femea==0) {
				    	$excluiu_no_pasto = '';
				    	break;
				    }

				    if ($sexo=='F'){
				    	if ($qtd_femea>0) {
						   	$qtd_femea--;
							$array_qtd_femea[$i] = $qtd_femea;  	
				    	}
				    	else if ($qtd_ambos>0) {
						   	$qtd_ambos--;
							$array_qtd_ambos[$i] = $qtd_ambos;  	
				    	}
				    }
				    else {
				    	if ($qtd_macho>0) {
						   	$qtd_macho--;
							$array_qtd_macho[$i] = $qtd_macho;  	
				    	}
				    	else if ($qtd_ambos>0){
						   	$qtd_ambos--;
							$array_qtd_ambos[$i] = $qtd_ambos;  	
				    	}
				    }

				  	$array_qtd_femea_ajustado = implode("!", $array_qtd_femea);
				   	$array_qtd_macho_ajustado = implode("!", $array_qtd_macho);
				   	$array_qtd_ambos_ajustado = implode("!", $array_qtd_ambos);

					$sql = ("UPDATE tbl_pasto SET 
						         tbl_pasto_array_qtd_animais_macho='$array_qtd_macho_ajustado',
						         tbl_pasto_array_qtd_animais_femea='$array_qtd_femea_ajustado',
						         tbl_pasto_array_qtd_animais_ambos='$array_qtd_ambos_ajustado',
								 tbl_pasto_alterado_em='$data_sistema',
								 tbl_pasto_alterado_por='$nomeusuario'
					 	     WHERE tbl_pasto_id ='$codigo_pasto'");

				    $resultado = mysqli_query($conector,$sql);
				    $erro_mysql = mysqli_error($conector);

				    if (!$resultado){
				    	return 'Erro na alteração do registro no pasto.' . $erro_mysql;
					  	//header('Content-type: application/json');
					   	//echo json_encode(array('error' => true, 'message' => 'Erro na alteração do registro no pasto.' . $erro_mysql));
						//	mysqli_close($conector);
						//exit;
				    }

				    $excluiu_no_pasto = 'S';
				    break;
		    	}
		    }
		}
		else {
		    $tbl_pasto = "SELECT * FROM tbl_pasto WHERE tbl_pasto_id ='$codigo_pasto'";
		    $rs = mysqli_query($conector, $tbl_pasto);
		    $reg_pasto = mysqli_fetch_object($rs);

		    $array_categoria = explode("!", $reg_pasto->tbl_pasto_array_categoria);
		    $array_qtd_macho = explode("!", $reg_pasto->tbl_pasto_array_qtd_animais_macho);
		    $array_qtd_femea = explode("!", $reg_pasto->tbl_pasto_array_qtd_animais_femea);
		    $array_qtd_ambos = explode("!", $reg_pasto->tbl_pasto_array_qtd_animais_ambos);

		    for ($i=0; $i<5; $i++) { 
		    	if ($array_categoria[$i]==$codigo_categoria) {

				    if ($array_qtd_macho[$i]=='') {
				    	$qtd_macho = 0;
				    }
				    else {
					    $qtd_macho = intval($array_qtd_macho[$i]);
				    }

				    if ($array_qtd_femea[$i]=='') {
				    	$qtd_femea = 0;
				    }
				    else {
					    $qtd_femea = intval($array_qtd_femea[$i]);
				    }

				    if ($array_qtd_ambos[$i]=='') {
				    	$qtd_ambos = 0;
				    }
				    else {
					    $qtd_ambos = intval($array_qtd_ambos[$i]);
				    }

				    if ($sexo=='F'){
				    	if ($qtd_femea>0) {
						   	$qtd_femea--;
							$array_qtd_femea[$i] = $qtd_femea;  	
				    	}
				    	else {
						   	$qtd_ambos--;
							$array_qtd_ambos[$i] = $qtd_ambos;  	
				    	}
				    }
				    else {
				    	if ($qtd_macho>0) {
						   	$qtd_macho--;
							$array_qtd_macho[$i] = $qtd_macho;  	
				    	}
				    	else {
						   	$qtd_ambos--;
							$array_qtd_ambos[$i] = $qtd_ambos;  	
				    	}
				    }

				  	$array_qtd_femea_ajustado = implode("!", $array_qtd_femea);
				   	$array_qtd_macho_ajustado = implode("!", $array_qtd_macho);
				   	$array_qtd_ambos_ajustado = implode("!", $array_qtd_ambos);

					$sql = ("UPDATE tbl_pasto SET 
						         tbl_pasto_array_qtd_animais_macho='$array_qtd_macho_ajustado',
						         tbl_pasto_array_qtd_animais_femea='$array_qtd_femea_ajustado',
						         tbl_pasto_array_qtd_animais_ambos='$array_qtd_ambos_ajustado',
								 tbl_pasto_alterado_em='$data_sistema',
				    			 tbl_pasto_alterado_por='$nomeusuario'
					 	     WHERE tbl_pasto_id ='$codigo_pasto'");

				    $resultado = mysqli_query($conector,$sql);
				    $erro_mysql = mysqli_error($conector);

				    if (!$resultado){
				    	return 'Erro na alteração do registro no pasto.' . $erro_mysql;
					  	//header('Content-type: application/json');
					   	//echo json_encode(array('error' => true, 'message' => 'Erro na alteração do registro no pasto.' . $erro_mysql));
						//	mysqli_close($conector);
						//exit;
				    }

				    $excluiu_no_pasto = 'S';
				    break;
		    	}
		    }

		}

	    if ($excluiu_no_pasto=='') {
	    	//return 'Não foi possível encontrar o animal no pasto com os dados informados.' . $erro_mysql;
			header('Content-type: application/json');
			echo json_encode(array('error' => true, 'message' => 'Não foi possível encontrar o animal no pasto com os dados informados.' . $erro_mysql));
			mysqli_close($conector);
			exit;
	    }
	    else {
			return 'Gravei';	
	    } */
	}

?>