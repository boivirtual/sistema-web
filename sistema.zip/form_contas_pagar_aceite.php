<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";

    $data_sistema = date("Y-m-d");

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS -->
  <link href="css/jquery-ui.css" rel="stylesheet" />
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <link href="css/daterangepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-colorpicker.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="DataTables-1.10.18/css/dataTables.bootstrap4.min.css"rel="stylesheet" >
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>

<body>

  <?php

   @ session_start();   
    if(isset($_SESSION['menu_gestao_adm'])) {
        $array_gestao_adm = explode("!",$_SESSION['menu_gestao_adm']);

        if ($array_gestao_adm[2] == 0){
            echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
            echo '<strong class="negrito">Atenção! </strong><span>Você não tem acesso a esse programa!</span>';  
            echo '</div>';         
            exit;
        }
    }
    else {
        echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
        echo '<strong class="negrito">Atenção! </strong><span>Você não efetuou o login!</span>';  
        echo '</div>';         
        exit;
    }

?>

<!-- container section start -->
<section id="container" class="">

    <!--sidebar start-->
    <?php
        include "cabecalho.php";
        include "opcoes_menu.php";
    ?>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Gestão Administrativa <i class="fa fa-angle-right seta-direita"></i><a class="voltar-menu" href="form_contas_pagar.php"> Conta a Pagar</a> <i class="fa fa-angle-right seta-direita"></i>
            <span class="titulo">Aceite Contas a Pagar</span></span>

            <a href="#" style="color: gray; margin-left: 10px;" data-toggle='tooltip' data-placement='right' title="Orientações de uso" onclick="informacoes_uso()"><i class="far fa-question-circle"></i></a>

           <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fas fa-hand-holding"></i> Aceite Contas a Pagar</h3>
                </div>
            </div>

            <div class="row col-lg-12">
                <div class="form-group">
                    <button type="button" class="btn btn-primary" 
                        onClick="confirmar_aceite()">Confirmar Selecionados</button>

                   <button type="button" class="btn btn-info pull-right" 
                        onClick="aceite_sair()">Voltar</button>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                    <div class="table-responsive">
                        <table class="table table-borderless table-hover" width="100%" 
                        style="font-size: 12px">
                        <thead>
                            <tr>
                                <th><input type="checkbox" class='checkbox1' data-toggle='tooltip' data-placement='top' id="seleciona_todos_aceite" title="Selecionar Todos"></th> 
                                <th>Fonte Recebedora</th> 
                                <th>Conta</th>
                                <th>Emissão</th> 
                                <th>Parcela</th>
                                <th>Vencimentos</th> 
                                <th>Valor</th> 
                                <th>Descrição</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $chave_anterior = '';

                                $rs = mysqli_query($conector, "SELECT * FROM contas_pagar
                                    INNER JOIN tbl_plano_contas
                                            ON tbl_plano_contas_codigo_id=ctp_codigo_conta
                                         WHERE ctp_aceite=''
                                      ORDER BY ctp_numero_doc, ctp_parcela, ctp_codigo_fornecedor, ctp_data_emissao ASC");
                                    
                                while ($fila = mysqli_fetch_object($rs)){
                                    $data_emissao = new DateTime($fila->ctp_data_emissao);
                                    $data_vencimento = new DateTime($fila->ctp_data_vencimento);
                                    $banco = $fila->ctp_codigo_banco;
                                    $numero_cheque = $fila->ctp_numero_cheque;

                                    if (empty($fila->ctp_numero_doc)) {
                                        $numero_id = $fila->ctp_numero_documento;
                                    }
                                    else {
                                        $numero_id = $fila->ctp_numero_doc;
                                    }

                                    $parcela = $fila->ctp_parcela;
                                    $codigo_for = $fila->ctp_codigo_fornecedor;
                                    $nome_for = $fila->ctp_nome_fornecedor;
                                    $desc_conta = $fila->tbl_plano_contas_descricao;
                                    $descricao_compra = $fila->ctp_descricao_compra;
                                    $situacao = $fila->ctp_situacao;
                                    $vlr_parcela = $fila->ctp_valor_parcela;
                                    $vlr_juros = $fila->ctp_valor_juros;
                                    $vlr_desconto = $fila->ctp_valor_desconto;
                                    $vlr_outro = $fila->ctp_outro_valor;
                                    $total_parcela = $vlr_parcela - $vlr_desconto + $vlr_juros + $vlr_outro;

                                    if ($situacao=="P"){
                                        $desc_situacao = "Paga";
                                    }
                                    else if ($situacao=="C") {
                                        $desc_situacao = "Paga Parc";
                                    }
                                    else {
                                        $desc_situacao = "";
                                    }

                                    //$chave_ctp = $numero_id . $parcela . $codigo_for;
                                    $chave_ctp = $codigo_for . $numero_id;
                                    $doc_parcela = $numero_id . '-' . $parcela;

                                    if ($chave_anterior!=$chave_ctp) {
                                        echo "<tr>";
                                        echo "<td width='2%'>
                                              <input type='checkbox' class='checkbox1' name='id_ctp' data-toggle='tooltip' data-placement='top' title='Seleciome para Confirmar o aceite' value='".$chave_ctp."'>
                                              </td>";
                                        echo "<td width='30%'>".$nome_for."</td>";
                                        echo "<td width='20%'>".$desc_conta."</td>";
                                        echo "<td width='6%'>".$data_emissao->format('d/m/Y')."</td>";
                                        echo "<td width='3%' align='center'>".$parcela."</td>";
                                        echo "<td width='6%'>".$data_vencimento->format('d/m/Y')."</td>";
                                        echo "<td width='12%'>".number_format($total_parcela, 2, ",", ".")."</td>";
                                        echo "<td width='19%' style='font-size: 10px;'>".$descricao_compra."</td>";
                                        echo "<td width='10%'>".$desc_situacao."</td>";
                                        echo "</tr>";
                                        $chave_anterior=$chave_ctp;
                                    }
                                    else {
                                        echo "<tr>";
                                        echo "<td colspan='4'></td>";
                                        echo "<td width='3%' align='center'>".$parcela."</td>";
                                        echo "<td width='6%'>".$data_vencimento->format('d/m/Y')."</td>";
                                        echo "<td width='12%'>".number_format($total_parcela, 2, ",", ".")."</td>";
                                        echo "<td></td>";
                                        echo "<td width='10%'>".$desc_situacao."</td>";
                                        echo "</tr>";
                                    }
                                }
                            ?>    
                        </tbody>

                        <tfoot>
                            
                        </tfoot>
                        </table>

                        <div class="row col-md-12">
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" 
                                 onClick="confirmar_aceite()">Confirmar Selecionados</button>

                                <button type="button" class="btn btn-info pull-right" 
                                 onClick="aceite_sair()">Voltar</button>
                            </div>
                        </div>
                    </div> <!-- fecha div responsivo -->
                    </section>
                </div>
            </div>

            <div>
                <?php
                    include "ajuda.php";
                ?>
            </div>

        </section>
    </section>

<?php 
  $javascript_file_name = 'contas_pagar.js';
  require 'rodape.php';
?>



                
                
