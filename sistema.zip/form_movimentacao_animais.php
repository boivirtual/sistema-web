<?php
    include "valida_sessao.inc";
    include "conecta_mysql.inc";
    $data_sistema = date("Y-m-d");
    $ano = date("Y");
    $mes = date("m");

    $dias_mes = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="img/boi_virtual_preto.ico">
  <title>Boi Virtual</title>

  <!-- Bootstrap CSS 
  <link href="css/jquery-ui.css" rel="stylesheet" />-->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="https://cdn.datatables.net/v/bs4/dt-1.10.22/r-2.2.6/datatables.min.css" rel="stylesheet" type="text/css"/>
  <link href="css/select-1.13.14.css" rel="stylesheet" > 

  <script src="https://kit.fontawesome.com/30604bf5d3.js" crossorigin="anonymous"></script>
</head>

<body>

  <?php

    @ session_start();

    if(isset($_SESSION['menu_manejo_animais'])) {
        $array_cadastro = explode("!",$_SESSION['menu_manejo_animais']);

        if ($array_cadastro[2] == 0){
            echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
            echo '<strong class="negrito">Atenção! </strong><span>Você não tem acesso a esse programa!</span>';  
            echo '</div>';         
            exit;
        }
    }
    else {
        echo '<div class="alert alert-danger alert_erro" id="alert_erro" >';
        echo '<strong class="negrito">Atenção! </strong><span>Você não efetuol o login!</span>';  
        echo '</div>';         
        exit;
    }

    $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_classe=4 and tbl_pessoa_lixeira=0"); 

    if ($_SESSION['data_inicial_movimentacao']==''){
        $data_inicial = $ano . '-' . $mes . '-01';
    }
    else {
        $data_inicial =  $_SESSION['data_inicial_movimentacao'];  
    }

    if ($_SESSION['data_final_movimentacao']==''){
        $data_final = $ano . '-' . $mes . '-' . $dias_mes;
    }
    else {
        $data_final =  $_SESSION['data_final_movimentacao'];   
    }

    $array_local= $_SESSION['local_movimentacao'];
    $array_tipo= $_SESSION['tipo_movimentacao'];

    $controle_estoque = $_SESSION['controle_estoque'];

    $codigo_usuario = $_SESSION['id_usuario'];

    $tbl_usuario = "SELECT * FROM usuario WHERE id_usuario = '$codigo_usuario' AND 
                                           lixeira_usuario=0 ";  
    $query = mysqli_query($conector_acesso, $tbl_usuario);

    $num_rows_usuario = mysqli_num_rows($query);

    if ($num_rows_usuario!=0){
        $reg_usuario = mysqli_fetch_assoc($query);

        $array_locais_usuario = explode(',', $reg_usuario['local_usuario']);
        $qtd_locais_usuario = count($array_locais_usuario);

        if ($qtd_locais_usuario==0) {
            $array_locais_usuario='';
        }
    }
    else {
        $array_locais_usuario='';
    }

//while ($reg_local = mysqli_fetch_object($tbl_local)) {
//    foreach ($array_locais_usuario as $value) {
//        $value = ltrim($value);
//        $value = rtrim($value);
//        if ($value==$reg_local->tbl_pessoa_id) {
//            echo $reg_local->tbl_pessoa_id; 
//            print_r('Fazenda ' . $reg_local->tbl_pessoa_id);
//       }
//    }
//}
?>

<!-- container section start -->
<section id="container" class="">

    <!--sidebar start-->
    <?php
        include "cabecalho.php";
        include "opcoes_menu.php";
    ?>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <span class="caminho-programa">Animais <i class="fa fa-angle-right seta-direita"></i>
            <span class="titulo">Movimentações</span></span>

            <a href="#" style="color: gray; margin-left: 10px;" data-toggle='tooltip' data-placement='right' title="Orientações de uso" onclick="informacoes_uso()"><i class="far fa-question-circle"></i></a>

           <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-cogs"></i> Movimentações</h3>
                </div>
            </div>

	        <div class="row">
		        <div class="col-lg-12">

                    <div  class="form-group">
                        <a href="form_movimentacao_animais_incluir.php">
                            <input type="button" class="btn btn-primary" aria-label="Left Align" value="Nova Movimentação"/>
                        </a>
                    </div> 

                    <div class="row col-md-12" id="consulta_contas">
                        <form method="GET" action="form_produtos.php" enctype="multipart/form-data" >
                            
                            <div class="tab-panel">
                                <div class="tab-pane active">
                                    <fieldset class="scheduler-border" id="dados_consulta">
                                        <legend class="scheduler-border fonte-legend">Dados para Consultar</legend>

                                        <div class="row ">
                                            <input type="hidden" name="controle_estoque" id="controle_estoque"
                                            <?php echo "value='".$controle_estoque."'";?>>

                                            <div class="form-group col-md-4">
                                                <label for="data_inicial" class="control-label">Data Inicial</label>

                                                <input type="date" name="data_inicial" id="data_inicial" class="form-control"
                                                    <?php echo "value='".$data_inicial."'";?>>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label for="data_final" class="control-label">Data Final</label>
                                                <input name="data_final" type="date" class="form-control" id="data_final"
                                                    <?php echo "value='".$data_final."'";?>>
                                            </div>
                                        </div>
                                        
                                        <div class="row">    
                                            <div class="form-group col-md-4">
                                                <label for="codigo_local" class="control-label">Local</label>
                                                <select class="form-control selectpicker" id="codigo_local" multiple name="codigo_local">
                                                <?php 
                                                    while($reg_local = mysqli_fetch_object($tbl_local)) { 
                                                    
                                                        foreach ($array_locais_usuario as $value) {
                                                            $value = ltrim($value);
                                                            $value = rtrim($value);
                                                            if ($value==$reg_local->tbl_pessoa_id) {
                                                                echo '<option value="'.$value.'">' .$reg_local->tbl_pessoa_nome. '</option>'; 
                                                            }
                                                        }
                                                    } 
                                                 ?>

                                                </select>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label for="tipo_movimentacao" class="control-label">Movimentação</label>
                                                <select class="form-control selectpicker" multiple id="tipo_movimentacao" name="tipo_movimentacao">

                                                <option value="5"
                                                    <?php 
                                                        if ($array_tipo!="") {
                                                            foreach ($array_tipo as $value) {
                                                                if ($value==5) { 
                                                                    echo "selected";       
                                                                }
                                                            }                           
                                                        }
                                                    ?>>Transferência</option>
                                                <option value="4"
                                                    <?php 
                                                        if ($array_tipo!="") {
                                                            foreach ($array_tipo as $value) {
                                                                if ($value==4) { 
                                                                    echo "selected";       
                                                                }
                                                            }                           
                                                        }
                                                    ?>>Compra</option>
                                                <option value="3"
                                                    <?php 
                                                        if ($array_tipo!="") {
                                                            foreach ($array_tipo as $value) {
                                                                if ($value==3) { 
                                                                    echo "selected";       
                                                                }
                                                            }                           
                                                        }
                                                    ?>>Venda</option>
                                                <option value="888"
                                                    <?php 
                                                        if ($array_tipo!="") {
                                                            foreach ($array_tipo as $value) {
                                                                if ($value==888) { 
                                                                    echo "selected";       
                                                                }
                                                            }                           
                                                        }
                                                    ?>>Morte</option>
                                                <option value="881"
                                                    <?php 
                                                        if ($array_tipo!="") {
                                                            foreach ($array_tipo as $value) {
                                                                if ($value==881) { 
                                                                    echo "selected";       
                                                                }
                                                            }                           
                                                        }
                                                    ?>>Natimorto</option>
                                                <option value="999"
                                                    <?php 
                                                        if ($array_tipo!="") {
                                                            foreach ($array_tipo as $value) {
                                                                if ($value==999) { 
                                                                    echo "selected";       
                                                                }
                                                            }                           
                                                        }
                                                    ?>>Outras Saídas</option>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-2">
                                                <label class="control-label">&nbsp;</label>
                                                <button type="button" class="form-control btn btn-info pull-right" onclick="consultar()">Consultar</button>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </form>
                    </div>    

                    <div id="lista_movimentacoes">
                    </div>
                </div>
            </div>
	        <!-- page end-->

            <div class="modal fade" id="modal_confirmar_venda" tabindex="-1" role="dialog" 
             aria-labelledby="modal_incluirCenterTitle" aria-hidden="true" data-backdrop="static">

                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="modal_incluirLabel">Movimentação - Confirmar Faturamento de Venda</h4>
                        </div>

                        <div class="modal-body">
                            <form method="POST" action="#" enctype="multipart/form-data">
                                <input name="codigo_animal" type="hidden" id="codigo_animal">
                              
                            <div class="tab-content">
                                <div id="dados" class="tab-pane active">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-12">

                                <p class="numero_movimento"></p>
                                <input class="numero_movimento" type="hidden">

                                <table class="table table-advance table-hover" id="tabela_vendas"
                                style="font-size: 12px;">
                                <thead>
                                    <tr> 
                                        <th>Faturamento</th>
                                        <th>Data</th>
                                        <th>Origem</th>
                                        <th>Destino</th>
                                        <th align="center">Qtde Animais</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $sql = "select * from tbl_venda 
                                            inner join tbl_pessoa
                                            on tbl_venda_codigo_local_origem=tbl_pessoa_id 
                                            where tbl_venda_categoria=1 and tbl_venda_codigo_movimentacao=0"; 
                                        $rs = mysqli_query($conector, $sql); 
                                        while ($reg_venda = mysqli_fetch_object($rs)){
                                            $numero_venda = $reg_venda->tbl_venda_id;
                                            $data_venda = new DateTime($reg_venda->tbl_venda_emissao);
                                            $data_venda = $data_venda->format('d/m/Y');
                                            $desc_origem = $reg_venda->tbl_pessoa_nome;
                                            $codigo_destino = $reg_venda->tbl_venda_codigo_local_destino;

                                            $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_id='$codigo_destino'");
                                            $reg = mysqli_fetch_object($tbl_local);
                                            $desc_destino = $reg->tbl_pessoa_nome;


                                            $tbl_itens = mysqli_query($conector, "select * from tbl_item_venda where tbl_ite_venda_numero_id ='$numero_venda'");

                                            $total_cabecas = 0;
                                            while ($reg_item = mysqli_fetch_object($tbl_itens)) {
                                                $total_cabecas+= $reg_item->tbl_ite_venda_quantidade;
                                            }

                                            echo "<tr>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_venda(\"{$numero_venda}\")'>".$numero_venda."</a></td>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_venda(\"{$numero_venda}\")'>".$data_venda."</a></td>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_venda(\"{$numero_venda}\")'>".$desc_origem."</a></td>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_venda(\"{$numero_venda}\")'>".$desc_destino."</a></td>";
                                            echo "<td align='center'><a class='' href='#' onclick='confirmar_faturamento_venda(\"{$numero_venda}\")'>".$total_cabecas."</a></td>";
                                            echo "</tr>";
                                        } 
                                    ?>
                                </tbody>
                                <tfoot>
                                </tfoot>
                                </table>  
                                </div>  
                            </div>

                            <div class="row">  
                                <div class="form-group col-md-12">
                                    <!--<button type="button" class="btn btn-primary confirma_gravar" onClick="gravar_animais()">Confirmar Inclusão</button>-->
                                    <button type="button" class="btn btn-info pull-right" data-dismiss="modal" onclick="sair_inclusao()">Voltar</button>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="modal_confirmar_compra" tabindex="-1" role="dialog" 
             aria-labelledby="modal_incluirCenterTitle" aria-hidden="true" data-backdrop="static">

                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="modal_incluirLabel">Movimentação - Confirmar Faturamento de Compra</h4>
                        </div>

                        <div class="modal-body">
                            <form method="POST" action="#" enctype="multipart/form-data">
                                <input name="codigo_animal" type="hidden" id="codigo_animal">
                              
                            <div class="tab-content">
                                <div id="dados" class="tab-pane active">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-12">

                                <p class="numero_movimento"></p>
                                <input class="numero_movimento" type="hidden">

                                <table class="table table-advance table-hover" id="tabela_vendas"
                                style="font-size: 12px;">
                                <thead>
                                    <tr> 
                                        <th>Faturamento</th>
                                        <th>Data</th>
                                        <th>Origem</th>
                                        <th>Destino</th>
                                        <th align="center">Qtde Animais</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $sql = "select * from tbl_venda 
                                            inner join tbl_pessoa
                                            on tbl_venda_codigo_local_origem=tbl_pessoa_id 
                                            where tbl_venda_categoria=2 and tbl_venda_codigo_movimentacao=0"; 
                                        $rs = mysqli_query($conector, $sql); 
                                        while ($reg_venda = mysqli_fetch_object($rs)){
                                            $numero_venda = $reg_venda->tbl_venda_id;
                                            $data_venda = new DateTime($reg_venda->tbl_venda_emissao);
                                            $data_venda = $data_venda->format('d/m/Y');
                                            $desc_origem = $reg_venda->tbl_pessoa_nome;
                                            $codigo_destino = $reg_venda->tbl_venda_codigo_local_destino;

                                            $tbl_local = mysqli_query($conector, "select * from tbl_pessoa where tbl_pessoa_id='$codigo_destino'");
                                            $reg = mysqli_fetch_object($tbl_local);
                                            $desc_destino = $reg->tbl_pessoa_nome;


                                            $tbl_itens = mysqli_query($conector, "select * from tbl_item_venda where tbl_ite_venda_numero_id ='$numero_venda'");

                                            $total_cabecas = 0;
                                            while ($reg_item = mysqli_fetch_object($tbl_itens)) {
                                                $total_cabecas+= $reg_item->tbl_ite_venda_quantidade;
                                            }

                                            echo "<tr>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_compra(\"{$numero_venda}\")'>".$numero_venda."</a></td>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_compra(\"{$numero_venda}\")'>".$data_venda."</a></td>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_compra(\"{$numero_venda}\")'>".$desc_origem."</a></td>";
                                            echo "<td><a class='' href='#' onclick='confirmar_faturamento_compra(\"{$numero_venda}\")'>".$desc_destino."</a></td>";
                                            echo "<td align='center'><a class='' href='#' onclick='confirmar_faturamento_compra(\"{$numero_venda}\")'>".$total_cabecas."</a></td>";
                                            echo "</tr>";
                                        } 
                                    ?>
                                </tbody>
                                <tfoot>
                                </tfoot>
                                </table>  
                                </div>  
                            </div>

                            <div class="row">  
                                <div class="form-group col-md-12">
                                    <!--<button type="button" class="btn btn-primary confirma_gravar" onClick="gravar_animais()">Confirmar Inclusão</button>-->
                                    <button type="button" class="btn btn-info pull-right" data-dismiss="modal" onclick="sair_inclusao()">Voltar</button>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_retorno" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Movimentações </h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" onclick="location.reload();">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="mensagem_erro" tabindex="-1" role="dialog" 
                aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Movimentações - Erro</h4>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button" >Fechar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <?php
                    include "ajuda.php";
                ?>
            </div>

        </section>
    </section>

<?php 
  $javascript_file_name = 'movimentacao.js';
  require 'rodape.php';
?>
