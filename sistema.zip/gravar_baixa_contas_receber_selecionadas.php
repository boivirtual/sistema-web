<?php

@ session_start();
$usuario_baixa = $_SESSION['nome_usuario'];
$data_sistema = date("Y/m/d H:i:s");
$mensagem = 0;

include "conecta_mysql.inc";

$grupo_contas = $_POST['grupo_contas'];
$data_pagamento = $_POST['data_pagamento'];
$conta_rec = $_POST['conta_rec'];

$matriz_contas = explode("<|>", $grupo_contas);
$quantidade_itens = count($matriz_contas);

for($i=0; $i < $quantidade_itens; $i++) {
	$chave_ctr = $matriz_contas[$i];

	$numero_doc = substr($chave_ctr, 0,10);
	$numero_parcela = substr($chave_ctr, 10,3);

	$ssql = "SELECT * FROM contas_receber 
	                 WHERE ctr_numero_doc='$numero_doc' AND ctr_parcela='$numero_parcela'";
	$conta_receber = mysqli_query($conector, $ssql); 

	$registro_conta = mysqli_fetch_object($conta_receber); 
			
	$codigo_cliente = $registro_conta->ctr_codigo_cliente_fornecedor;
	$razao = $registro_conta->ctr_nome_cliente;
	$valor_parcela = $registro_conta->ctr_valor_parcela;
	$valor_desconto = $registro_conta->ctr_valor_desconto;
	$valor_juros = $registro_conta->ctr_valor_juros;
	$valor_outro = $registro_conta->ctr_valor_acrescimo;

	$vlr_pagamento = $valor_parcela - $valor_desconto + $valor_juros + $valor_outro;
	$tipo_documento = $registro_conta->ctr_tipo;

	$historico = "Recebimento total de: " . $razao;

	$sql = "INSERT INTO baixa_contas_receber (
	   						bcr_numero_id,
							bcr_parcela,
							bcr_tipo,
							bcr_codigo_cliente_fornecedor,
							bcr_nome_cliente,
							bcr_data_pagamento,
							bcr_valor_pagamento,
							bcr_valor_juros,
							bcr_valor_desconto,
							bcr_valor_acrescimo,
							bcr_descricao_acrescimo,
							bcr_usuario_aceite,
							bcr_data_aceite,
							bcr_historico,
							bcr_situacao,
							bcr_usuario_aceite_pagamento,
							bcr_data_aceite_pagamento,
							bcr_comissao_paga)
				           VALUES ('$numero_doc', 
								   '$numero_parcela',
								   '$tipo_documento',
						           '$codigo_cliente',
								   '$razao',
					               '$data_pagamento',
								   '$vlr_pagamento',
								   null,
								   null,
								   null,
								   null,
								   '$usuario_baixa',
								   '$data_sistema',
								   '$historico',
								   'P',
								   null,
								   null,
								   null)";
								   
	$resultado = mysqli_query($conector, $sql);
	if (!$resultado) {
		$mensagem = "Ocorreu um erro ao gravar a baixa da conta." . "\n" . mysqli_error($conector);
		echo $mensagem;
		mysqli_close($conector);
	   	exit;
	}

	$sql = ("UPDATE contas_receber SET ctr_situacao='P',
		                               ctr_codigo_conta_recebimento='$conta_rec'
		                         WHERE ctr_numero_doc='$numero_doc' AND ctr_parcela='$numero_parcela'");
	$resultado = mysqli_query($conector, $sql);
					
	if (!$resultado) {
		$mensagem = "Ocorreu um erro ao gravar a baixa da conta no ctr." . "\n" . mysqli_error($conector);
		echo $mensagem;
		mysqli_close($conector);
	  	exit;
	}
}

echo $mensagem;
mysqli_close($conector);

?>